// VibeMind — DB-backed runtime settings with in-memory cache + env defaults.
// Replaces env-only config for admin-editable values.

import { db } from "@/lib/db";

// Defaults (also serve as fallback if DB is unreachable).
const DEFAULTS: Record<string, string> = {
  deliveryDelayMs: "0", // 0 = live queue; 3600000 = 60-min PRD delay
  maxTextLength: "5000",
  maxAudioSize: String(10 * 1024 * 1024),
  // Model preferences (optional — providers have their own default model)
  classifierModel: "",
  analysisModel: "",
};

// In-memory cache, populated lazily.
let cache: Map<string, string> | null = null;
let loadPromise: Promise<Map<string, string>> | null = null;

async function loadSettings(): Promise<Map<string, string>> {
  if (cache) return cache;
  if (loadPromise) return loadPromise;
  loadPromise = (async () => {
    const map = new Map<string, string>(Object.entries(DEFAULTS));
    try {
      const rows = await db.systemSetting.findMany();
      for (const r of rows) {
        map.set(r.key, r.value);
      }
    } catch (err) {
      // DB may not be ready yet (fresh install) — fall back to defaults.
      console.warn("[settings] failed to load from DB, using defaults:", err);
    }
    cache = map;
    loadPromise = null;
    return map;
  })();
  return loadPromise;
}

/** Get a setting as string (with default fallback). */
export async function getSetting(key: string): Promise<string> {
  const map = await loadSettings();
  return map.get(key) ?? DEFAULTS[key] ?? "";
}

/** Get a numeric setting (with default fallback). */
export async function getSettingNumber(key: string): Promise<number> {
  const v = await getSetting(key);
  const n = Number(v);
  return Number.isFinite(n) ? n : Number(DEFAULTS[key]) || 0;
}

/** Set a setting (upserts in DB + updates cache). */
export async function setSetting(key: string, value: string): Promise<void> {
  await db.systemSetting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  });
  if (cache) cache.set(key, value);
}

/** Bulk set settings. Uses a write lock to serialize concurrent calls. */
let writeLock: Promise<void> = Promise.resolve();
export async function setSettings(entries: Record<string, string>): Promise<void> {
  // Chain onto the previous write to avoid interleaving.
  writeLock = writeLock.then(async () => {
    for (const [key, value] of Object.entries(entries)) {
      await db.systemSetting.upsert({
        where: { key },
        update: { value },
        create: { key, value },
      });
    }
    if (cache) {
      for (const [key, value] of Object.entries(entries)) {
        cache.set(key, value);
      }
    }
  });
  await writeLock;
}

/**
 * Bust the in-memory cache (forces reload from DB on next read).
 * Waits for any in-flight write to finish before clearing, so the next read
 * sees the committed values.
 */
export async function bustSettingsCache(): Promise<void> {
  await writeLock.catch(() => {});
  cache = null;
  loadPromise = null;
}

/** Get all settings as a plain object (for admin UI). */
export async function getAllSettings(): Promise<Record<string, string>> {
  const map = await loadSettings();
  const out: Record<string, string> = {};
  for (const [k, v] of map) out[k] = v;
  return out;
}

/** Convenience: delivery delay in ms (0 = live queue). */
export async function getDeliveryDelayMs(): Promise<number> {
  return getSettingNumber("deliveryDelayMs");
}

/** True when artificial slowdown is enabled. */
export async function hasArtificialDelay(): Promise<boolean> {
  return (await getDeliveryDelayMs()) > 0;
}

/** Human-readable delivery message. */
export async function deliveryMessage(): Promise<string> {
  const delay = await getDeliveryDelayMs();
  return delay > 0
    ? `Мысль сохранена. Анализ придёт через ${Math.round(delay / 60000)} мин`
    : "Мысль сохранена. Анализ готовится в очереди";
}
