import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Self-healing: if a schema change introduced new models but the cached
// PrismaClient instance is stale (from before `prisma generate`), recreate it.
function createPrisma(): PrismaClient {
  return new PrismaClient({
    log: process.env.NODE_ENV === 'production' ? ['error'] : ['error', 'warn'],
  })
}

function getPrisma(): PrismaClient {
  const cached = globalForPrisma.prisma
  // Bust the cache if the instance is missing a known model (stale client
  // after schema change). Check the newest models added across iterations.
  if (
    cached &&
    (typeof (cached as any).questMessage === 'undefined' ||
      typeof (cached as any).tag === 'undefined' ||
      typeof (cached as any).systemSetting === 'undefined' ||
      typeof (cached as any).aIProvider === 'undefined' ||
      typeof (cached as any).analysisRevision === 'undefined')
  ) {
    try {
      cached.$disconnect().catch(() => {})
    } catch {
      /* ignore */
    }
    globalForPrisma.prisma = undefined
  }
  if (!globalForPrisma.prisma) {
    globalForPrisma.prisma = createPrisma()
  }
  return globalForPrisma.prisma
}

export const db = getPrisma()

if (process.env.NODE_ENV !== 'production') {
  // Ensure the singleton is always fresh on HMR.
  globalForPrisma.prisma = db
}