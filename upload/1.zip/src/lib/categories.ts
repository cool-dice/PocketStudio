// VibeMind — category metadata (colors, labels, icons).

import {
  Briefcase,
  ShoppingBag,
  HeartHandshake,
  Sparkles,
  type LucideIcon,
} from "lucide-react";
import type { ContextType } from "@/lib/types";

interface CategoryMeta {
  label: string;
  shortLabel: string;
  icon: LucideIcon;
  // Tailwind classes for badges / accents (light + dark).
  badge: string;
  accent: string; // text color
  ring: string; // ring/border color
  dot: string; // small status dot
  gradient: string; // header gradient for analysis card
}

export const CATEGORY_META: Record<ContextType, CategoryMeta> = {
  business: {
    label: "Бизнес и Проекты",
    shortLabel: "Бизнес",
    icon: Briefcase,
    badge:
      "bg-amber-100 text-amber-800 border-amber-200 dark:bg-amber-950/60 dark:text-amber-200 dark:border-amber-900",
    accent: "text-amber-700 dark:text-amber-300",
    ring: "ring-amber-300/50 dark:ring-amber-700/50",
    dot: "bg-amber-500",
    gradient: "from-amber-500/15 via-amber-500/5 to-transparent",
  },
  shopping: {
    label: "Быт и Покупки",
    shortLabel: "Покупки",
    icon: ShoppingBag,
    badge:
      "bg-teal-100 text-teal-800 border-teal-200 dark:bg-teal-950/60 dark:text-teal-200 dark:border-teal-900",
    accent: "text-teal-700 dark:text-teal-300",
    ring: "ring-teal-300/50 dark:ring-teal-700/50",
    dot: "bg-teal-500",
    gradient: "from-teal-500/15 via-teal-500/5 to-transparent",
  },
  psychology: {
    label: "Психология и Отношения",
    shortLabel: "Психология",
    icon: HeartHandshake,
    badge:
      "bg-rose-100 text-rose-800 border-rose-200 dark:bg-rose-950/60 dark:text-rose-200 dark:border-rose-900",
    accent: "text-rose-700 dark:text-rose-300",
    ring: "ring-rose-300/50 dark:ring-rose-700/50",
    dot: "bg-rose-500",
    gradient: "from-rose-500/15 via-rose-500/5 to-transparent",
  },
  general: {
    label: "Общий разбор",
    shortLabel: "Общее",
    icon: Sparkles,
    badge:
      "bg-stone-100 text-stone-700 border-stone-200 dark:bg-stone-800/60 dark:text-stone-200 dark:border-stone-700",
    accent: "text-stone-700 dark:text-stone-300",
    ring: "ring-stone-300/50 dark:ring-stone-600/50",
    dot: "bg-stone-500",
    gradient: "from-stone-500/15 via-stone-500/5 to-transparent",
  },
};

export function categoryMeta(c: ContextType | null | undefined): CategoryMeta {
  return CATEGORY_META[(c ?? "general") as ContextType] ?? CATEGORY_META.general;
}
