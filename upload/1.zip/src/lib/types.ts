// VibeMind — shared TypeScript types for API responses.

export type ContextType = "business" | "shopping" | "psychology" | "general";
export type InsightStatus = "pending" | "processing" | "processed" | "error";

export interface InsightTag {
  id: string;
  name: string;
  color: string;
}

export interface InsightListItem {
  id: string;
  context_type: ContextType | null;
  status: InsightStatus;
  raw_text: string;
  has_audio: boolean;
  audio_url: string | null;
  has_analysis: boolean;
  is_ready: boolean;
  notified: boolean;
  favorite: boolean;
  tags: InsightTag[];
  scheduled_delivery_at: string | null;
  created_at: string;
}

export interface InsightListResponse {
  data: InsightListItem[];
  pagination: { total: number; limit: number; offset: number };
}

export interface CaptureResponse {
  insight_id: string;
  status: InsightStatus;
  scheduled_delivery_at: string;
  message: string;
}

export interface AnalysisRevision {
  positive_block: string;
  negative_block: string;
  final_block: string;
  recommendations: string;
  created_at: string;
}

export interface AnalysisReady {
  status: "ready";
  insight_id: string;
  context_type: ContextType;
  original_text: string;
  has_audio: boolean;
  audio_url: string | null;
  positive_block: string;
  negative_block: string;
  final_block: string;
  recommendations: string;
  created_at: string;
  has_revision: boolean;
  revision: AnalysisRevision | null;
}

export interface AnalysisNotReady {
  status: "analysis_not_ready" | "error";
  insight_id: string;
  insight_status?: InsightStatus;
  estimated_time: string | null;
  scheduled_delivery_at: string | null;
  message?: string;
}

export type AnalysisResponse = AnalysisReady | AnalysisNotReady;

export interface StatsDayPoint {
  date: string;
  label: string;
  count: number;
  byCategory: Record<string, number>;
}

export interface StatsResponse {
  total: number;
  ready: number;
  pending: number;
  error: number;
  favorite: number;
  by_status: Record<string, number>;
  by_category: Record<string, number>;
  over_time: StatsDayPoint[];
}

export interface RetryResponse {
  insight_id: string;
  status: InsightStatus;
  scheduled_delivery_at: string;
  message: string;
}

export interface QuestMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  step_index: number | null;
  completed_at: string | null;
  created_at: string;
}

export interface QuestHistoryResponse {
  insight_id: string;
  messages: QuestMessage[];
  count: number;
  current_step: number;
  total_steps: number;
  is_completed: boolean;
}

export interface QuestReplyResponse {
  insight_id: string;
  user_message: QuestMessage | null;
  assistant_message: QuestMessage;
}
