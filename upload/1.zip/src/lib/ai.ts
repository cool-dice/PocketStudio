// VibeMind — AI pipeline: context classifier + multi-prompt analyzer.
// Implements PRD section 2 (dynamic context router) and section 3 (4-block analysis).
//
// Uses the OpenAI-compatible provider pool (src/lib/ai-providers.ts) with
// fallback to the built-in z-ai-web-dev-sdk when no providers are configured.

import { chatCompletion, type ChatMessage } from "@/lib/ai-providers";
import { getSetting } from "@/lib/settings";
import { CONTEXT_TYPES, type ContextType } from "@/lib/config";

// ---------------------------------------------------------------------------
// Section 2.1 — Classifier
// ---------------------------------------------------------------------------

const CLASSIFIER_SYSTEM_PROMPT = `Ты — лёгкий классификатор мыслей. Прочитай текст пользователя и определи, к какому контексту он относится.

Категории и триггеры:
- business: стартап, продажи, инвестиции, MVP, юнит-экономика, конкуренты, рынок, прибыль, cost, revenue, проект, идея бизнеса, B2B, SaaS, метрики.
- shopping: купить, стоимость, цена, скидка, замена, совместимость, гарантия, доставка, товар, выбор, сравнение.
- psychology: чувствую, отношения, тревога, границы, усталость, депрессия, рефлексия, манипуляция, эмоции, стресс, близкие.

Если ни одна категория не подходит с уверенностью > 60%, верни "general".

Ответ — строго валидный JSON без объяснений, в формате:
{"category": "business" | "shopping" | "psychology" | "general", "confidence": 0..1}`;

export interface ClassificationResult {
  category: ContextType;
  confidence: number;
}

export async function classifyContext(text: string): Promise<ClassificationResult> {
  const model = (await getSetting("classifierModel")) || undefined;
  const { content: raw } = await chatCompletion(
    [
      { role: "system", content: CLASSIFIER_SYSTEM_PROMPT },
      { role: "user", content: text },
    ],
    { temperature: 0.2, model },
  );
  return parseClassification(raw);
}

function parseClassification(raw: string): ClassificationResult {
  // Try to extract JSON from the response (model may wrap in code fences).
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      const cat = String(parsed.category ?? "general").toLowerCase();
      const category = (CONTEXT_TYPES as readonly string[]).includes(cat)
        ? (cat as ContextType)
        : "general";
      const confidence = Number(parsed.confidence) || 0;
      return { category, confidence };
    } catch {
      /* fall through */
    }
  }

  // Fallback: keyword-based heuristic.
  return { category: keywordFallback(text), confidence: 0.5 };
}

function keywordFallback(text: string): ContextType {
  const t = text.toLowerCase();
  const businessKw = ["стартап", "продаж", "инвест", "mvp", "юнит", "конкурент", "рынок", "прибыл", "cost", "revenue", "проект", "b2b", "saas", "метрик"];
  const shoppingKw = ["купить", "стоимост", "цен", "скидк", "замена", "совместимост", "гаранти", "доставк", "товар", "выбор", "сравн"];
  const psychologyKw = ["чувствую", "отношени", "тревог", "границ", "усталост", "депресс", "рефлекс", "манипуляц", "эмоци", "стресс", "близк"];

  const scores = {
    business: businessKw.filter((k) => t.includes(k)).length,
    shopping: shoppingKw.filter((k) => t.includes(k)).length,
    psychology: psychologyKw.filter((k) => t.includes(k)).length,
  } as Record<ContextType, number>;

  let best: ContextType = "general";
  let bestScore = 0;
  (Object.keys(scores) as ContextType[]).forEach((k) => {
    if (scores[k] > bestScore) {
      bestScore = scores[k];
      best = k;
    }
  });
  return bestScore === 0 ? "general" : best;
}

// ---------------------------------------------------------------------------
// Section 2.2 — Three rigid system prompts (+ general fallback)
// ---------------------------------------------------------------------------

const BUSINESS_PROMPT = `Ты — стратегический консультант по развитию бизнеса. Твоя задача — дать жёсткий, прагматичный анализ идеи пользователя.
Фокусные области:
1. Финансовая жизнеспособность: оценка юнит-экономики, точки безубыточности, маржинальности.
2. MVP-реализация: минимальный функциональный набор для проверки гипотезы, сроки, ресурсы.
3. Рыночные риски: конкуренты, барьеры входа, регуляторные ограничения, волатильность спроса.
4. Масштабируемость: возможность роста без пропорционального роста затрат.

Ответ строго структурируй в четыре блока, без воды, используй цифры, проценты и конкретные метрики там, где это возможно.`;

const SHOPPING_PROMPT = `Ты — рациональный эксперт по потребительским решениям. Твоя задача — оценить практическую ценность покупки или бытового решения.
Фокусные области:
1. Целесообразность расходов: соотношение цена/качество, частота использования, срок окупаемости.
2. Альтернативы: более дешёвые/дорогие аналоги, подержанные варианты, аренда вместо покупки.
3. Техническая совместимость: интеграция с существующими устройствами/системами, требования к инфраструктуре.
4. Скрытые затраты: обслуживание, расходники, утилизация, электроэнергия.

Ответ строго структурируй в четыре блока, используй сравнительные перечни в тексте (в виде маркированных списков), будь предельно конкретен.`;

const PSYCHOLOGY_PROMPT = `Ты — эмпатичный, но трезвый психологический ассистент. Твоя задача — поддержать, но без ложного оптимизма.
Фокусные области:
1. Личные границы: оценка ситуации с точки зрения нарушения или укрепления личных границ.
2. Когнитивные искажения: выявление возможных искажений (катастрофизация, чёрно-белое мышление, долженствование).
3. Долгосрочные последствия для ментального здоровья: как решение или ситуация повлияет через 1 месяц, 1 год.
4. Ресурсы и опоры: что уже есть у пользователя (сильные стороны), что можно укрепить.

Ответ строго структурируй в четыре блока, используй мягкий, вопросительный тон в рекомендациях, избегай клинических диагнозов, делай акцент на осознанности.`;

const GENERAL_PROMPT = `Ты — вдумчивый ассистент-спарринг партнёр. Дай сбалансированный анализ мысли пользователя без специализации.
Фокусные области:
1. Позитивные стороны и потенциал идеи.
2. Возможные риски и слабые места.
3. Главный вывод и синтез.
4. Конкретные следующие шаги.

Ответ строго структурируй в четыре блока, будь конкретен и избегай воды.`;

export function systemPromptFor(category: ContextType): string {
  switch (category) {
    case "business":
      return BUSINESS_PROMPT;
    case "shopping":
      return SHOPPING_PROMPT;
    case "psychology":
      return PSYCHOLOGY_PROMPT;
    default:
      return GENERAL_PROMPT;
  }
}

// ---------------------------------------------------------------------------
// Section 3.1 — 4-block analysis generator
// ---------------------------------------------------------------------------

const OUTPUT_FORMAT_INSTRUCTIONS = `Отвечай СТРОГО валидным JSON без markdown-обёртки и без пояснений. Формат:
{
  "positive_block": "Позитивный анализ, развитие, сильные стороны идеи (100–200 слов).",
  "negative_block": "Риски, слабые стороны, возможные проблемы (100–200 слов).",
  "final_block": "Синтез, взвешенный итог, главный вывод (80–150 слов).",
  "recommendations": "Конкретные действия, чек-лист или пошаговый план (до 10 пунктов, нумерованный список)."
}`;

export interface AnalysisBlocks {
  positive_block: string;
  negative_block: string;
  final_block: string;
  recommendations: string;
}

export async function generateAnalysis(
  text: string,
  category: ContextType,
): Promise<{ blocks: AnalysisBlocks; raw: string }> {
  const model = (await getSetting("analysisModel")) || undefined;
  const systemPrompt = systemPromptFor(category);

  const { content: raw } = await chatCompletion(
    [
      { role: "system", content: `${systemPrompt}\n\n${OUTPUT_FORMAT_INSTRUCTIONS}` },
      { role: "user", content: text },
    ],
    { temperature: 0.7, model },
  );
  const blocks = parseAnalysisBlocks(raw);
  return { blocks, raw };
}

function parseAnalysisBlocks(raw: string): AnalysisBlocks {
  // Try direct JSON parse first.
  try {
    const parsed = JSON.parse(raw);
    return normalizeBlocks(parsed);
  } catch {
    /* fall through */
  }

  // Try to extract JSON object from text (model may add ```json fences or prose).
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      return normalizeBlocks(parsed);
    } catch {
      /* fall through */
    }
  }

  // Last-resort fallback: put entire raw response into positive block.
  return {
    positive_block: raw.slice(0, 2000) || "Анализ недоступен.",
    negative_block: "Не удалось выделить негативный блок из ответа модели.",
    final_block: "Не удалось выделить финальный синтез из ответа модели.",
    recommendations: "Попробуйте переформулировать мысль и отправить снова.",
  };
}

function normalizeBlocks(parsed: any): AnalysisBlocks {
  const get = (k: string) => {
    const v = parsed?.[k];
    if (typeof v === "string") return v.trim();
    if (Array.isArray(v)) {
      // Model sometimes returns recommendations as an array of strings.
      return v
        .map((item) => (typeof item === "string" ? item.trim() : String(item)))
        .filter(Boolean)
        .join("\n");
    }
    return "";
  };
  const fallback = "Блок не сформирован моделью.";
  return {
    positive_block: get("positive_block") || fallback,
    negative_block: get("negative_block") || fallback,
    final_block: get("final_block") || fallback,
    recommendations:
      get("recommendations") ||
      "Сформулируйте 3–5 конкретных следующих шагов на основе разбора выше.",
  };
}

// ---------------------------------------------------------------------------
// Section 3.2.6 — Chat quest: multi-turn coaching dialogue
// ---------------------------------------------------------------------------

export interface QuestContext {
  originalText: string;
  contextType: ContextType;
  positiveBlock: string;
  negativeBlock: string;
  finalBlock: string;
  recommendations: string;
}

/**
 * Build the system prompt for the chat quest. It primes the AI with the
 * insight's full analysis and instructs it to coach the user step-by-step
 * through the recommendations (one at a time, with concrete questions).
 */
export function buildQuestSystemPrompt(ctx: QuestContext, opts?: { totalSteps?: number; currentStep?: number; isCompleting?: boolean }): string {
  const meta = systemPromptFor(ctx.contextType);
  const steps = opts?.totalSteps ?? countRecommendations(ctx.recommendations);
  const current = opts?.currentStep ?? 0;
  const completing = opts?.isCompleting === true;

  return `${meta}

Сейчас ты работаешь в режиме чат-квеста — пошагового наставника, который помогает пользователю проработать конкретную мысль.

КОНТЕКСТ МЫСЛИ ПОЛЬЗОВАТЕЛЯ:
"""
${ctx.originalText}
"""

ПРЕДЫДУЩИЙ РАЗБОР (который уже увидел пользователь):
— Сильные стороны: ${ctx.positiveBlock}
— Риски: ${ctx.negativeBlock}
— Синтез: ${ctx.finalBlock}
— Рекомендации (${steps} шагов):
${ctx.recommendations}

ТЕКУЩИЙ ПРОГРЕСС: шаг ${current} из ${steps}${completing ? " (ФИНАЛЬНЫЙ ШАГ — завершение)" : ""}.

ПРАВИЛА ЧАТ-КВЕСТА:
1. Веди диалог в одном сообщении за раз. Не вываливай весь план сразу.
2. Каждое твоё сообщение заканчивается ОДНИМ конкретным вопросом или микро-заданием.
3. Иди по рекомендациям последовательно: шаг 1, шаг 2, ... шаг ${steps}.
4. **ЖЁСТКО: 2–4 предложения + 1 вопрос. Максимум ~60 слов. Превышение — ошибка.** Без воды, без markdown-заголовков.
5. Если пользователь отвечает — отражай (ОДНИМ предложением) его ответ и двигайся дальше.
6. Если пользователь просит пропустить шаг — пропускай, но возвращайся в конце.
7. **ФИНАЛЬНЫЙ ШАГ (шаг ${steps}):** когда все рекомендации проработаны, дай резюме (2-3 предложения) и задай ОДИН вопрос: "Что конкретно вы сделаете прямо сегодня, чтобы продвинуться?" Это последнее сообщение квеста.
8. Не ставь клинические диагнозы, не давай юридических/финансовых гарантий.`;
}

/** Count the number of recommendations (numbered or bulleted lines). */
function countRecommendations(recs: string): number {
  const lines = recs.split(/\n+/).map((l) => l.trim()).filter(Boolean);
  // Count lines starting with a number, dash, or bullet — fallback to line count.
  const numbered = lines.filter((l) => /^(\d+[.\)]|[-–*•])/.test(l));
  return Math.max(1, numbered.length > 0 ? numbered.length : lines.length);
}

/**
 * Generate the AI's next reply in the quest, given the conversation history
 * and the quest context. Returns the assistant's message text + completion flag.
 */
export async function generateQuestReply(
  ctx: QuestContext,
  history: { role: "user" | "assistant"; content: string }[],
  opts?: { currentStep?: number; isCompleting?: boolean },
): Promise<string> {
  const model = (await getSetting("analysisModel")) || undefined;
  const totalSteps = countRecommendations(ctx.recommendations);
  const currentStep = opts?.currentStep ?? 0;
  const isCompleting = opts?.isCompleting === true;
  const systemPrompt = buildQuestSystemPrompt(ctx, { totalSteps, currentStep, isCompleting });

  const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
    { role: "system", content: systemPrompt },
  ];

  // If there's no history yet, ask the AI to open the quest with the first step.
  if (history.length === 0) {
    messages.push({
      role: "user",
      content:
        "Начни квест. Коротко (1-2 предложения) подведи к первой рекомендации и задай первый вопрос/микро-задание по ней. НЕ БОЛЕЕ 4 предложений.",
    });
  } else {
    for (const m of history) {
      messages.push({ role: m.role, content: m.content });
    }
  }

  const { content: raw } = await chatCompletion(
    messages as ChatMessage[],
    { temperature: 0.7, model, maxTokens: 250 },
  );

  // Post-process: enforce brevity. If response is excessively long, truncate.
  const text = enforceBrevity(raw);
  return text;
}

/** Enforce quest message brevity: max ~500 chars, truncate with note if exceeded. */
function enforceBrevity(text: string): string {
  const MAX_CHARS = 500;
  if (text.length <= MAX_CHARS) return text;
  // Try to cut at the last sentence boundary before MAX_CHARS.
  const truncated = text.slice(0, MAX_CHARS);
  const lastDot = truncated.lastIndexOf(".");
  if (lastDot > MAX_CHARS * 0.6) {
    return truncated.slice(0, lastDot + 1) + " — что сделаете сегодня?";
  }
  return truncated + "... — что сделаете сегодня?";
}

/**
 * Generate an evolved analysis based on the original analysis + quest dialogue.
 * Returns the revised 4-block analysis incorporating quest insights.
 */
export async function generateEvolvedAnalysis(
  ctx: QuestContext,
  questHistory: { role: "user" | "assistant"; content: string }[],
): Promise<{ blocks: AnalysisBlocks; raw: string }> {
  const model = (await getSetting("analysisModel")) || undefined;
  const meta = systemPromptFor(ctx.contextType);

  const questSummary = questHistory
    .map((m) => `${m.role === "user" ? "Пользователь" : "Наставник"}: ${m.content}`)
    .join("\n\n");

  const systemPrompt = `${meta}

Ты обновляешь разбор мысли на основе того, что выяснилось в чат-квесте.

ОРИГИНАЛЬНЫЙ РАЗБОР:
— Сильные стороны: ${ctx.positiveBlock}
— Риски: ${ctx.negativeBlock}
— Синтез: ${ctx.finalBlock}
— Рекомендации: ${ctx.recommendations}

ДИАЛОГ КВЕСТА:
"""
${questSummary}
"""

Обнови разбор с учётом того, что пользователь узнал/решил в квесте. Сохраняй структуру 4 блоков. Уточни риски, добавь новые рекомендации если они всплыли в диалоге, обнови синтез.

${OUTPUT_FORMAT_INSTRUCTIONS}`;

  const { content: raw } = await chatCompletion(
    [
      { role: "system", content: systemPrompt },
      { role: "user", content: "Сгенерируй обновлённый разбор." },
    ],
    { temperature: 0.6, model },
  );
  const blocks = parseAnalysisBlocks(raw);
  return { blocks, raw };
}
