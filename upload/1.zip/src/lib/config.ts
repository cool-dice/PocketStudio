// VibeMind — static runtime configuration (constants only).
// Runtime-configurable values (delivery delay, limits, models) live in the DB
// via src/lib/settings.ts and are editable from the admin panel.

/** Where uploaded audio files are stored (under /public so they're web-accessible). */
export const AUDIO_UPLOAD_DIR = "public/uploads";

/** Web-relative prefix for audio URLs. */
export const AUDIO_URL_PREFIX = "/uploads";

/** Context types supported by the router. */
export const CONTEXT_TYPES = ["business", "shopping", "psychology", "general"] as const;
export type ContextType = (typeof CONTEXT_TYPES)[number];

/** User roles. */
export const ROLES = {
  USER: "user",
  ADMIN: "admin",
} as const;
export type UserRole = (typeof ROLES)[keyof typeof ROLES];

/** Insight lifecycle statuses. */
export const STATUS = {
  PENDING: "pending",
  PROCESSING: "processing",
  PROCESSED: "processed",
  ERROR: "error",
} as const;
export type InsightStatus = (typeof STATUS)[keyof typeof STATUS];
