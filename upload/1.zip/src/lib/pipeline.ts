// VibeMind — background pipeline orchestrator.
// Implements PRD section 1.2 (two-stage async workflow) and section 5.1 (queue logic).
//
// In MVP we run the pipeline in-process via `setImmediate` so the HTTP response
// can return immediately while classification + analysis happen in the background.

import path from "path";
import fs from "fs";
import { db } from "@/lib/db";
import { STATUS, AUDIO_UPLOAD_DIR } from "@/lib/config";
import { getDeliveryDelayMs } from "@/lib/settings";
import { transcribeAudioFile, detectAudioFormat } from "@/lib/asr";
import { classifyContext, generateAnalysis } from "@/lib/ai";

/**
 * Run the full background pipeline for an insight:
 *   1. (audio only) transcribe via ASR
 *   2. classify context_type
 *   3. run main analysis with the matching system prompt
 *   4. persist AnalysisResult, set status=processed
 *   5. on error: set status=error + log to ErrorLog
 *
 * Does NOT throw — all errors are captured and persisted.
 */
export async function processInsight(insightId: string): Promise<void> {
  console.log(`[pipeline] start insight=${insightId}`);
  try {
    await db.insight.update({
      where: { id: insightId },
      data: { status: STATUS.PROCESSING },
    });

    const insight = await db.insight.findUnique({ where: { id: insightId } });
    if (!insight) {
      console.warn(`[pipeline] insight not found: ${insightId}`);
      return;
    }

    // Step 1 — get a textual representation of the thought.
    let text = insight.rawText ?? "";

    if (insight.audioUrl && !text) {
      // Audio-only: transcribe.
      const fileName = path.basename(insight.audioUrl);
      const absPath = path.resolve(process.cwd(), AUDIO_UPLOAD_DIR, fileName);
      if (!fs.existsSync(absPath)) {
        throw new Error(`Audio file missing on disk: ${fileName}`);
      }
      const fmt = detectAudioFormat(absPath);
      console.log(`[pipeline] transcribing audio: ${fileName} (${fmt.ext}, ${fmt.mime})`);
      try {
        const transcription = await transcribeAudioFile(absPath);
        await db.insight.update({
          where: { id: insightId },
          data: { transcription },
        });
        text = transcription;
      } catch (asrErr: any) {
        throw new Error(
          `ASR transcription failed (${fmt.ext}): ${asrErr?.message ?? asrErr}`,
        );
      }
    } else if (insight.audioUrl && text) {
      // PRD 5.1.6: when both text and audio are present, audio wins.
      const fileName = path.basename(insight.audioUrl);
      const absPath = path.resolve(process.cwd(), AUDIO_UPLOAD_DIR, fileName);
      if (fs.existsSync(absPath)) {
        const fmt = detectAudioFormat(absPath);
        console.log(`[pipeline] transcribing audio (text+audio): ${fileName} (${fmt.ext})`);
        try {
          const transcription = await transcribeAudioFile(absPath);
          await db.insight.update({
            where: { id: insightId },
            data: { transcription },
          });
          text = transcription;
        } catch (asrErr: any) {
          console.warn(`[pipeline] transcription failed, falling back to raw text (${fmt.ext}):`, asrErr?.message);
          // Keep the original raw text — audio transcription is best-effort here.
        }
      }
    }

    if (!text || text.trim().length === 0) {
      throw new Error("No text to analyse (empty raw_text and failed transcription).");
    }

    // Step 2 — classify context.
    console.log(`[pipeline] classifying insight=${insightId}`);
    const { category, confidence } = await classifyContext(text);
    await db.insight.update({
      where: { id: insightId },
      data: { contextType: category },
    });
    console.log(`[pipeline] classified insight=${insightId} as ${category} (conf=${confidence})`);

    // Step 3 — main analysis with the matching system prompt.
    console.log(`[pipeline] generating analysis insight=${insightId}`);
    const { blocks, raw } = await generateAnalysis(text, category);

    // Step 4 — persist analysis result.
    await db.analysisResult.upsert({
      where: { insightId },
      create: {
        insightId,
        positiveBlock: blocks.positive_block,
        negativeBlock: blocks.negative_block,
        finalBlock: blocks.final_block,
        recommendations: blocks.recommendations,
        rawResponse: JSON.stringify({ raw, category, confidence, text }),
      },
      update: {
        positiveBlock: blocks.positive_block,
        negativeBlock: blocks.negative_block,
        finalBlock: blocks.final_block,
        recommendations: blocks.recommendations,
        rawResponse: JSON.stringify({ raw, category, confidence, text }),
      },
    });

    await db.insight.update({
      where: { id: insightId },
      data: { status: STATUS.PROCESSED },
    });
    const delay = await getDeliveryDelayMs();
    console.log(
      `[pipeline] done insight=${insightId} (delay=${delay}ms, ready immediately)`,
    );
  } catch (err: any) {
    console.error(`[pipeline] error insight=${insightId}:`, err?.message ?? err);
    await markInsightError(insightId, err);
  }
}

async function markInsightError(insightId: string, err: any): Promise<void> {
  try {
    await db.insight.update({
      where: { id: insightId },
      data: { status: STATUS.ERROR },
    });
    // Capture diagnostic context for the error log.
    const insight = await db.insight.findUnique({
      where: { id: insightId },
      select: { status: true, contextType: true, rawText: true, audioUrl: true, transcription: true },
    });
    await db.errorLog.create({
      data: {
        insightId,
        errorMessage: err?.message ?? String(err),
        stackTrace: err?.stack ?? null,
        context: JSON.stringify({
          stage: "pipeline",
          insightStatus: insight?.status,
          contextType: insight?.contextType,
          hasRawText: !!insight?.rawText,
          hasAudio: !!insight?.audioUrl,
          hasTranscription: !!insight?.transcription,
        }),
      },
    });
  } catch (innerErr) {
    console.error(`[pipeline] failed to persist error state`, innerErr);
  }
}

/**
 * Schedule the pipeline to run asynchronously (non-blocking).
 * Call this from API routes after the insight has been created.
 */
export function schedulePipeline(insightId: string): void {
  setImmediate(() => {
    processInsight(insightId).catch((e) =>
      console.error(`[pipeline] uncaught error insight=${insightId}:`, e),
    );
  });
}

/**
 * For insights whose scheduled delivery time has passed but which haven't been
 * marked notified yet — return them so the API can flag them as ready.
 */
export async function findReadyToNotify(userId: string) {
  const now = new Date();
  return db.insight.findMany({
    where: {
      userId,
      status: STATUS.PROCESSED,
      notified: false,
      scheduledDeliveryAt: { lte: now },
    },
    select: { id: true, contextType: true, rawText: true, scheduledDeliveryAt: true },
  });
}

/**
 * Mark an insight as notified (so we don't fire the toast twice).
 */
export async function markNotified(insightId: string): Promise<void> {
  await db.insight.update({
    where: { id: insightId },
    data: { notified: true },
  });
}
