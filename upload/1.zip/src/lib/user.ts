// VibeMind — single MVP user helper.
// PRD uses Supabase Auth; for MVP we auto-provision a single local user.
// The MVP user is granted admin role so they can access the admin panel.

import { db } from "@/lib/db";
import { ROLES, type UserRole } from "@/lib/config";

const MVP_EMAIL = "you@vibemind.local";

// Cached user + timestamp; refreshed every 30s so role changes take effect
// without a server restart (important for the admin panel role management).
let cachedUser: { id: string; email: string; name: string; role: UserRole } | null = null;
let cachedAt = 0;
const CACHE_TTL_MS = 30_000;

/**
 * Returns the singleton MVP user. Creates the user on first call.
 * The MVP user has admin role so the admin panel is accessible.
 * Safe to call from API routes / server components.
 */
export async function getMvpUser(): Promise<{ id: string; email: string; name: string; role: UserRole }> {
  const now = Date.now();
  if (cachedUser && now - cachedAt < CACHE_TTL_MS) {
    return cachedUser;
  }

  let user = await db.user.findUnique({ where: { email: MVP_EMAIL } });
  if (!user) {
    user = await db.user.create({
      data: { email: MVP_EMAIL, name: "You", role: ROLES.ADMIN },
    });
  } else if (user.role !== ROLES.ADMIN) {
    // Ensure the MVP user always has admin role (auto-promote on access).
    user = await db.user.update({
      where: { id: user.id },
      data: { role: ROLES.ADMIN },
    });
  }
  cachedUser = {
    id: user.id,
    email: user.email,
    name: user.name ?? "You",
    role: user.role as UserRole,
  };
  cachedAt = now;
  return cachedUser;
}

/** Bust the user cache (forces re-fetch on next call). */
export function bustUserCache(): void {
  cachedUser = null;
  cachedAt = 0;
}


