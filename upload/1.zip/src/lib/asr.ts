// VibeMind — ASR (speech-to-text) via z-ai-web-dev-sdk.
// Used to transcribe voice insights.
//
// Supports: WAV, MP3, M4A, FLAC, OGG, WebM.
// Format is detected from the file extension and logged for debugging.

import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";
import path from "path";

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZai() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

/** Supported audio formats (extension → mime type hint for logging). */
const FORMAT_MAP: Record<string, string> = {
  ".wav": "audio/wav",
  ".mp3": "audio/mp3",
  ".m4a": "audio/m4a",
  ".flac": "audio/flac",
  ".ogg": "audio/ogg",
  ".webm": "audio/webm",
  ".opus": "audio/ogg",
};

/** Detect audio format from file path. Returns extension + mime type. */
export function detectAudioFormat(filePath: string): { ext: string; mime: string } {
  const ext = path.extname(filePath).toLowerCase();
  return {
    ext,
    mime: FORMAT_MAP[ext] ?? "unknown",
  };
}

/**
 * Transcribe an audio file from disk to text.
 * @param filePath absolute path to the audio file (webm/mp3/wav/ogg/m4a)
 * @returns transcribed text
 * @throws if the file doesn't exist, format is unsupported, or ASR returns empty text
 */
export async function transcribeAudioFile(filePath: string): Promise<string> {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Audio file not found: ${filePath}`);
  }

  const { ext, mime } = detectAudioFormat(filePath);
  console.log(`[asr] transcribing: ${path.basename(filePath)} (format: ${ext}, mime: ${mime})`);

  if (!FORMAT_MAP[ext]) {
    console.warn(`[asr] unsupported format "${ext}" — may fail. Supported: ${Object.keys(FORMAT_MAP).join(", ")}`);
  }

  const zai = await getZai();
  const audioBuffer = fs.readFileSync(filePath);
  const base64Audio = audioBuffer.toString("base64");

  try {
    const response = await zai.audio.asr.create({
      file_base64: base64Audio,
    });

    const text = (response?.text ?? "").trim();
    if (!text) {
      throw new Error(`ASR returned empty transcription (format: ${ext}, size: ${(audioBuffer.length / 1024).toFixed(1)}KB)`);
    }
    console.log(`[asr] success: ${text.length} chars transcribed from ${ext}`);
    return text;
  } catch (err: any) {
    // Enrich the error with format info for easier debugging.
    if (err?.message?.includes("empty transcription")) throw err;
    throw new Error(
      `ASR failed for ${ext} (${mime}, ${(audioBuffer.length / 1024).toFixed(1)}KB): ${err?.message ?? String(err)}`,
    );
  }
}

/**
 * Transcribe audio from a base64 string (without data: prefix).
 */
export async function transcribeBase64(base64Audio: string): Promise<string> {
  const zai = await getZai();
  const response = await zai.audio.asr.create({
    file_base64: base64Audio,
  });
  const text = (response?.text ?? "").trim();
  if (!text) {
    throw new Error("ASR returned empty transcription");
  }
  return text;
}
