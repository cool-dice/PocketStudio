// VibeMind — OpenAI-compatible AI adapter with DB-backed provider pool + fallback.
//
// Each provider has: baseUrl, apiKey, model, priority. Enabled providers are
// tried in priority order (lower = higher priority). If all fail, falls back
// to the built-in z-ai-web-dev-sdk (so the app works out of the box).
//
// Uses fetch against the OpenAI Chat Completions API shape:
//   POST {baseUrl}/chat/completions
//   { model, messages, temperature?, max_tokens? }
//   -> { choices: [{ message: { content } }] }

import ZAI from "z-ai-web-dev-sdk";
import { db } from "@/lib/db";

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface ChatCompletionOptions {
  temperature?: number;
  maxTokens?: number;
  // Override the provider's default model for this call.
  model?: string;
}

export interface ProviderInfo {
  id: string;
  name: string;
  baseUrl: string;
  apiKey: string;
  model: string;
  priority: number;
  enabled: boolean;
}

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;
async function getZai() {
  if (!zaiInstance) zaiInstance = await ZAI.create();
  return zaiInstance;
}

/** Load enabled providers sorted by priority (lowest first). */
async function loadProviders(): Promise<ProviderInfo[]> {
  try {
    const rows = await db.aIProvider.findMany({
      where: { enabled: true },
      orderBy: { priority: "asc" },
    });
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      baseUrl: r.baseUrl,
      apiKey: r.apiKey,
      model: r.model,
      priority: r.priority,
      enabled: r.enabled,
    }));
  } catch (err) {
    console.warn("[ai-providers] failed to load from DB:", err);
    return [];
  }
}

/** Call one provider's chat completions endpoint. Throws on error. */
async function callProvider(
  provider: ProviderInfo,
  messages: ChatMessage[],
  opts: ChatCompletionOptions,
): Promise<string> {
  const model = opts.model || provider.model;
  const url = `${provider.baseUrl.replace(/\/$/, "")}/chat/completions`;

  const body: Record<string, unknown> = {
    model,
    messages,
  };
  if (typeof opts.temperature === "number") body.temperature = opts.temperature;
  if (typeof opts.maxTokens === "number") body.max_tokens = opts.maxTokens;

  // Retry on 429 (rate limit) and 529 (overloaded) — up to 2 retries with backoff.
  const RETRYABLE = new Set([429, 503, 529]);
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${provider.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(120_000),
      });

      if (!res.ok) {
        const text = await res.text().catch(() => "");
        const err = new Error(
          `Provider ${provider.name} returned ${res.status}: ${text.slice(0, 300)}`,
        );
        if (RETRYABLE.has(res.status) && attempt < 2) {
          console.warn(`[ai-providers] ${provider.name} ${res.status}, retry ${attempt + 1}/2`);
          lastError = err;
          await new Promise((r) => setTimeout(r, (attempt + 1) * 1000));
          continue;
        }
        throw err;
      }

      // Parse JSON safely (some endpoints return non-JSON on edge cases).
      let data: any;
      try {
        data = await res.json();
      } catch {
        throw new Error(`Provider ${provider.name} returned non-JSON response`);
      }

      const content: string = data?.choices?.[0]?.message?.content ?? "";
      if (!content || !content.trim()) {
        throw new Error(`Provider ${provider.name} returned empty content`);
      }
      return content;
    } catch (err: any) {
      // Network errors / timeouts — retry if attempts remain.
      if (attempt < 2 && err?.name !== "AbortError") {
        lastError = err;
        await new Promise((r) => setTimeout(r, (attempt + 1) * 1000));
        continue;
      }
      throw err;
    }
  }
  throw lastError ?? new Error(`Provider ${provider.name} exhausted retries`);
}

/** Fallback to the built-in z-ai-web-dev-sdk. */
async function callZai(messages: ChatMessage[], opts: ChatCompletionOptions): Promise<string> {
  const zai = await getZai();
  // z-ai SDK uses 'assistant' role for system prompts.
  const sdkMessages = messages.map((m) =>
    m.role === "system" ? { role: "assistant" as const, content: m.content } : m,
  );
  const completion = await zai.chat.completions.create({
    messages: sdkMessages as any,
    thinking: { type: "disabled" },
  });
  const content = completion.choices[0]?.message?.content ?? "";
  if (!content || !content.trim()) {
    throw new Error("z-ai fallback returned empty content");
  }
  return content;
}

/**
 * Chat completion with fallback pool.
 * Tries each enabled DB provider in priority order; if all fail, falls back
 * to the built-in z-ai-web-dev-sdk.
 */
export async function chatCompletion(
  messages: ChatMessage[],
  opts: ChatCompletionOptions = {},
): Promise<{ content: string; provider: string }> {
  const providers = await loadProviders();
  const errors: string[] = [];

  for (const p of providers) {
    try {
      const content = await callProvider(p, messages, opts);
      return { content, provider: p.name };
    } catch (err: any) {
      errors.push(`${p.name}: ${err?.message ?? err}`);
      console.warn(`[ai-providers] ${p.name} failed, trying next:`, err?.message);
    }
  }

  // Fallback to z-ai.
  try {
    const content = await callZai(messages, opts);
    return { content, provider: "z-ai (fallback)" };
  } catch (err: any) {
    errors.push(`z-ai: ${err?.message ?? err}`);
    throw new Error(
      `All providers failed:\n${errors.join("\n")}`,
    );
  }
}

/** Test a provider config without saving (used by admin UI). */
export async function testProvider(
  baseUrl: string,
  apiKey: string,
  model: string,
): Promise<{ ok: boolean; message: string }> {
  try {
    const url = `${baseUrl.replace(/\/$/, "")}/chat/completions`;
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: "ping" }],
        max_tokens: 5,
      }),
      signal: AbortSignal.timeout(30_000),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return { ok: false, message: `HTTP ${res.status}: ${text.slice(0, 200)}` };
    }
    let data: any;
    try {
      data = await res.json();
    } catch {
      return { ok: false, message: "Provider returned non-JSON response (check baseUrl)" };
    }
    const content = data?.choices?.[0]?.message?.content ?? "";
    return {
      ok: true,
      message: `OK — model "${model}" replied: "${content.slice(0, 80)}"`,
    };
  } catch (err: any) {
    // Distinguish timeout from other errors for clearer admin feedback.
    if (err?.name === "TimeoutError" || err?.name === "AbortError") {
      return { ok: false, message: "Timeout (30s) — provider may be down or unreachable" };
    }
    return { ok: false, message: err?.message ?? String(err) };
  }
}
