"use client";

// useCurrentUser — fetches /api/me and returns the current user's info + role.
// Used to conditionally render admin features.

import { useQuery } from "@tanstack/react-query";

export interface CurrentUser {
  id: string;
  email: string;
  name: string;
  role: "user" | "admin";
}

export function useCurrentUser() {
  return useQuery<CurrentUser>({
    queryKey: ["me"],
    queryFn: async () => {
      const res = await fetch("/api/me", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load user");
      return res.json();
    },
    staleTime: 60_000, // role doesn't change often
  });
}
