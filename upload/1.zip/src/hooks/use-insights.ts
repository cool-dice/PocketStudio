"use client";

// React Query hooks for insights + analysis, with polling for ready notifications.

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { toast } from "sonner";
import type {
  AnalysisResponse,
  CaptureResponse,
  InsightListResponse,
  QuestHistoryResponse,
  QuestReplyResponse,
  RetryResponse,
  StatsResponse,
} from "@/lib/types";

const QK_LIST = ["insights"] as const;
const QK_STATS = ["stats"] as const;

export function useInsights() {
  return useQuery<InsightListResponse>({
    queryKey: QK_LIST,
    queryFn: async () => {
      const res = await fetch("/api/insights?limit=50", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load insights");
      return res.json();
    },
    // Poll every 5s only when there are pending/processing insights (to catch
    // newly-ready analyses). When all insights are settled, stop polling to
    // save bandwidth. The query still refetches on window focus.
    refetchInterval: (query) => {
      const data = query.state.data;
      if (!data?.data || data.data.length === 0) return false;
      const hasActive = data.data.some(
        (i) =>
          i.status === "pending" ||
          i.status === "processing" ||
          (i.status === "processed" && !i.is_ready),
      );
      return hasActive ? 5_000 : false;
    },
  });
}

export function useStats() {
  return useQuery<StatsResponse>({
    queryKey: QK_STATS,
    queryFn: async () => {
      const res = await fetch("/api/stats", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load stats");
      return res.json();
    },
    refetchInterval: 5_000,
  });
}

/**
 * Fires a toast for any insight that just became "ready" (analysis delivered).
 * Tracks previously-seen ready ids so we only toast once per insight.
 */
export function useReadyNotifications() {
  const { data } = useInsights();
  const seenReady = useRef<Set<string>>(new Set());
  const firstLoad = useRef(true);

  useEffect(() => {
    if (!data?.data) return;
    const readyOnes = data.data.filter((i) => i.is_ready);
    if (firstLoad.current) {
      // On first load, mark all currently-ready as already-seen (don't toast).
      readyOnes.forEach((i) => seenReady.current.add(i.id));
      firstLoad.current = false;
      return;
    }
    const fresh = readyOnes.filter((i) => !seenReady.current.has(i.id));
    fresh.forEach((i) => {
      seenReady.current.add(i.id);
      toast.success("Разбор вашей мысли готов", {
        description: "Откройте VibeMind",
        duration: 6000,
      });
      // Ask browser to show a real notification too (if permission granted).
      if (typeof window !== "undefined" && "Notification" in window) {
        if (Notification.permission === "granted") {
          new Notification("Разбор вашей мысли готов", {
            body: "Откройте VibeMind",
          });
        }
      }
    });
    // Tell the server we've shown the toast (so it stops surfacing them).
    if (fresh.length > 0) {
      fetch("/api/insights?limit=50&mark_notified=1", { cache: "no-store" }).catch(() => {});
    }
  }, [data]);
}

export function useCaptureInsight() {
  const qc = useQueryClient();
  return useMutation<
    CaptureResponse,
    Error,
    { text?: string; audioBlob?: Blob; audioName?: string }
  >({
    mutationFn: async (vars) => {
      const hasText = vars.text && vars.text.trim().length > 0;
      const hasAudio = !!vars.audioBlob;
      if (!hasText && !hasAudio) {
        throw new Error("Нужно либо ввести текст, либо записать голос");
      }
      const formData = new FormData();
      if (hasText) formData.set("text", vars.text!.trim());
      if (hasAudio) {
        const name = vars.audioName || `recording-${Date.now()}.webm`;
        formData.set("audio_file", vars.audioBlob!, name);
      }
      const res = await fetch("/api/insights/capture", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Не удалось сохранить мысль");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_LIST });
      qc.invalidateQueries({ queryKey: QK_STATS });
    },
  });
}

export function useAnalysis(insightId: string | null) {
  return useQuery<AnalysisResponse>({
    queryKey: ["analysis", insightId],
    queryFn: async () => {
      const res = await fetch(`/api/insights/${insightId}/analysis`, { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load analysis");
      return res.json();
    },
    enabled: !!insightId,
    refetchInterval: (query) => {
      const data = query.state.data;
      // Stop polling once we have a ready or terminal error.
      if (data && (data.status === "ready" || data.status === "error")) return false;
      return 4_000;
    },
  });
}

export function useDeleteInsight() {
  const qc = useQueryClient();
  return useMutation<{ success: boolean }, Error, string>({
    mutationFn: async (id) => {
      const res = await fetch(`/api/insights/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Не удалось удалить мысль");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_LIST });
      qc.invalidateQueries({ queryKey: QK_STATS });
    },
  });
}

export function useBulkDeleteInsights() {
  const qc = useQueryClient();
  return useMutation<{ deleted: number; errors: number }, Error, string[]>({
    mutationFn: async (ids) => {
      let deleted = 0;
      let errors = 0;
      // Delete sequentially to avoid memory spikes
      for (const id of ids) {
        try {
          const res = await fetch(`/api/insights/${id}`, { method: "DELETE" });
          if (res.ok) deleted++;
          else errors++;
        } catch {
          errors++;
        }
      }
      return { deleted, errors };
    },
    onSuccess: (result) => {
      qc.invalidateQueries({ queryKey: QK_LIST });
      qc.invalidateQueries({ queryKey: QK_STATS });
      if (result.errors === 0) {
        toast.success(`Удалено: ${result.deleted}`);
      } else {
        toast.warning(`Удалено: ${result.deleted}, ошибок: ${result.errors}`);
      }
    },
  });
}

export function useToggleFavorite() {
  const qc = useQueryClient();
  return useMutation<{ insight_id: string; favorite: boolean }, Error, string>({
    mutationFn: async (id) => {
      const res = await fetch(`/api/insights/${id}/favorite`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      if (!res.ok) throw new Error("Не удалось изменить избранное");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_LIST });
    },
  });
}

export function useRetryInsight() {
  const qc = useQueryClient();
  return useMutation<RetryResponse, Error, string>({
    mutationFn: async (id) => {
      const res = await fetch(`/api/insights/${id}/retry`, { method: "POST" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Не удалось запустить повторный анализ");
      }
      return res.json();
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: QK_LIST });
      qc.invalidateQueries({ queryKey: QK_STATS });
      qc.invalidateQueries({ queryKey: ["analysis", data.insight_id] });
      toast.success("Повторный анализ запущен", {
        description: "Разбор появится через несколько секунд.",
        duration: 4000,
      });
    },
  });
}

export function useRequestNotificationPermission() {
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    if (Notification.permission === "default") {
      // Defer slightly so it doesn't fire on first paint.
      const t = setTimeout(() => {
        Notification.requestPermission().catch(() => {});
      }, 2000);
      return () => clearTimeout(t);
    }
  }, []);
}

// ---------------------------------------------------------------------------
// Chat quest hooks (PRD 3.2.6)
// ---------------------------------------------------------------------------

export function useQuestHistory(insightId: string | null) {
  return useQuery<QuestHistoryResponse>({
    queryKey: ["quest", insightId],
    queryFn: async () => {
      const res = await fetch(`/api/insights/${insightId}/quest`, { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load quest history");
      return res.json();
    },
    enabled: !!insightId,
    // Poll while the AI is "thinking" (last message is from user, or no messages yet),
    // OR while the quest just completed (to pick up the evolved analysis).
    refetchInterval: (query) => {
      const data = query.state.data;
      if (!data) return 2000;
      const last = data.messages[data.messages.length - 1];
      if (!last || last.role === "user") return 2000;
      // If quest just completed, poll for a few more cycles to catch the
      // evolved analysis being generated in the background.
      if (data.is_completed && data.messages.length > 0) {
        // Stop polling 30s after completion.
        const lastMsgTime = new Date(last.created_at).getTime();
        if (Date.now() - lastMsgTime < 30_000) return 3000;
      }
      return false;
    },
  });
}

export function useStartOrSendQuest() {
  const qc = useQueryClient();
  return useMutation<QuestReplyResponse, Error, { insightId: string; message?: string }>({
    mutationFn: async ({ insightId, message }) => {
      const body = message && message.trim() ? { message: message.trim() } : {};
      const res = await fetch(`/api/insights/${insightId}/quest`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Не удалось получить ответ ИИ");
      }
      return res.json();
    },
    onSuccess: (_data, vars) => {
      // Invalidate immediately so the poll picks up the user message + starts
      // polling for the assistant reply.
      qc.invalidateQueries({ queryKey: ["quest", vars.insightId] });
    },
    onError: (err) => {
      toast.error(err.message || "Ошибка в чат-квесте");
    },
  });
}

export function useResetQuest() {
  const qc = useQueryClient();
  return useMutation<{ success: boolean }, Error, string>({
    mutationFn: async (insightId) => {
      const res = await fetch(`/api/insights/${insightId}/quest`, { method: "DELETE" });
      if (!res.ok) throw new Error("Не удалось очистить квест");
      return res.json();
    },
    onSuccess: (_d, insightId) => {
      qc.invalidateQueries({ queryKey: ["quest", insightId] });
      toast.success("Чат-квест сброшен");
    },
  });
}
