"use client";

// Tag management hooks: list all tags, create, delete, attach/detach to insight.

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { InsightTag } from "@/lib/types";

const QK_TAGS = ["tags"] as const;
const QK_LIST = ["insights"] as const;

export interface TagWithCount extends InsightTag {
  count: number;
  created_at: string;
}

export function useTags() {
  return useQuery<{ data: TagWithCount[] }>({
    queryKey: QK_TAGS,
    queryFn: async () => {
      const res = await fetch("/api/tags", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load tags");
      return res.json();
    },
  });
}

export function useCreateTag() {
  const qc = useQueryClient();
  return useMutation<InsightTag, Error, { name: string; color?: string }>({
    mutationFn: async ({ name, color }) => {
      const res = await fetch("/api/tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, color }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Не удалось создать тег");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_TAGS });
    },
  });
}

export function useDeleteTag() {
  const qc = useQueryClient();
  return useMutation<{ success: boolean }, Error, string>({
    mutationFn: async (id) => {
      const res = await fetch(`/api/tags/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Не удалось удалить тег");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_TAGS });
      qc.invalidateQueries({ queryKey: QK_LIST });
      toast.success("Тег удалён");
    },
  });
}

export function useAttachTag() {
  const qc = useQueryClient();
  return useMutation<
    { insight_id: string; tag_id: string; tag_name: string; tag_color: string; attached: boolean },
    Error,
    { insightId: string; tagId?: string; name?: string }
  >({
    mutationFn: async ({ insightId, tagId, name }) => {
      const res = await fetch(`/api/insights/${insightId}/tags`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tag_id: tagId, name }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Не удалось прикрепить тег");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_LIST });
      qc.invalidateQueries({ queryKey: QK_TAGS });
    },
  });
}

export function useDetachTag() {
  const qc = useQueryClient();
  return useMutation<{ success: boolean; detached: boolean }, Error, { insightId: string; tagId: string }>({
    mutationFn: async ({ insightId, tagId }) => {
      const res = await fetch(`/api/insights/${insightId}/tags?tag_id=${tagId}`, {
        method: "DELETE",
      });
      if (!res.ok) throw new Error("Не удалось открепить тег");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: QK_LIST });
      qc.invalidateQueries({ queryKey: QK_TAGS });
    },
  });
}
