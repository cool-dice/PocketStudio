"use client";

// useVoiceRecorder — MediaRecorder wrapper that produces a Blob + duration + waveform.
// Returns a simple amplitude history for visualisation.

import { useCallback, useEffect, useRef, useState } from "react";

interface RecorderState {
  isRecording: boolean;
  isInitializing: boolean;
  durationSec: number;
  levels: number[]; // recent peak amplitudes 0..1
  error: string | null;
}

export function useVoiceRecorder() {
  const [state, setState] = useState<RecorderState>({
    isRecording: false,
    isInitializing: false,
    durationSec: 0,
    levels: [],
    error: null,
  });

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const rafRef = useRef<number | null>(null);
  const startTimeRef = useRef<number>(0);
  const durationTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const cleanup = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    if (durationTimerRef.current) {
      clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }
    analyserRef.current = null;
    mediaRecorderRef.current = null;
  }, []);

  useEffect(() => () => cleanup(), [cleanup]);

  const start = useCallback(async () => {
    setState((s) => ({ ...s, error: null, isInitializing: true }));
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // Set up audio analysis for waveform.
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioCtx = new AudioCtx();
      audioCtxRef.current = audioCtx;
      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;

      const data = new Uint8Array(analyser.frequencyBinCount);
      const tick = () => {
        analyser.getByteTimeDomainData(data);
        let peak = 0;
        for (let i = 0; i < data.length; i++) {
          const v = Math.abs(data[i] - 128) / 128;
          if (v > peak) peak = v;
        }
        setState((s) => ({
          ...s,
          levels: [...s.levels.slice(-39), peak],
        }));
        rafRef.current = requestAnimationFrame(tick);
      };
      rafRef.current = requestAnimationFrame(tick);

      // MediaRecorder — prefer webm/opus, fallback to whatever is supported.
      const mimeCandidates = [
        "audio/webm;codecs=opus",
        "audio/webm",
        "audio/ogg;codecs=opus",
        "audio/mp4",
      ];
      let mimeType = "";
      for (const m of mimeCandidates) {
        if (MediaRecorder.isTypeSupported(m)) {
          mimeType = m;
          break;
        }
      }
      const recorder = mimeType
        ? new MediaRecorder(stream, { mimeType })
        : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      chunksRef.current = [];

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
      };

      startTimeRef.current = Date.now();
      durationTimerRef.current = setInterval(() => {
        const sec = Math.floor((Date.now() - startTimeRef.current) / 1000);
        setState((s) => ({ ...s, durationSec: sec }));
      }, 250);

      recorder.start(250);
      setState((s) => ({
        ...s,
        isRecording: true,
        isInitializing: false,
        levels: [],
        durationSec: 0,
      }));
    } catch (err: any) {
      console.error("recorder start error:", err);
      setState((s) => ({
        ...s,
        isInitializing: false,
        isRecording: false,
        error:
          err?.name === "NotAllowedError"
            ? "Доступ к микрофону запрещён. Разрешите доступ в настройках браузера."
            : err?.message ?? "Не удалось запустить запись",
      }));
      cleanup();
    }
  }, [cleanup]);

  const stop = useCallback((): Promise<{ blob: Blob | null; durationSec: number }> => {
    return new Promise((resolve) => {
      const recorder = mediaRecorderRef.current;
      if (!recorder || recorder.state === "inactive") {
        cleanup();
        setState((s) => ({ ...s, isRecording: false, isInitializing: false }));
        resolve({ blob: null, durationSec: 0 });
        return;
      }
      recorder.onstop = () => {
        const blob = new Blob(chunksRef.current, {
          type: recorder.mimeType || "audio/webm",
        });
        const dur = Math.floor((Date.now() - startTimeRef.current) / 1000);
        cleanup();
        setState((s) => ({
          ...s,
          isRecording: false,
          isInitializing: false,
          levels: [],
          durationSec: 0,
        }));
        resolve({ blob, durationSec: dur });
      };
      recorder.stop();
    });
  }, [cleanup]);

  const cancel = useCallback(() => {
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== "inactive") {
      try {
        recorder.onstop = null;
        recorder.stop();
      } catch {
        /* ignore */
      }
    }
    cleanup();
    setState({
      isRecording: false,
      isInitializing: false,
      durationSec: 0,
      levels: [],
      error: null,
    });
  }, [cleanup]);

  return { ...state, start, stop, cancel };
}
