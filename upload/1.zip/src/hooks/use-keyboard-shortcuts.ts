"use client";

// useKeyboardShortcuts — global keyboard shortcuts for the VibeMind app.
// Shortcuts:
//   n         → go to capture (new thought)
//   /         → focus the search box (on insights list)
//   ?         → toggle help modal
//   Escape    → exit select mode / close dialog / go back

import { useEffect, useRef } from "react";

interface ShortcutHandlers {
  onNew?: () => void;
  onSearch?: () => void;
  onEscape?: () => void;
  onHelp?: () => void;
}

export function useKeyboardShortcuts(handlers: ShortcutHandlers) {
  // Store handlers in a ref so the effect doesn't re-subscribe on every render
  // (the parent passes a new handlers object each render, which would cause
  // unnecessary addEventListener/removeEventListener churn).
  const ref = useRef<ShortcutHandlers>({});
  useEffect(() => {
    ref.current = handlers;
  });

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const h = ref.current;
      // Ignore if user is typing in an input/textarea/contenteditable
      const target = e.target as HTMLElement;
      const isTyping =
        target?.tagName === "INPUT" ||
        target?.tagName === "TEXTAREA" ||
        target?.isContentEditable;

      // Escape always works (even when typing)
      if (e.key === "Escape") {
        h.onEscape?.();
        return;
      }

      if (isTyping) return;

      // Single-key shortcuts
      if (e.key === "n" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        h.onNew?.();
      } else if (e.key === "/" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        h.onSearch?.();
      } else if (e.key === "?" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        // Shift+/ produces "?" on most layouts; also handle direct "?"
        e.preventDefault();
        h.onHelp?.();
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []); // Empty deps — subscribe once, read handlers via ref.
}
