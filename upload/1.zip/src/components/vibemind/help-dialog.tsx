"use client";

// VibeMind HelpDialog — lists all keyboard shortcuts + features.
// Triggered by "?" key or a button in the header.

import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Keyboard,
  Sparkles,
  Wand2,
  Search,
  Trash2,
  Copy,
  Download,
  Mic,
  PenLine,
} from "lucide-react";

interface HelpDialogProps {
  open: boolean;
  onClose: () => void;
  onStartTour?: () => void;
}

interface Shortcut {
  keys: string;
  desc: string;
}

interface Feature {
  icon: React.ElementType;
  title: string;
  desc: string;
  color: string;
}

const SHORTCUTS: Shortcut[] = [
  { keys: "N", desc: "Новая мысль — перейти к экрану захвата" },
  { keys: "/", desc: "Поиск — фокус на поле поиска в списке" },
  { keys: "Esc", desc: "Назад — закрыть модал / вернуться к списку" },
  { keys: "⌘↵", desc: "Отправить мысль (в поле ввода текста)" },
  { keys: "Enter", desc: "Отправить сообщение в чат-квесте" },
  { keys: "Shift+Enter", desc: "Перенос строки в чат-квесте" },
];

const FEATURES: Feature[] = [
  {
    icon: PenLine,
    title: "Захват мысли",
    desc: "Текстом или голосом — без форматирования. ИИ определит контекст сам.",
    color: "text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/40",
  },
  {
    icon: Mic,
    title: "Голосовая запись",
    desc: "Нажмите на микрофон, говорите — аудио транскрибируется и анализируется.",
    color: "text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-950/40",
  },
  {
    icon: Sparkles,
    title: "4-блочный разбор",
    desc: "Сильные стороны → риски → синтез → рекомендации. Раскрывается пошагово.",
    color: "text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/40",
  },
  {
    icon: Wand2,
    title: "Чат-квест",
    desc: "Пошаговая проработка рекомендаций с ИИ-наставником. Можно скопировать или скачать .md.",
    color: "text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-950/40",
  },
  {
    icon: Search,
    title: "Поиск и фильтры",
    desc: "Поиск по тексту + фильтр по категориям (бизнес, покупки, психология).",
    color: "text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-950/40",
  },
  {
    icon: Copy,
    title: "Копирование",
    desc: "Каждый блок разбора и весь разбор целиком можно скопировать одним кликом.",
    color: "text-stone-600 dark:text-stone-400 bg-stone-100 dark:bg-stone-800/60",
  },
  {
    icon: Trash2,
    title: "Массовое удаление",
    desc: "Режим выбора → отметить несколько → удалить сразу.",
    color: "text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-950/40",
  },
  {
    icon: Download,
    title: "Экспорт диалога",
    desc: "Чат-квест можно скачать как markdown-файл.",
    color: "text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-950/40",
  },
];

export function HelpDialog({ open, onClose, onStartTour }: HelpDialogProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/50 p-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="relative max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-stone-200 bg-white shadow-2xl dark:border-stone-800 dark:bg-stone-900"
            initial={{ scale: 0.95, y: 12, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.96, y: 8, opacity: 0 }}
            transition={{ type: "spring", stiffness: 360, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="Справка VibeMind"
          >
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-stone-200 bg-white/90 px-5 py-4 backdrop-blur dark:border-stone-800 dark:bg-stone-900/90">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">
                  <Keyboard className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-stone-900 dark:text-stone-50">
                    Справка
                  </h2>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400">
                    Возможности VibeMind и горячие клавиши
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="flex h-8 w-8 items-center justify-center rounded-full text-stone-500 transition-colors hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-100"
                aria-label="Закрыть"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="space-y-6 p-5 sm:p-6">
              {/* Features */}
              <section>
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-stone-500 dark:text-stone-400">
                  Возможности
                </h3>
                <div className="grid gap-3 sm:grid-cols-2">
                  {FEATURES.map((f, i) => {
                    const Icon = f.icon;
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.04 }}
                        className="flex gap-3 rounded-2xl border border-stone-200 bg-stone-50/50 p-3 dark:border-stone-800 dark:bg-stone-950/30"
                      >
                        <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${f.color}`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-stone-900 dark:text-stone-50">
                            {f.title}
                          </p>
                          <p className="mt-0.5 text-xs leading-relaxed text-stone-500 dark:text-stone-400">
                            {f.desc}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </section>

              {/* Shortcuts */}
              <section>
                <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-stone-500 dark:text-stone-400">
                  Горячие клавиши
                </h3>
                <div className="overflow-hidden rounded-2xl border border-stone-200 dark:border-stone-800">
                  {SHORTCUTS.map((s, i) => (
                    <div
                      key={i}
                      className={`flex items-center justify-between gap-3 px-4 py-2.5 ${
                        i % 2 === 0
                          ? "bg-white dark:bg-stone-900"
                          : "bg-stone-50/50 dark:bg-stone-950/30"
                      } ${i < SHORTCUTS.length - 1 ? "border-b border-stone-100 dark:border-stone-800/60" : ""}`}
                    >
                      <span className="text-sm text-stone-700 dark:text-stone-300">
                        {s.desc}
                      </span>
                      <kbd className="shrink-0 rounded-md border border-stone-300 bg-stone-100 px-2 py-1 font-mono text-[11px] font-medium text-stone-700 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300">
                        {s.keys}
                      </kbd>
                    </div>
                  ))}
                </div>
              </section>

              {/* Tip */}
              <div className="rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 p-4 dark:from-emerald-950/30 dark:to-teal-950/30">
                <p className="flex items-start gap-2 text-xs text-emerald-800 dark:text-emerald-300">
                  <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span>
                    <span className="font-medium">Совет:</span> после захвата мысли ИИ-разбор готовится в порядке живой очереди. Искусственное замедление можно включить для времени рефлексии. Чат-квест поможет проработать рекомендации шаг за шагом.
                  </span>
                </p>
                {onStartTour && (
                  <button
                    onClick={onStartTour}
                    className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white transition-colors hover:bg-emerald-700 dark:bg-emerald-700 dark:hover:bg-emerald-800"
                  >
                    <Sparkles className="h-3 w-3" />
                    Пройти тур заново
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
