"use client";

// Admin Dashboard — system-wide statistics cards.

import { useQuery } from "@tanstack/react-query";
import {
  Users,
  Brain,
  ListChecks,
  MessageSquare,
  Tag,
  Cpu,
  AlertTriangle,
  Activity,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface AdminStats {
  total_users: number;
  total_insights: number;
  total_analyses: number;
  total_quest_messages: number;
  total_tags: number;
  total_providers: number;
  total_errors: number;
  error_rate_pct: number;
  success_rate_pct: number;
  analysis_coverage_pct: number;
  by_status: Record<string, number>;
}

export function AdminDashboard() {
  const { data, isLoading } = useQuery<AdminStats>({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const res = await fetch("/api/admin/stats", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load stats");
      return res.json();
    },
  });

  if (isLoading || !data) {
    return <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div>;
  }

  const cards = [
    { label: "Пользователи", value: data.total_users, icon: Users, color: "text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-950/40" },
    { label: "Инсайты", value: data.total_insights, icon: ListChecks, color: "text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/40" },
    { label: "Анализы", value: data.total_analyses, icon: Brain, color: "text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/40" },
    { label: "Сообщения квестов", value: data.total_quest_messages, icon: MessageSquare, color: "text-teal-600 dark:text-teal-400 bg-teal-100 dark:bg-teal-950/40" },
    { label: "Теги", value: data.total_tags, icon: Tag, color: "text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-950/40" },
    { label: "AI Провайдеры", value: data.total_providers, icon: Cpu, color: "text-stone-600 dark:text-stone-400 bg-stone-100 dark:bg-stone-800/60" },
    { label: "Ошибки", value: data.total_errors, icon: AlertTriangle, color: "text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-950/40" },
    { label: "Обработано", value: data.by_status.processed ?? 0, icon: Activity, color: "text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/40" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {cards.map((c, i) => {
          const Icon = c.icon;
          return (
            <div key={i} className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
              <div className="flex items-center justify-between">
                <span className={cn("flex h-8 w-8 items-center justify-center rounded-lg", c.color)}>
                  <Icon className="h-4 w-4" />
                </span>
                <span className="text-2xl font-semibold tabular-nums text-stone-900 dark:text-stone-50">{c.value}</span>
              </div>
              <p className="mt-2 text-[11px] font-medium uppercase tracking-wider text-stone-500 dark:text-stone-400">{c.label}</p>
            </div>
          );
        })}
      </div>

      {/* Status breakdown + derived metrics */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
          <h3 className="mb-3 text-sm font-semibold text-stone-900 dark:text-stone-50">Статусы инсайтов</h3>
          <div className="space-y-2">
            {["pending", "processing", "processed", "error"].map((s) => {
              const count = data.by_status[s] ?? 0;
              const pct = data.total_insights > 0 ? Math.round((count / data.total_insights) * 100) : 0;
              const colors: Record<string, string> = {
                pending: "bg-stone-400",
                processing: "bg-amber-400",
                processed: "bg-emerald-500",
                error: "bg-rose-500",
              };
              return (
                <div key={s} className="flex items-center gap-3">
                  <span className="w-20 text-xs text-stone-500 dark:text-stone-400">{s}</span>
                  <div className="h-2 flex-1 overflow-hidden rounded-full bg-stone-100 dark:bg-stone-800">
                    <div className={cn("h-full rounded-full", colors[s])} style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-12 text-right text-xs font-medium tabular-nums text-stone-600 dark:text-stone-300">{count}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Derived metrics */}
        <div className="rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
          <h3 className="mb-3 text-sm font-semibold text-stone-900 dark:text-stone-50">Метрики</h3>
          <div className="space-y-3">
            <MetricRow label="Успешность" value={data.success_rate_pct} suffix="%" good={data.success_rate_pct > 90} />
            <MetricRow label="Покрытие анализом" value={data.analysis_coverage_pct} suffix="%" good={data.analysis_coverage_pct > 80} />
            <MetricRow label="Доля ошибок" value={data.error_rate_pct} suffix="%" good={data.error_rate_pct < 5} inverse />
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricRow({
  label,
  value,
  suffix,
  good,
  inverse,
}: {
  label: string;
  value: number;
  suffix?: string;
  good: boolean;
  inverse?: boolean; // when true, lower is better (e.g. error rate)
}) {
  const isGood = inverse ? good : good;
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-stone-500 dark:text-stone-400">{label}</span>
      <span className={cn(
        "text-sm font-semibold tabular-nums",
        isGood ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400",
      )}>
        {value}{suffix}
      </span>
    </div>
  );
}
