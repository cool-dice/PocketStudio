"use client";

// Admin Settings — DB-backed runtime settings (delivery delay, models, limits).

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Save, Loader2, Clock, Cpu, FileText, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";

const SETTING_META: Record<string, { label: string; desc: string; icon: React.ElementType; suffix?: string }> = {
  deliveryDelayMs: {
    label: "Задержка доставки (мс)",
    desc: "0 = живая очередь. 3600000 = 60 минут (оригинальный PRD).",
    icon: Clock,
    suffix: "мс",
  },
  maxTextLength: {
    label: "Макс. длина текста (символы)",
    desc: "Лимит символов для текстовой мысли.",
    icon: FileText,
    suffix: "симв.",
  },
  maxAudioSize: {
    label: "Макс. размер аудио (байты)",
    desc: "Лимит размера аудиофайла в байтах (10MB = 10485760).",
    icon: Volume2,
    suffix: "байт",
  },
  classifierModel: {
    label: "Модель классификатора (опц.)",
    desc: "Переопределяет модель провайдера для классификации. Пусто = по умолчанию.",
    icon: Cpu,
  },
  analysisModel: {
    label: "Модель анализа (опц.)",
    desc: "Переопределяет модель провайдера для анализа и квестов. Пусто = по умолчанию.",
    icon: Cpu,
  },
};

export function AdminSettings() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery<{ settings: Record<string, string> }>({
    queryKey: ["admin-settings"],
    queryFn: async () => {
      const res = await fetch("/api/admin/settings", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load settings");
      return res.json();
    },
  });

  const [draft, setDraft] = useState<Record<string, string> | null>(null);

  const settings = draft ?? data?.settings ?? {};

  const save = useMutation({
    mutationFn: async (entries: Record<string, string>) => {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(entries),
      });
      if (!res.ok) throw new Error("Failed to save settings");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-settings"] });
      toast.success("Настройки сохранены");
      setDraft(null);
    },
  });

  if (isLoading) return <div className="space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>;

  const update = (key: string, value: string) => {
    setDraft({ ...settings, [key]: value });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-stone-500 dark:text-stone-400">
          Настройки хранятся в БД и применяются без перезапуска сервера.
        </p>
        {draft && (
          <Button onClick={() => save.mutate(draft)} disabled={save.isPending} size="sm" className="gap-1.5 rounded-full">
            {save.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            Сохранить
          </Button>
        )}
      </div>

      <div className="space-y-3">
        {Object.entries(SETTING_META).map(([key, meta]) => {
          const Icon = meta.icon;
          const value = settings[key] ?? "";
          return (
            <div key={key} className="flex items-start gap-3 rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
              <div className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-stone-100 dark:bg-stone-800">
                <Icon className="h-4 w-4 text-stone-600 dark:text-stone-300" />
              </div>
              <div className="min-w-0 flex-1">
                <label className="text-sm font-medium text-stone-900 dark:text-stone-50">{meta.label}</label>
                <p className="mt-0.5 text-xs text-stone-500 dark:text-stone-400">{meta.desc}</p>
              </div>
              <div className="flex items-center gap-2">
                <Input
                  value={value}
                  onChange={(e) => update(key, e.target.value)}
                  className="w-40 text-right font-mono text-sm"
                  placeholder="—"
                />
                {meta.suffix && <span className="text-xs text-stone-400">{meta.suffix}</span>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
