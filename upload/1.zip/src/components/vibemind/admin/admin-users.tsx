"use client";

// Admin Users — list users + change role + delete.

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Shield, Trash2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

interface AdminUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  insights_count: number;
  created_at: string;
}

export function AdminUsers() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery<{ data: AdminUser[] }>({
    queryKey: ["admin-users"],
    queryFn: async () => {
      const res = await fetch("/api/admin/users", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load users");
      return res.json();
    },
  });

  const setRole = useMutation({
    mutationFn: async ({ id, role }: { id: string; role: string }) => {
      const res = await fetch(`/api/admin/users/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role }),
      });
      if (!res.ok) throw new Error("Failed to update role");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast.success("Роль обновлена");
    },
  });

  const deleteUser = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/admin/users/${id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Failed to delete");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-users"] });
      toast.success("Пользователь удалён");
    },
  });

  if (isLoading) return <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-stone-100 dark:bg-stone-800" />)}</div>;

  const users = data?.data ?? [];

  return (
    <div className="space-y-3">
      {users.map((u) => (
        <div key={u.id} className="flex items-center gap-3 rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
          <div className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
            u.role === "admin" ? "bg-stone-900 text-white dark:bg-stone-50 dark:text-stone-900" : "bg-stone-100 text-stone-500 dark:bg-stone-800 dark:text-stone-400",
          )}>
            <Shield className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-stone-900 dark:text-stone-50">{u.email}</p>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {u.insights_count} инсайтов · {new Date(u.created_at).toLocaleDateString("ru-RU")}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={u.role}
              onChange={(e) => setRole.mutate({ id: u.id, role: e.target.value })}
              disabled={setRole.isPending}
              className="h-8 rounded-lg border border-stone-200 bg-white px-2 text-xs font-medium text-stone-700 focus-visible:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200"
            >
              <option value="user">user</option>
              <option value="admin">admin</option>
            </select>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-stone-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40" aria-label="Удалить">
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Удалить пользователя {u.email}?</AlertDialogTitle>
                  <AlertDialogDescription>Все инсайты, анализы и квесты этого пользователя будут удалены. Действие необратимо.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Отмена</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => deleteUser.mutate(u.id)}
                    className="bg-rose-600 hover:bg-rose-700 dark:bg-rose-700"
                  >
                    {deleteUser.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Удалить"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      ))}
      {users.length === 0 && <p className="py-8 text-center text-sm text-stone-400">Нет пользователей</p>}
    </div>
  );
}
