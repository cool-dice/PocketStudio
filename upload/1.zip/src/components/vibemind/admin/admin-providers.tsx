"use client";

// Admin Providers — manage OpenAI-compatible AI provider pool (CRUD + test).

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Trash2, Loader2, Zap, Power, CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";

interface Provider {
  id: string;
  name: string;
  baseUrl: string;
  apiKey: string;
  model: string;
  priority: number;
  enabled: boolean;
  kind: string;
}

export function AdminProviders() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery<{ data: Provider[] }>({
    queryKey: ["admin-providers"],
    queryFn: async () => {
      const res = await fetch("/api/admin/providers", { cache: "no-store" });
      if (!res.ok) throw new Error("Failed to load providers");
      return res.json();
    },
  });

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", baseUrl: "", apiKey: "", model: "", priority: 10 });
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  const createProvider = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch("/api/admin/providers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err?.error ?? "Failed to create");
      }
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-providers"] });
      toast.success("Провайдер добавлен");
      setForm({ name: "", baseUrl: "", apiKey: "", model: "", priority: 10 });
      setShowForm(false);
      setTestResult(null);
    },
  });

  const toggleEnabled = useMutation({
    mutationFn: async ({ id, enabled }: { id: string; enabled: boolean }) => {
      const res = await fetch(`/api/admin/providers/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled }),
      });
      if (!res.ok) throw new Error("Failed to toggle");
      return res.json();
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-providers"] }),
  });

  const deleteProvider = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/admin/providers/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Failed to delete");
      return res.json();
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-providers"] });
      toast.success("Провайдер удалён");
    },
  });

  const testProvider = useMutation({
    mutationFn: async (data: typeof form) => {
      const res = await fetch("/api/admin/providers/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Test failed");
      return res.json();
    },
    onSuccess: (result) => setTestResult(result),
  });

  if (isLoading) return <div className="space-y-3">{Array.from({ length: 2 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-stone-100 dark:bg-stone-800" />)}</div>;

  const providers = data?.data ?? [];

  return (
    <div className="space-y-4">
      {/* Add button */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-stone-500 dark:text-stone-400">
          Пул провайдеров (OpenAI-совместимый). Используются по приоритету для fallback.
        </p>
        <Button onClick={() => setShowForm((v) => !v)} size="sm" className="gap-1.5 rounded-full">
          <Plus className="h-3.5 w-3.5" />
          {showForm ? "Отмена" : "Добавить"}
        </Button>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="space-y-3 rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium text-stone-500">Название</label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="OpenAI" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-stone-500">Базовый URL</label>
              <Input value={form.baseUrl} onChange={(e) => setForm({ ...form, baseUrl: e.target.value })} placeholder="https://api.openai.com/v1" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-stone-500">API ключ</label>
              <Input type="password" value={form.apiKey} onChange={(e) => setForm({ ...form, apiKey: e.target.value })} placeholder="sk-..." />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-stone-500">Модель</label>
              <Input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} placeholder="gpt-4o-mini" />
            </div>
          </div>
          {testResult && (
            <div className={cn(
              "flex items-center gap-2 rounded-lg px-3 py-2 text-xs",
              testResult.ok ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300" : "bg-rose-50 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300",
            )}>
              {testResult.ok ? <CheckCircle2 className="h-4 w-4 shrink-0" /> : <XCircle className="h-4 w-4 shrink-0" />}
              {testResult.message}
            </div>
          )}
          <div className="flex items-center gap-2">
            <Button onClick={() => testProvider.mutate(form)} disabled={testProvider.isPending || !form.baseUrl || !form.apiKey || !form.model} variant="outline" size="sm" className="gap-1.5 rounded-full">
              {testProvider.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Zap className="h-3.5 w-3.5" />}
              Тест
            </Button>
            <Button onClick={() => createProvider.mutate(form)} disabled={createProvider.isPending || !form.name || !form.baseUrl || !form.apiKey || !form.model} size="sm" className="gap-1.5 rounded-full">
              {createProvider.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
              Сохранить
            </Button>
          </div>
        </div>
      )}

      {/* Provider list */}
      <div className="space-y-2">
        {providers.map((p) => (
          <div key={p.id} className="flex items-center gap-3 rounded-2xl border border-stone-200 bg-white p-4 dark:border-stone-800 dark:bg-stone-900">
            <div className={cn(
              "flex h-9 w-9 shrink-0 items-center justify-center rounded-lg",
              p.enabled ? "bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400" : "bg-stone-100 text-stone-400 dark:bg-stone-800",
            )}>
              <Zap className="h-4 w-4" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-stone-900 dark:text-stone-50">{p.name}</span>
                <span className="rounded-full bg-stone-100 px-1.5 py-0.5 text-[9px] font-medium text-stone-500 dark:bg-stone-800 dark:text-stone-400">
                  приоритет {p.priority}
                </span>
              </div>
              <p className="truncate text-xs text-stone-500 dark:text-stone-400">
                {p.model} · {p.baseUrl} · {p.apiKey}
              </p>
            </div>
            <button
              onClick={() => toggleEnabled.mutate({ id: p.id, enabled: !p.enabled })}
              disabled={toggleEnabled.isPending}
              className={cn(
                "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
                p.enabled ? "text-emerald-600 hover:bg-emerald-50 dark:text-emerald-400 dark:hover:bg-emerald-950/40" : "text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800",
              )}
              aria-label={p.enabled ? "Выключить" : "Включить"}
            >
              <Power className="h-4 w-4" />
            </button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-stone-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/40" aria-label="Удалить">
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Удалить провайдер {p.name}?</AlertDialogTitle>
                  <AlertDialogDescription>Провайдер будет удалён из пула fallback.</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Отмена</AlertDialogCancel>
                  <AlertDialogAction onClick={() => deleteProvider.mutate(p.id)} className="bg-rose-600 hover:bg-rose-700 dark:bg-rose-700">Удалить</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        ))}
        {providers.length === 0 && (
          <div className="rounded-2xl border border-dashed border-stone-300 bg-stone-50/50 p-8 text-center dark:border-stone-700 dark:bg-stone-900/40">
            <p className="text-sm text-stone-500 dark:text-stone-400">Нет провайдеров. Используется встроенный z-ai fallback.</p>
            <p className="mt-1 text-xs text-stone-400">Добавьте OpenAI-совместимый провайдер, чтобы настроить пул fallback.</p>
          </div>
        )}
      </div>
    </div>
  );
}
