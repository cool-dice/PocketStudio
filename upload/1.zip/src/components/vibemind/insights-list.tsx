"use client";

// VibeMind insights list — shows all captured thoughts with status + category.
// Includes: stats strip, search box, category filter chips, refined empty state.

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Loader2,
  Mic,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Trash2,
  Inbox,
  ChevronRight,
  RefreshCw,
  Search,
  X,
  RotateCw,
  CheckSquare,
  Square,
  XCircle,
  Star,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useInsights, useDeleteInsight, useRetryInsight, useBulkDeleteInsights, useToggleFavorite } from "@/hooks/use-insights";
import { useDetachTag, useTags } from "@/hooks/use-tags";
import { StatsStrip } from "./stats-strip";
import { StatsDashboard } from "./stats-dashboard";
import { TagChip, TagPicker, tagColorClasses } from "./tag-components";
import { categoryMeta } from "@/lib/categories";
import { cn } from "@/lib/utils";
import type { ContextType, InsightListItem } from "@/lib/types";

interface InsightsListProps {
  onOpenInsight: (id: string) => void;
  onGoCapture: () => void;
}

export function InsightsList({ onOpenInsight, onGoCapture }: InsightsListProps) {
  const { data, isLoading, isFetching, refetch } = useInsights();
  const del = useDeleteInsight();
  const retry = useRetryInsight();
  const bulkDel = useBulkDeleteInsights();
  const favToggle = useToggleFavorite();
  const detachTag = useDetachTag();

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<ContextType | "all">("all");
  const [selectMode, setSelectMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "status">("newest");
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [activeTagId, setActiveTagId] = useState<string | null>(null);

  const allItems = data?.data ?? [];
  const favCount = allItems.filter((i) => i.favorite).length;
  const { data: tagsData } = useTags();
  const allTags = tagsData?.data ?? [];

  // Client-side filter + sort (search + category + favorites + tag + sort).
  const items = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = allItems.filter((it) => {
      if (category !== "all" && (it.context_type ?? "general") !== category) return false;
      if (favoritesOnly && !it.favorite) return false;
      if (activeTagId && !it.tags.some((t) => t.id === activeTagId)) return false;
      if (!q) return true;
      const hay = (it.raw_text ?? "").toLowerCase();
      return hay.includes(q);
    });
    const sorted = [...filtered];
    // Favorites always pinned to top (unless sorting by status)
    if (sortBy !== "status") {
      sorted.sort((a, b) => Number(b.favorite) - Number(a.favorite));
    }
    if (sortBy === "newest") {
      sorted.sort((a, b) => {
        if (a.favorite !== b.favorite) return 0;
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      });
    } else if (sortBy === "oldest") {
      sorted.sort((a, b) => {
        if (a.favorite !== b.favorite) return 0;
        return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      });
    } else if (sortBy === "status") {
      const rank = (s: string, ready: boolean) => {
        if (ready) return 0;
        if (s === "processing") return 1;
        if (s === "pending") return 2;
        if (s === "processed") return 3;
        if (s === "error") return 4;
        return 5;
      };
      sorted.sort((a, b) => rank(a.status, a.is_ready) - rank(b.status, b.is_ready));
    }
    return sorted;
  }, [allItems, query, category, favoritesOnly, activeTagId, sortBy]);

  const hasItems = allItems.length > 0;
  const hasFilters = query.trim() !== "" || category !== "all" || favoritesOnly || activeTagId !== null;

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === items.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(items.map((i) => i.id)));
    }
  };

  const exitSelectMode = () => {
    setSelectMode(false);
    setSelectedIds(new Set());
  };

  const handleBulkDelete = () => {
    const ids = Array.from(selectedIds);
    bulkDel.mutate(ids, {
      onSuccess: () => {
        exitSelectMode();
      },
    });
  };

  const allSelected = items.length > 0 && selectedIds.size === items.length;

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6 sm:px-6 sm:py-8">
      <div className="mb-5 flex items-end justify-between gap-3">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight text-stone-900 dark:text-stone-50">
            Мои мысли
          </h2>
          <p className="mt-1 text-sm text-stone-500 dark:text-stone-400">
            {data?.pagination.total ?? 0} всего · нажмите на карточку, чтобы открыть разбор
          </p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => refetch()}
          disabled={isFetching}
          className="rounded-full text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
          aria-label="Обновить список"
        >
          <RefreshCw className={cn("mr-1.5 h-3.5 w-3.5", isFetching && "animate-spin")} />
          <span className="hidden sm:inline">Обновить</span>
        </Button>
        {hasItems && !selectMode && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSelectMode(true)}
            className="rounded-full text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
            aria-label="Выбрать мысли"
          >
            <CheckSquare className="mr-1.5 h-3.5 w-3.5" />
            <span className="hidden sm:inline">Выбрать</span>
          </Button>
        )}
      </div>

      {/* Stats + category chips */}
      {hasItems && (
        <StatsStrip
          activeCategory={category}
          onCategoryClick={(c) => setCategory((cur) => (cur === c && c !== "all" ? "all" : c))}
        />
      )}

      {/* Stats dashboard — collapsible charts */}
      {hasItems && <StatsDashboard />}

      {/* Bulk action bar (select mode) */}
      <AnimatePresence>
        {selectMode && hasItems && (
          <motion.div
            initial={{ opacity: 0, height: 0, marginBottom: 0 }}
            animate={{ opacity: 1, height: "auto", marginBottom: 16 }}
            exit={{ opacity: 0, height: 0, marginBottom: 0 }}
            className="overflow-hidden"
          >
            <div className="flex items-center justify-between rounded-2xl border border-violet-200 bg-violet-50/60 px-4 py-2.5 dark:border-violet-900/60 dark:bg-violet-950/20">
              <div className="flex items-center gap-3">
                <button
                  onClick={toggleSelectAll}
                  className="flex items-center gap-2 text-sm font-medium text-violet-700 dark:text-violet-300"
                  aria-label={allSelected ? "Снять выделение" : "Выбрать все"}
                >
                  {allSelected ? (
                    <CheckSquare className="h-4 w-4" />
                  ) : (
                    <Square className="h-4 w-4" />
                  )}
                  <span className="hidden sm:inline">
                    {allSelected ? "Снять все" : "Все"}
                  </span>
                </button>
                <span className="text-sm text-violet-600 dark:text-violet-400">
                  Выбрано: {selectedIds.size}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      size="sm"
                      disabled={selectedIds.size === 0 || bulkDel.isPending}
                      className="gap-1.5 rounded-full bg-rose-600 px-3 text-xs text-white hover:bg-rose-700 dark:bg-rose-700 dark:hover:bg-rose-800"
                    >
                      {bulkDel.isPending ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Trash2 className="h-3.5 w-3.5" />
                      )}
                      Удалить {selectedIds.size > 0 ? `(${selectedIds.size})` : ""}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Удалить выбранные мысли?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Будет удалено {selectedIds.size}{" "}
                        {selectedIds.size === 1 ? "мысль" : "мыслей"} вместе с их ИИ-разбором и историей чат-квеста. Действие необратимо.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Отмена</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={handleBulkDelete}
                        className="bg-rose-600 hover:bg-rose-700 dark:bg-rose-700 dark:hover:bg-rose-800"
                      >
                        Удалить всё
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={exitSelectMode}
                  className="gap-1.5 rounded-full px-2.5 text-xs text-violet-600 hover:bg-violet-100 hover:text-violet-900 dark:text-violet-400 dark:hover:bg-violet-950/40"
                  aria-label="Выйти из режима выбора"
                >
                  <XCircle className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Отмена</span>
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Favorites + tag filters — show when relevant */}
      {(favCount > 0 || allTags.length > 0) && (
        <div className="mb-3 flex flex-wrap items-center gap-1.5">
          {favCount > 0 && (
            <button
              onClick={() => setFavoritesOnly((v) => !v)}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition-all",
                favoritesOnly
                  ? "border-amber-400 bg-amber-100 text-amber-800 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-300"
                  : "border-stone-200 bg-white text-stone-600 hover:border-amber-300 hover:text-amber-600 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-300 dark:hover:border-amber-800",
              )}
              aria-pressed={favoritesOnly}
            >
              <Star className={cn("h-3 w-3", favoritesOnly && "fill-current")} />
              Избранные
              <span className="tabular-nums opacity-70">{favCount}</span>
            </button>
          )}
          {/* Tag filter chips */}
          {allTags.map((t) => {
            const isActive = activeTagId === t.id;
            const c = tagColorClasses(t.color);
            return (
              <button
                key={t.id}
                onClick={() => setActiveTagId(isActive ? null : t.id)}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition-all",
                  isActive
                    ? cn("border-transparent", c.bg, c.text)
                    : "border-stone-200 bg-white text-stone-600 hover:border-stone-300 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-300 dark:hover:border-stone-600",
                )}
                aria-pressed={isActive}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full", c.dot)} />
                {t.name}
                <span className="tabular-nums opacity-70">{t.count}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Search + sort row — only when there are items */}
      {hasItems && (
        <div className="mb-4 flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400 dark:text-stone-500" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Поиск по мыслям..."
              aria-label="Поиск по мыслям"
              className={cn(
                "h-10 rounded-full border-stone-200 bg-white pl-9 pr-9 text-sm",
                "placeholder:text-stone-400 focus-visible:ring-2 focus-visible:ring-stone-300",
                "dark:border-stone-800 dark:bg-stone-900 dark:placeholder:text-stone-500",
              )}
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                aria-label="Очистить поиск"
                className="absolute right-2.5 top-1/2 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full text-stone-400 transition-colors hover:bg-stone-100 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
          {/* Sort dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as "newest" | "oldest" | "status")}
            aria-label="Сортировка"
            className="h-10 shrink-0 rounded-full border border-stone-200 bg-white px-3 text-xs font-medium text-stone-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-300 dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300"
          >
            <option value="newest">Сначала новые</option>
            <option value="oldest">Сначала старые</option>
            <option value="status">По статусу</option>
          </select>
        </div>
      )}

      {isLoading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-24 w-full rounded-2xl" />
          ))}
        </div>
      ) : !hasItems ? (
        <EmptyState onGoCapture={onGoCapture} />
      ) : items.length === 0 ? (
        <NoResultsState
          hasFilters={hasFilters}
          onReset={() => {
            setQuery("");
            setCategory("all");
            setFavoritesOnly(false);
            setActiveTagId(null);
          }}
        />
      ) : (
        <ul className="space-y-3">
          <AnimatePresence initial={false}>
            {items.map((item, idx) => (
              <motion.li
                key={item.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8, scale: 0.98 }}
                transition={{ duration: 0.2, delay: Math.min(idx * 0.03, 0.3) }}
              >
                <InsightCardRow
                  item={item}
                  onOpen={() => onOpenInsight(item.id)}
                  onDelete={() => del.mutate(item.id)}
                  onRetry={() => retry.mutate(item.id)}
                  onToggleFavorite={() => favToggle.mutate(item.id)}
                  deleting={del.isPending}
                  retrying={retry.isPending}
                  favoriting={favToggle.isPending}
                  selectMode={selectMode}
                  isSelected={selectedIds.has(item.id)}
                  onToggleSelect={() => toggleSelect(item.id)}
                />
              </motion.li>
            ))}
          </AnimatePresence>
        </ul>
      )}
    </div>
  );
}

function EmptyState({ onGoCapture }: { onGoCapture: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-3xl border border-dashed border-stone-300 bg-white/60 p-10 text-center dark:border-stone-700 dark:bg-stone-900/40"
    >
      {/* Ambient gradient */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-amber-500/5" />
      <div className="relative flex flex-col items-center">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 280, damping: 20 }}
          className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-100 to-teal-100 dark:from-emerald-950/60 dark:to-teal-950/60"
        >
          <Inbox className="h-8 w-8 text-emerald-600 dark:text-emerald-400" strokeWidth={1.8} />
        </motion.div>
        <h3 className="mt-5 text-lg font-semibold text-stone-900 dark:text-stone-50">
          Пока нет мыслей
        </h3>
        <p className="mt-1.5 max-w-sm text-sm text-stone-500 dark:text-stone-400">
          Запишите первую мысль голосом или текстом — и вскоре здесь появится ИИ-разбор со сильными сторонами, рисками и пошаговым планом.
        </p>
        <Button
          onClick={onGoCapture}
          className="mt-6 rounded-full bg-stone-900 px-5 dark:bg-stone-50 dark:text-stone-900"
        >
          Записать первую мысль
        </Button>
      </div>
    </motion.div>
  );
}

function NoResultsState({
  hasFilters,
  onReset,
}: {
  hasFilters: boolean;
  onReset: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center rounded-2xl border border-stone-200 bg-white/60 p-8 text-center dark:border-stone-800 dark:bg-stone-900/40"
    >
      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-stone-100 dark:bg-stone-800">
        <Search className="h-6 w-6 text-stone-400" />
      </div>
      <h3 className="mt-4 text-base font-semibold text-stone-900 dark:text-stone-50">
        Ничего не найдено
      </h3>
      <p className="mt-1 text-sm text-stone-500 dark:text-stone-400">
        {hasFilters
          ? "Попробуйте изменить запрос или сбросить фильтры."
          : "Список пуст."}
      </p>
      {hasFilters && (
        <Button
          variant="outline"
          size="sm"
          onClick={onReset}
          className="mt-4 rounded-full"
        >
          <X className="mr-1.5 h-3.5 w-3.5" />
          Сбросить фильтры
        </Button>
      )}
    </motion.div>
  );
}

function InsightCardRow({
  item,
  onOpen,
  onDelete,
  onRetry,
  onToggleFavorite,
  deleting,
  retrying,
  favoriting,
  selectMode,
  isSelected,
  onToggleSelect,
}: {
  item: InsightListItem;
  onOpen: () => void;
  onDelete: () => void;
  onRetry: () => void;
  onToggleFavorite: () => void;
  deleting: boolean;
  retrying: boolean;
  favoriting: boolean;
  selectMode: boolean;
  isSelected: boolean;
  onToggleSelect: () => void;
}) {
  const meta = categoryMeta(item.context_type);
  const Icon = meta.icon;
  const isError = item.status === "error";

  const status = (() => {
    if (item.status === "error") {
      return { label: "Ошибка", icon: AlertTriangle, color: "text-rose-600 dark:text-rose-400" };
    }
    if (item.is_ready) {
      return { label: "Готово", icon: CheckCircle2, color: "text-emerald-600 dark:text-emerald-400" };
    }
    if (item.status === "processed") {
      return { label: "Готовится к доставке", icon: Clock, color: "text-amber-600 dark:text-amber-400" };
    }
    if (item.status === "processing") {
      return { label: "Анализируем", icon: Loader2, color: "text-stone-500 dark:text-stone-400", spin: true };
    }
    return { label: "В очереди", icon: Clock, color: "text-stone-500 dark:text-stone-400" };
  })();

  const StatusIcon = status.icon;

  const preview =
    item.raw_text?.trim() ||
    (item.has_audio ? "Голосовая запись" : "Без текста");

  return (
    <div
      className={cn(
        "group relative flex items-stretch rounded-2xl border bg-white p-4 transition-all dark:bg-stone-900",
        isError
          ? "border-rose-200 hover:border-rose-300 dark:border-rose-900/60 dark:hover:border-rose-800"
          : "border-stone-200 hover:border-stone-300 dark:border-stone-800 dark:hover:border-stone-700",
        item.is_ready && !selectMode && "ring-1 ring-emerald-200/60 dark:ring-emerald-900/40",
        isSelected && "border-violet-400 ring-2 ring-violet-300/50 dark:border-violet-700 dark:ring-violet-700/40",
      )}
    >
      {/* Category accent strip */}
      <div className={cn("absolute inset-y-0 left-0 w-1 rounded-l-2xl", meta.dot)} />

      {/* Checkbox (select mode only) */}
      {selectMode && (
        <div className="flex items-center pl-2 pr-1">
          <Checkbox
            checked={isSelected}
            onCheckedChange={onToggleSelect}
            aria-label={`Выбрать мысль: ${preview.slice(0, 40)}`}
            className="data-[state=checked]:border-violet-600 data-[state=checked]:bg-violet-600"
          />
        </div>
      )}

      <button
        onClick={selectMode ? onToggleSelect : onOpen}
        className="flex flex-1 items-center gap-4 pl-3 text-left"
        aria-label={selectMode ? `Выбрать мысль: ${preview.slice(0, 60)}` : `Открыть мысль: ${preview.slice(0, 60)}`}
      >
        {/* Category icon */}
        <div
          className={cn(
            "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border bg-white dark:bg-stone-950",
            meta.badge,
          )}
        >
          <Icon className="h-5 w-5" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={cn("border-transparent px-1.5 py-0 text-[10px] font-medium", meta.badge)}>
              {meta.shortLabel}
            </Badge>
            {item.has_audio && (
              <span className="inline-flex items-center gap-1 text-[10px] font-medium text-stone-400 dark:text-stone-500">
                <Mic className="h-3 w-3" />
                голос
              </span>
            )}
            <span className={cn("ml-auto inline-flex items-center gap-1 text-[11px] font-medium", status.color)}>
              <StatusIcon className={cn("h-3 w-3", (status as any).spin && "animate-spin")} />
              {status.label}
            </span>
          </div>
          <p className="mt-1.5 line-clamp-2 text-sm text-stone-800 dark:text-stone-100">
            {preview}
          </p>
          <div className="mt-1.5 flex items-center gap-2 text-[11px] text-stone-400 dark:text-stone-500">
            <Clock className="h-3 w-3" />
            <time dateTime={item.created_at}>
              {new Date(item.created_at).toLocaleString("ru-RU", {
                day: "numeric",
                month: "short",
                hour: "2-digit",
                minute: "2-digit",
              })}
            </time>
            {item.scheduled_delivery_at && !item.is_ready && item.status !== "error" && (
              <>
                <span aria-hidden>·</span>
                <span>
                  разбор {new Date(item.scheduled_delivery_at) > new Date() ? "к" : "был к"}{" "}
                  {new Date(item.scheduled_delivery_at).toLocaleTimeString("ru-RU", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </>
            )}
          </div>

          {/* Tags row */}
          {(!selectMode) && (item.tags.length > 0 || true) && (
            <div className="mt-2 flex flex-wrap items-center gap-1">
              {item.tags.map((t) => (
                <TagChip
                  key={t.id}
                  tag={t}
                  size="xs"
                  onRemove={() => detachTag.mutate({ insightId: item.id, tagId: t.id })}
                />
              ))}
              <TagPicker insightId={item.id} insightTags={item.tags} />
            </div>
          )}
        </div>

        {!selectMode && (
          <ChevronRight className="h-4 w-4 shrink-0 text-stone-300 transition-transform group-hover:translate-x-0.5 group-hover:text-stone-500 dark:text-stone-600 dark:group-hover:text-stone-300" />
        )}
      </button>

      {/* Favorite star — top-right, always visible */}
      {!selectMode && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavorite();
          }}
          disabled={favoriting}
          aria-label={item.favorite ? "Убрать из избранного" : "В избранное"}
          className={cn(
            "absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full transition-all",
            item.favorite
              ? "text-amber-500 opacity-100"
              : "text-stone-300 opacity-0 hover:bg-amber-50 hover:text-amber-500 group-hover:opacity-100 dark:text-stone-600 dark:hover:bg-amber-950/40 [@media(hover:none)]:opacity-60",
          )}
        >
          <Star className={cn("h-3.5 w-3.5", item.favorite && "fill-current")} />
        </button>
      )}

      {/* Retry (only on error) */}
      {isError && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onRetry}
          disabled={retrying}
          className="absolute bottom-2 right-2 h-7 gap-1 rounded-full text-[11px] text-rose-600 hover:bg-rose-50 hover:text-rose-700 dark:text-rose-400 dark:hover:bg-rose-950/40"
          aria-label="Запустить повторный анализ"
        >
          {retrying ? (
            <Loader2 className="h-3 w-3 animate-spin" />
          ) : (
            <RotateCw className="h-3 w-3" />
          )}
          Повторить
        </Button>
      )}

      {/* Delete */}
      <AlertDialog>
        <AlertDialogTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "absolute right-2 text-stone-300 opacity-0 transition-opacity hover:bg-rose-50 hover:text-rose-600 group-hover:opacity-100 dark:text-stone-600 dark:hover:bg-rose-950/40",
              isError ? "top-2 h-7 w-7" : "top-2 h-7 w-7",
            )}
            aria-label="Удалить мысль"
            disabled={deleting}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </AlertDialogTrigger>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить мысль?</AlertDialogTitle>
            <AlertDialogDescription>
              Вместе с мыслью будет удалён и её ИИ-разбор. Действие необратимо.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              onClick={onDelete}
              className="bg-rose-600 hover:bg-rose-700 dark:bg-rose-700 dark:hover:bg-rose-800"
            >
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
