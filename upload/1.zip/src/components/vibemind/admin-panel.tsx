"use client";

// VibeMind AdminPanel — full admin interface with tabs:
//   Dashboard | Users | AI Providers | Settings
// Replaces the previous stub.

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, Users, BarChart3, Settings, ArrowLeft, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCurrentUser } from "@/hooks/use-current-user";
import { cn } from "@/lib/utils";
import { AdminDashboard } from "./admin/admin-dashboard";
import { AdminUsers } from "./admin/admin-users";
import { AdminProviders } from "./admin/admin-providers";
import { AdminSettings } from "./admin/admin-settings";

type Tab = "dashboard" | "users" | "providers" | "settings";

interface AdminPanelProps {
  onExit: () => void;
}

const TABS: { key: Tab; label: string; icon: React.ElementType }[] = [
  { key: "dashboard", label: "Дашборд", icon: BarChart3 },
  { key: "users", label: "Пользователи", icon: Users },
  { key: "providers", label: "AI Провайдеры", icon: Cpu },
  { key: "settings", label: "Настройки", icon: Settings },
];

export function AdminPanel({ onExit }: AdminPanelProps) {
  const { data: user } = useCurrentUser();
  const [tab, setTab] = useState<Tab>("dashboard");

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
      {/* Header */}
      <div className="mb-6 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br from-stone-800 to-stone-950 text-white shadow-lg dark:from-stone-200 dark:to-stone-400 dark:text-stone-900">
            <Shield className="h-5 w-5" strokeWidth={2.2} />
          </div>
          <div>
            <h2 className="text-2xl font-semibold tracking-tight text-stone-900 dark:text-stone-50">
              Админ-панель
            </h2>
            <p className="mt-0.5 text-sm text-stone-500 dark:text-stone-400">
              {user?.email} · {user?.role}
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={onExit}
          className="rounded-full text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
        >
          <ArrowLeft className="mr-1.5 h-3.5 w-3.5" />
          <span className="hidden sm:inline">Назад</span>
        </Button>
      </div>

      {/* Tabs */}
      <div className="mb-6 flex gap-1 overflow-x-auto rounded-2xl border border-stone-200 bg-white p-1 dark:border-stone-800 dark:bg-stone-900">
        {TABS.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium transition-all",
                active
                  ? "bg-stone-900 text-white dark:bg-stone-50 dark:text-stone-900"
                  : "text-stone-600 hover:bg-stone-100 dark:text-stone-400 dark:hover:bg-stone-800",
              )}
            >
              <Icon className="h-4 w-4" />
              <span className="whitespace-nowrap">{t.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
        >
          {tab === "dashboard" && <AdminDashboard />}
          {tab === "users" && <AdminUsers />}
          {tab === "providers" && <AdminProviders />}
          {tab === "settings" && <AdminSettings />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
