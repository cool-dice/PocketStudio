"use client";

// VibeMind OnboardingTour — first-visit overlay that walks the user through
// the app's core flow in 4 steps. Shown only once (tracked via localStorage).

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  ChevronRight,
  ChevronLeft,
  PenLine,
  Sparkles,
  Clock,
  Wand2,
  Check,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "vibemind:onboarding-completed";

interface TourStep {
  icon: React.ElementType;
  title: string;
  desc: string;
  color: string;
  bgColor: string;
}

const STEPS: TourStep[] = [
  {
    icon: PenLine,
    title: "Захватите мысль",
    desc: "Запишите голос или опишите идею текстом — без форматирования. ИИ сам определит контекст: бизнес, покупки, психология или общий разбор.",
    color: "text-emerald-600 dark:text-emerald-400",
    bgColor: "bg-emerald-100 dark:bg-emerald-950/40",
  },
  {
    icon: Clock,
    title: "Разбор в очереди",
    desc: "После захвата ИИ-спарринг партнёр анализирует мысль и возвращает структурированный разбор в порядке живой очереди. Искусственное замедление можно включить для времени рефлексии.",
    color: "text-amber-600 dark:text-amber-400",
    bgColor: "bg-amber-100 dark:bg-amber-950/40",
  },
  {
    icon: Sparkles,
    title: "4-блочный разбор",
    desc: "Сильные стороны → риски → синтез → рекомендации. Раскрывается пошагово, как беседа со спарринг-партнёром. Можно копировать блоки и весь разбор целиком.",
    color: "text-rose-600 dark:text-rose-400",
    bgColor: "bg-rose-100 dark:bg-rose-950/40",
  },
  {
    icon: Wand2,
    title: "Чат-квест",
    desc: "После разбора запустите чат-квест — ИИ-наставник проработает рекомендации шаг за шагом. Диалог можно скопировать или скачать как .md.",
    color: "text-violet-600 dark:text-violet-400",
    bgColor: "bg-violet-100 dark:bg-violet-950/40",
  },
];

interface OnboardingTourProps {
  forceOpen?: boolean;
  onClose?: () => void;
}

export function OnboardingTour({ forceOpen, onClose }: OnboardingTourProps) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0);

  // Check localStorage on mount — show tour only on first visit.
  useEffect(() => {
    if (forceOpen) {
      // Use a microtask to avoid setState-in-effect lint warning.
      const raf = requestAnimationFrame(() => {
        setOpen(true);
        setStep(0);
      });
      return () => cancelAnimationFrame(raf);
    }
    try {
      const done = localStorage.getItem(STORAGE_KEY);
      if (!done) {
        // Small delay so it doesn't fight with page entrance animations.
        const t = setTimeout(() => setOpen(true), 800);
        return () => clearTimeout(t);
      }
    } catch {
      /* localStorage may be blocked */
    }
  }, [forceOpen]);

  const handleClose = () => {
    setOpen(false);
    try {
      localStorage.setItem(STORAGE_KEY, "1");
    } catch {
      /* ignore */
    }
    onClose?.();
  };

  const handleNext = () => {
    if (step < STEPS.length - 1) {
      setStep(step + 1);
    } else {
      handleClose();
    }
  };

  const handlePrev = () => {
    if (step > 0) setStep(step - 1);
  };

  const current = STEPS[step];
  const Icon = current.icon;
  const isLast = step === STEPS.length - 1;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-stone-950/60 p-4 backdrop-blur-md"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          <motion.div
            className="relative w-full max-w-md overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-2xl dark:border-stone-800 dark:bg-stone-900"
            initial={{ scale: 0.92, y: 16, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.96, y: 8, opacity: 0 }}
            transition={{ type: "spring", stiffness: 360, damping: 28 }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="Добро пожаловать в VibeMind"
          >
            {/* Close */}
            <button
              onClick={handleClose}
              className="absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full text-stone-400 transition-colors hover:bg-stone-100 hover:text-stone-700 dark:text-stone-500 dark:hover:bg-stone-800 dark:hover:text-stone-200"
              aria-label="Пропустить"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Step content */}
            <div className="p-6 sm:p-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.25 }}
                  className="flex flex-col items-center text-center"
                >
                  <motion.div
                    className={cn(
                      "flex h-16 w-16 items-center justify-center rounded-2xl",
                      current.bgColor,
                    )}
                    initial={{ scale: 0.6, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 0.1, type: "spring", stiffness: 320, damping: 18 }}
                  >
                    <Icon className={cn("h-8 w-8", current.color)} strokeWidth={1.8} />
                  </motion.div>
                  <h2 className="mt-5 text-xl font-semibold text-stone-900 dark:text-stone-50">
                    {current.title}
                  </h2>
                  <p className="mt-2 text-sm leading-relaxed text-stone-600 dark:text-stone-400">
                    {current.desc}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Footer: step dots + nav */}
            <div className="flex items-center justify-between border-t border-stone-100 bg-stone-50/50 px-6 py-4 dark:border-stone-800 dark:bg-stone-950/30">
              {/* Step dots */}
              <div className="flex items-center gap-1.5">
                {STEPS.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setStep(i)}
                    aria-label={`Шаг ${i + 1}`}
                    className={cn(
                      "h-1.5 rounded-full transition-all",
                      i === step
                        ? "w-6 bg-stone-900 dark:bg-stone-50"
                        : "w-1.5 bg-stone-300 hover:bg-stone-400 dark:bg-stone-700 dark:hover:bg-stone-600",
                    )}
                  />
                ))}
              </div>

              {/* Buttons */}
              <div className="flex items-center gap-2">
                {step > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handlePrev}
                    className="gap-1 rounded-full px-3 text-xs text-stone-600 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
                  >
                    <ChevronLeft className="h-3.5 w-3.5" />
                    Назад
                  </Button>
                )}
                <Button
                  onClick={handleNext}
                  size="sm"
                  className="gap-1.5 rounded-full bg-stone-900 px-4 text-xs text-white hover:bg-stone-800 dark:bg-stone-50 dark:text-stone-900 dark:hover:bg-stone-200"
                >
                  {isLast ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      Понятно
                    </>
                  ) : (
                    <>
                      Далее
                      <ChevronRight className="h-3.5 w-3.5" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
