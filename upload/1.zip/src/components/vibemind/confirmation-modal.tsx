"use client";

// Confirmation modal — "Мысль сохранена. Анализ готовится в очереди".
// Auto-dismisses after 2s (PRD section 1.1).

import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check } from "lucide-react";

interface ConfirmationModalProps {
  open: boolean;
  onClose: () => void;
  /** Subtitle shown under "Мысль сохранена". */
  subtitle?: string;
}

export function ConfirmationModal({ open, onClose, subtitle }: ConfirmationModalProps) {
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(onClose, 2000);
    return () => clearTimeout(t);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/40 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="mx-4 w-full max-w-md rounded-2xl border border-stone-200 bg-white p-7 shadow-2xl shadow-stone-900/10 dark:border-stone-800 dark:bg-stone-900"
            initial={{ scale: 0.92, y: 16, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.96, y: 8, opacity: 0 }}
            transition={{ type: "spring", stiffness: 360, damping: 26 }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-live="polite"
          >
            <div className="flex flex-col items-center text-center">
              <motion.div
                className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-950/70"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.1, type: "spring", stiffness: 380, damping: 18 }}
              >
                <Check className="h-7 w-7 text-emerald-600 dark:text-emerald-400" strokeWidth={3} />
              </motion.div>
              <h3 className="mt-4 text-lg font-semibold text-stone-900 dark:text-stone-50">
                Мысль сохранена
              </h3>
              <p className="mt-1 text-sm text-stone-500 dark:text-stone-400">
                {subtitle ?? "Анализ готовится в очереди"}
              </p>
              <div className="mt-5 h-1 w-full overflow-hidden rounded-full bg-stone-100 dark:bg-stone-800">
                <motion.div
                  className="h-full bg-gradient-to-r from-emerald-500 to-teal-500"
                  initial={{ width: "100%" }}
                  animate={{ width: "0%" }}
                  transition={{ duration: 2, ease: "linear" }}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

