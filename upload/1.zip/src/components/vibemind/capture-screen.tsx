"use client";

// VibeMind capture screen — the two dominant controls per PRD 1.1:
//   1. "Записать голос" button (mic + waveform + timer)
//   2. "Опишите мысль" textarea (auto-expands up to 5 lines)

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, Square, Send, Trash2, Loader2, AlertCircle, ClipboardPaste } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useVoiceRecorder } from "@/hooks/use-voice-recorder";
import { useCaptureInsight } from "@/hooks/use-insights";
import { cn } from "@/lib/utils";

interface CaptureScreenProps {
  onCaptured: () => void;
}

export function CaptureScreen({ onCaptured }: CaptureScreenProps) {
  const [text, setText] = useState("");
  const recorder = useVoiceRecorder();
  const capture = useCaptureInsight();
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  // Auto-grow textarea (PRD: up to 5 lines).
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    const lineHeight = 24;
    const maxHeight = lineHeight * 5 + 24; // ~5 lines + padding
    el.style.height = `${Math.min(el.scrollHeight, maxHeight)}px`;
  }, [text]);

  // Update tab title during recording for visual feedback.
  useEffect(() => {
    if (typeof document === "undefined") return;
    const originalTitle = "VibeMind — зафиксируй мысль, получи разбор в порядке очереди.";
    if (recorder.isRecording) {
      document.title = "● Запись — VibeMind";
    } else {
      document.title = originalTitle;
    }
    return () => {
      document.title = originalTitle;
    };
  }, [recorder.isRecording]);

  // Paste from clipboard helper (PRD 1.1: "Поддерживает вставку из буфера обмена").
  const handlePaste = async () => {
    try {
      const clip = await navigator.clipboard.readText();
      if (clip) setText((t) => (t ? t + " " + clip : clip));
    } catch {
      /* clipboard may be blocked; ignore */
    }
  };

  const handleStopAndSubmit = async () => {
    if (!recorder.isRecording) return;
    const { blob } = await recorder.stop();
    if (!blob) return;
    submit({ audioBlob: blob });
  };

  const submit = (vars: { text?: string; audioBlob?: Blob }) => {
    capture.mutate(vars, {
      onSuccess: () => {
        setText("");
        onCaptured();
      },
    });
  };

  const handleSubmitText = () => {
    if (!text.trim()) return;
    submit({ text });
  };

  // Spacebar to start/stop recording (only when not typing in the textarea).
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key !== " " || e.code !== "Space") return;
      const target = e.target as HTMLElement;
      if (target?.tagName === "INPUT" || target?.tagName === "TEXTAREA" || target?.isContentEditable) return;
      e.preventDefault();
      if (recorder.isRecording) {
        handleStopAndSubmit();
      } else if (!recorder.isInitializing && !capture.isPending) {
        recorder.start();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [recorder, capture.isPending, handleStopAndSubmit]);

  const hasContent = text.trim().length > 0 || recorder.isRecording;
  const isSubmitting = capture.isPending;
  const showRecorder = recorder.isRecording || recorder.isInitializing;

  return (
    <div className="relative mx-auto isolate flex w-full max-w-2xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-10">
      {/* Ambient background orbs (behind content via -z-10 within isolate) */}
      <div aria-hidden className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] overflow-hidden">
        <div className="absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-emerald-400/25 blur-3xl dark:bg-emerald-500/20" />
        <div className="absolute right-1/4 top-10 h-48 w-48 rounded-full bg-amber-400/25 blur-3xl dark:bg-amber-500/20" />
        <div className="absolute left-1/4 top-20 h-48 w-48 rounded-full bg-rose-400/20 blur-3xl dark:bg-rose-500/15" />
      </div>

      {/* Hero copy */}
      <div className="text-center">
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="mb-3 inline-flex items-center gap-1.5 rounded-full border border-stone-200 bg-white/70 px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-stone-500 backdrop-blur dark:border-stone-800 dark:bg-stone-900/70 dark:text-stone-400"
        >
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-75 motion-reduce:hidden" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
          </span>
          VibeMind · мысль за секунду
        </motion.div>
        <motion.h1
          className="text-balance bg-gradient-to-br from-stone-900 via-stone-800 to-stone-600 bg-clip-text text-3xl font-semibold tracking-tight text-transparent sm:text-4xl dark:from-stone-50 dark:via-stone-200 dark:to-stone-400"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          Что у вас на уме?
        </motion.h1>
        <motion.p
          className="mx-auto mt-3 max-w-md text-balance text-sm text-stone-500 sm:text-base dark:text-stone-400"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.05 }}
        >
          Запишите голос или опишите мысль текстом — ИИ-спарринг партнёр разберёт её и вернёт анализ в порядке очереди.
        </motion.p>
      </div>

      {/* Capture card */}
      <motion.div
        className="group relative overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-xl shadow-stone-900/5 transition-shadow duration-300 hover:shadow-2xl hover:shadow-emerald-600/10 dark:border-stone-800 dark:bg-stone-900 dark:shadow-black/30 dark:hover:shadow-emerald-500/10"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
      >
        {/* Soft ambient gradient backdrop */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-amber-500/5 transition-opacity duration-300 group-hover:from-emerald-500/10 group-hover:to-amber-500/10" />

        <div className="relative p-5 sm:p-7">
          {/* Voice recorder section */}
          <AnimatePresence mode="wait">
            {showRecorder ? (
              <motion.div
                key="recorder"
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-4 overflow-hidden"
              >
                <RecorderPanel
                  isRecording={recorder.isRecording}
                  isInitializing={recorder.isInitializing}
                  durationSec={recorder.durationSec}
                  levels={recorder.levels}
                  error={recorder.error}
                  onStop={handleStopAndSubmit}
                  onCancel={recorder.cancel}
                />
              </motion.div>
            ) : (
              <motion.div
                key="voice-button"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center"
              >
                <button
                  onClick={recorder.start}
                  disabled={isSubmitting}
                  aria-label="Записать голос"
                  className={cn(
                    "group relative flex h-24 w-24 items-center justify-center rounded-full",
                    "bg-gradient-to-br from-rose-500 via-rose-600 to-rose-700 text-white shadow-lg shadow-rose-600/30",
                    "transition-transform duration-200 hover:scale-105 active:scale-95",
                    "focus-visible:outline-none focus-visible:ring-4 focus-visible:ring-rose-300/50",
                    "disabled:cursor-not-allowed disabled:opacity-60",
                  )}
                >
                  {/* Pulsing rings (two layers for breathing effect) */}
                  <span className="absolute inset-0 rounded-full bg-rose-500/30 animate-ping motion-reduce:hidden" style={{ animationDuration: "2.5s" }} />
                  <span className="absolute -inset-2 rounded-full bg-rose-400/20 animate-ping motion-reduce:hidden" style={{ animationDuration: "3s", animationDelay: "0.5s" }} />
                  <Mic className="relative h-9 w-9" strokeWidth={2.2} />
                </button>
                <p className="mt-3 text-sm font-medium text-stone-700 dark:text-stone-300">
                  Записать голос
                </p>
                <p className="mt-0.5 text-xs text-stone-400 dark:text-stone-500">
                  Нажмите, чтобы начать запись
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Divider between voice and text */}
          <div className="my-5 flex items-center gap-3 text-xs uppercase tracking-wider text-stone-400 dark:text-stone-600">
            <div className="h-px flex-1 bg-stone-200 dark:bg-stone-800" />
            <span>или текстом</span>
            <div className="h-px flex-1 bg-stone-200 dark:bg-stone-800" />
          </div>

          {/* Text input */}
          <div className="relative">
            <Textarea
              ref={textareaRef}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Опишите мысль..."
              maxLength={5000}
              className={cn(
                "min-h-[88px] w-full resize-none rounded-2xl border-stone-200 bg-stone-50/50 p-4 text-base leading-6",
                "placeholder:text-stone-400 focus-visible:ring-2 focus-visible:ring-emerald-500/40",
                "dark:border-stone-800 dark:bg-stone-950/40 dark:placeholder:text-stone-600",
              )}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
                  e.preventDefault();
                  handleSubmitText();
                }
              }}
              aria-label="Опишите мысль"
            />
            <div className="mt-2 flex items-center justify-between">
              <button
                onClick={handlePaste}
                type="button"
                className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs text-stone-500 transition-colors hover:bg-stone-100 hover:text-stone-700 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-200"
              >
                <ClipboardPaste className="h-3.5 w-3.5" />
                Вставить
              </button>
              <span className={cn("text-xs tabular-nums", text.length > 4500 ? "text-amber-600" : "text-stone-400 dark:text-stone-500")}>
                {text.length} / 5000
              </span>
            </div>
          </div>

          {/* Submit row */}
          <div className="mt-5 flex items-center justify-end gap-2">
            {text.trim() && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setText("")}
                disabled={isSubmitting}
                className="text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200"
              >
                <Trash2 className="mr-1.5 h-3.5 w-3.5" />
                Очистить
              </Button>
            )}
            <Button
              onClick={handleSubmitText}
              disabled={!text.trim() || isSubmitting}
              className="gap-2 rounded-full bg-stone-900 px-5 text-sm font-medium hover:bg-stone-800 dark:bg-stone-50 dark:text-stone-900 dark:hover:bg-stone-200"
            >
              {isSubmitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              Отправить
              <kbd className="ml-1 hidden rounded border border-white/20 px-1.5 py-0.5 text-[10px] font-normal opacity-70 sm:inline-block">
                ⌘↵
              </kbd>
            </Button>
          </div>

          {capture.isError && (
            <motion.div
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-3 flex items-center gap-2 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700 dark:bg-rose-950/40 dark:text-rose-300"
            >
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{capture.error?.message ?? "Не удалось сохранить мысль"}</span>
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* Example thought chips — quick starters for inspiration */}
      {!hasContent && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="flex flex-wrap items-center justify-center gap-2"
        >
          <span className="text-xs text-stone-400 dark:text-stone-500">Например:</span>
          {[
            { text: "Хочу запустить SaaS для трекинга привычек", cat: "business" },
            { text: "Стоит ли покупать б/у велосипед за 15к", cat: "shopping" },
            { text: "Чувствую, что выгорел на работе", cat: "psychology" },
          ].map((ex, i) => (
            <button
              key={i}
              onClick={() => setText(ex.text)}
              className="rounded-full border border-stone-200 bg-white px-3 py-1 text-xs text-stone-600 transition-all hover:border-stone-300 hover:bg-stone-50 hover:shadow-sm dark:border-stone-700 dark:bg-stone-900 dark:text-stone-300 dark:hover:border-stone-600 dark:hover:bg-stone-800"
            >
              {ex.text}
            </button>
          ))}
        </motion.div>
      )}

      {/* Hint card */}
      <motion.div
        className="rounded-2xl border border-dashed border-stone-200 bg-stone-50/50 p-4 text-sm text-stone-500 dark:border-stone-800 dark:bg-stone-900/40 dark:text-stone-400"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <p className="font-medium text-stone-700 dark:text-stone-300">Как это работает</p>
        <ul className="mt-2.5 space-y-2">
          <li className="flex gap-2.5">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-[10px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">1</span>
            <span>Фиксируете мысль голосом или текстом — без форматирования.</span>
          </li>
          <li className="flex gap-2.5">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-amber-100 text-[10px] font-bold text-amber-700 dark:bg-amber-950/60 dark:text-amber-300">2</span>
            <span>ИИ определяет контекст: бизнес, покупки, психология или общий разбор.</span>
          </li>
          <li className="flex gap-2.5">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-teal-100 text-[10px] font-bold text-teal-700 dark:bg-teal-950/60 dark:text-teal-300">3</span>
            <span>Через час приходит структурированный разбор: сильные стороны, риски, синтез, рекомендации.</span>
          </li>
        </ul>
      </motion.div>

      {/* Spacer to keep footer pushed down naturally on short content */}
      <div aria-hidden className="h-2" />
      {!hasContent && <div aria-hidden className="hidden sm:block" style={{ minHeight: "10vh" }} />}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Recorder panel — waveform + timer + stop/cancel controls.
// ---------------------------------------------------------------------------

function RecorderPanel({
  isRecording,
  isInitializing,
  durationSec,
  levels,
  error,
  onStop,
  onCancel,
}: {
  isRecording: boolean;
  isInitializing: boolean;
  durationSec: number;
  levels: number[];
  error: string | null;
  onStop: () => void;
  onCancel: () => void;
}) {
  const mm = String(Math.floor(durationSec / 60)).padStart(2, "0");
  const ss = String(durationSec % 60).padStart(2, "0");

  return (
    <div className="rounded-2xl border border-rose-200 bg-rose-50/60 p-5 dark:border-rose-900/60 dark:bg-rose-950/20">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-500 opacity-75 motion-reduce:hidden" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-rose-600" />
          </span>
          <span className="text-sm font-medium text-rose-800 dark:text-rose-300">
            {isInitializing ? "Подготовка..." : "Идёт запись"}
          </span>
        </div>
        <span className="font-mono text-sm tabular-nums text-rose-800 dark:text-rose-300">
          {mm}:{ss}
        </span>
      </div>

      {/* Waveform */}
      <div className="mt-4 flex h-16 items-center justify-center gap-[3px]">
        {Array.from({ length: 40 }).map((_, i) => {
          const level = levels[i] ?? 0;
          const height = Math.max(4, Math.min(60, 4 + level * 56));
          return (
            <motion.div
              key={i}
              className="w-1 rounded-full bg-gradient-to-t from-rose-500 to-rose-400"
              animate={{ height }}
              transition={{ duration: 0.08 }}
              style={{ height: 4 }}
            />
          );
        })}
      </div>

      {error && (
        <p className="mt-2 text-center text-xs text-rose-700 dark:text-rose-400">{error}</p>
      )}

      <div className="mt-4 flex items-center justify-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={onCancel}
          disabled={!isRecording && !isInitializing}
          className="rounded-full text-stone-600 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800"
        >
          Отмена
        </Button>
        <Button
          onClick={onStop}
          disabled={!isRecording}
          className="gap-2 rounded-full bg-rose-600 px-5 text-sm font-medium text-white hover:bg-rose-700"
        >
          <Square className="h-3.5 w-3.5 fill-current" />
          Остановить и отправить
        </Button>
      </div>
    </div>
  );
}
