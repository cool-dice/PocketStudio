"use client";

// VibeMind footer — sticky to bottom of viewport.

import { Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-stone-200/70 bg-background/80 py-4 backdrop-blur-md dark:border-stone-800/70">
      <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-2 px-4 text-center text-xs text-stone-500 sm:flex-row sm:px-6 dark:text-stone-400">
        <p>
          VibeMind — зафиксируй мысль, получи разбор в порядке очереди.
        </p>
        <div className="flex items-center gap-3">
          {/* Keyboard shortcut hints */}
          <span className="hidden items-center gap-1.5 sm:flex">
            <kbd className="rounded border border-stone-300 bg-stone-100 px-1.5 py-0.5 font-mono text-[10px] text-stone-600 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300">N</kbd>
            <span className="text-stone-400 dark:text-stone-500">новая</span>
            <kbd className="rounded border border-stone-300 bg-stone-100 px-1.5 py-0.5 font-mono text-[10px] text-stone-600 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300">/</kbd>
            <span className="text-stone-400 dark:text-stone-500">поиск</span>
            <kbd className="rounded border border-stone-300 bg-stone-100 px-1.5 py-0.5 font-mono text-[10px] text-stone-600 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300">Esc</kbd>
            <span className="text-stone-400 dark:text-stone-500">назад</span>
          </span>
          <p className="flex items-center gap-1.5">
            <span>Сделано с</span>
            <Heart className="h-3 w-3 fill-rose-400 text-rose-400" />
            <span>для рефлексии</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
