"use client";

// VibeMind AudioPlayer — custom audio player with waveform bars + download.
// Replaces the native <audio> element in the analysis view.

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, Pause, Download, Volume2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface AudioPlayerProps {
  src: string;
  fileName?: string;
}

export function AudioPlayer({ src, fileName }: AudioPlayerProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [waveform, setWaveform] = useState<number[]>([]);

  // Generate a pseudo-waveform (deterministic, based on src hash for stability).
  useEffect(() => {
    // Simple hash → 32 bars.
    const bars: number[] = [];
    let hash = 0;
    for (let i = 0; i < src.length; i++) hash = (hash * 31 + src.charCodeAt(i)) & 0xffffffff;
    for (let i = 0; i < 32; i++) {
      hash = (hash * 1103515245 + 12345) & 0x7fffffff;
      bars.push(0.2 + (hash % 100) / 100 * 0.8);
    }
    // eslint-disable-next-line react-hooks/set-state-in-effect -- legitimate: computing deterministic waveform from src
    setWaveform(bars);
  }, [src]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onLoaded = () => setDuration(audio.duration || 0);
    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);

    audio.addEventListener("loadedmetadata", onLoaded);
    audio.addEventListener("timeupdate", onTimeUpdate);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);

    return () => {
      audio.removeEventListener("loadedmetadata", onLoaded);
      audio.removeEventListener("timeupdate", onTimeUpdate);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
    };
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) audio.pause();
    else audio.play().catch(() => {});
  };

  const seekTo = (fraction: number) => {
    const audio = audioRef.current;
    if (!audio || !duration) return;
    audio.currentTime = fraction * duration;
    setCurrentTime(audio.currentTime);
  };

  const handleDownload = () => {
    const a = document.createElement("a");
    a.href = src;
    a.download = fileName || "vibemind-audio.webm";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const progress = duration > 0 ? currentTime / duration : 0;
  const fmtTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${String(sec).padStart(2, "0")}`;
  };

  return (
    <div className="rounded-xl border border-stone-200 bg-stone-50/80 p-3 dark:border-stone-700 dark:bg-stone-950/40">
      <audio ref={audioRef} src={src} preload="metadata" className="hidden" />

      <div className="flex items-center gap-3">
        {/* Play/Pause button */}
        <button
          onClick={togglePlay}
          aria-label={isPlaying ? "Пауза" : "Воспроизвести"}
          className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-all",
            "bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm hover:scale-105 active:scale-95",
          )}
        >
          {isPlaying ? (
            <Pause className="h-4 w-4 fill-current" />
          ) : (
            <Play className="h-4 w-4 translate-x-0.5 fill-current" />
          )}
        </button>

        {/* Waveform + progress */}
        <div className="flex-1">
          <div
            className="flex h-10 items-center gap-[2px]"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const frac = (e.clientX - rect.left) / rect.width;
              seekTo(Math.max(0, Math.min(1, frac)));
            }}
            role="slider"
            aria-label="Прогресс аудио"
            aria-valuenow={Math.round(progress * 100)}
            aria-valuemin={0}
            aria-valuemax={100}
            tabIndex={0}
          >
            {waveform.map((h, i) => {
              const isPast = i / waveform.length <= progress;
              return (
                <motion.div
                  key={i}
                  className={cn(
                    "flex-1 rounded-full transition-colors",
                    isPast
                      ? "bg-gradient-to-t from-emerald-500 to-teal-400"
                      : "bg-stone-300 dark:bg-stone-600",
                  )}
                  style={{ height: `${h * 100}%` }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.01 }}
                />
              );
            })}
          </div>
          {/* Time labels */}
          <div className="mt-1 flex items-center justify-between text-[10px] tabular-nums text-stone-400 dark:text-stone-500">
            <span>{fmtTime(currentTime)}</span>
            <span>{fmtTime(duration)}</span>
          </div>
        </div>

        {/* Download button */}
        <button
          onClick={handleDownload}
          aria-label="Скачать аудио"
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-stone-400 transition-colors hover:bg-stone-100 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200"
        >
          <Download className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}
