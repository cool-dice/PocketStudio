"use client";

// VibeMind stats strip — shows aggregated counts above the insights list.
// Helps the user see at a glance: total, ready-to-read, in progress, errors,
// plus a per-category breakdown bar.

import { motion } from "framer-motion";
import {
  Inbox,
  CheckCircle2,
  Loader2,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useStats } from "@/hooks/use-insights";
import { categoryMeta } from "@/lib/categories";
import { cn } from "@/lib/utils";
import type { ContextType } from "@/lib/types";

interface StatsStripProps {
  /** Optional callback when a category chip is clicked (for filtering). */
  onCategoryClick?: (c: ContextType | "all") => void;
  activeCategory?: ContextType | "all";
}

export function StatsStrip({ onCategoryClick, activeCategory = "all" }: StatsStripProps) {
  const { data, isLoading } = useStats();

  if (isLoading || !data) {
    return (
      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-20 rounded-2xl" />
        ))}
      </div>
    );
  }

  const cards = [
    {
      key: "total",
      label: "Всего мыслей",
      value: data.total,
      icon: Inbox,
      color: "text-stone-700 dark:text-stone-300",
      bg: "bg-stone-100 dark:bg-stone-800/60",
    },
    {
      key: "ready",
      label: "Новые",
      value: data.ready,
      icon: CheckCircle2,
      color: "text-emerald-700 dark:text-emerald-300",
      bg: "bg-emerald-100 dark:bg-emerald-950/40",
    },
    {
      key: "pending",
      label: "В работе",
      value: data.pending,
      icon: Loader2,
      color: "text-amber-700 dark:text-amber-300",
      bg: "bg-amber-100 dark:bg-amber-950/40",
      spin: data.pending > 0,
    },
    {
      key: "error",
      label: "С ошибкой",
      value: data.error,
      icon: AlertTriangle,
      color: "text-rose-700 dark:text-rose-300",
      bg: "bg-rose-100 dark:bg-rose-950/40",
    },
  ];

  // Category breakdown for the bar.
  const cats: ContextType[] = ["business", "shopping", "psychology", "general"];
  const totalForBar = Math.max(
    1,
    cats.reduce((sum, c) => sum + (data.by_category[c] ?? 0), 0),
  );

  return (
    <div className="mb-5 space-y-3">
      {/* Number cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {cards.map((c, i) => {
          const Icon = c.icon;
          return (
            <motion.div
              key={c.key}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              className={cn(
                "relative overflow-hidden rounded-2xl border border-stone-200 bg-white p-3.5 dark:border-stone-800 dark:bg-stone-900",
                c.value > 0 && c.key === "ready" && "ring-1 ring-emerald-300/50 dark:ring-emerald-800/50",
              )}
            >
              <div className="flex items-center justify-between">
                <span className={cn("flex h-7 w-7 items-center justify-center rounded-lg", c.bg)}>
                  <Icon
                    className={cn("h-3.5 w-3.5", c.color, (c as any).spin && "animate-spin")}
                  />
                </span>
                <span className={cn("text-2xl font-semibold tabular-nums", c.color)}>
                  {c.value}
                </span>
              </div>
              <p className="mt-2 text-[11px] font-medium uppercase tracking-wider text-stone-500 dark:text-stone-400">
                {c.label}
              </p>
            </motion.div>
          );
        })}
      </div>

      {/* Category distribution bar */}
      {data.total > 0 && (
        <div className="rounded-2xl border border-stone-200 bg-white p-3.5 dark:border-stone-800 dark:bg-stone-900">
          <div className="mb-2 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-stone-500 dark:text-stone-400">
            <Sparkles className="h-3 w-3" />
            По контекстам
          </div>
          <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-stone-100 dark:bg-stone-800">
            {cats.map((c) => {
              const count = data.by_category[c] ?? 0;
              if (count === 0) return null;
              const meta = categoryMeta(c);
              const width = (count / totalForBar) * 100;
              return (
                <motion.div
                  key={c}
                  className={cn("h-full", meta.dot)}
                  initial={{ width: 0 }}
                  animate={{ width: `${width}%` }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  title={`${meta.label}: ${count}`}
                />
              );
            })}
          </div>
          {/* Category chips */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            <CategoryChip
              label="Все"
              count={data.total}
              active={activeCategory === "all"}
              onClick={() => onCategoryClick?.("all")}
            />
            {cats.map((c) => {
              const count = data.by_category[c] ?? 0;
              if (count === 0) return null;
              const meta = categoryMeta(c);
              const Icon = meta.icon;
              return (
                <CategoryChip
                  key={c}
                  label={meta.shortLabel}
                  icon={<Icon className="h-3 w-3" />}
                  count={count}
                  dot={meta.dot}
                  active={activeCategory === c}
                  onClick={() => onCategoryClick?.(c)}
                />
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function CategoryChip({
  label,
  count,
  icon,
  dot,
  active,
  onClick,
}: {
  label: string;
  count: number;
  icon?: React.ReactNode;
  dot?: string;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-all",
        active
          ? "border-stone-900 bg-stone-900 text-white dark:border-stone-50 dark:bg-stone-50 dark:text-stone-900"
          : "border-stone-200 bg-stone-50 text-stone-600 hover:border-stone-300 hover:bg-stone-100 dark:border-stone-700 dark:bg-stone-800/60 dark:text-stone-300 dark:hover:bg-stone-800",
      )}
    >
      {dot && <span className={cn("h-1.5 w-1.5 rounded-full", dot)} />}
      {icon}
      {label}
      <span className={cn("tabular-nums", active ? "opacity-80" : "opacity-60")}>{count}</span>
    </button>
  );
}
