"use client";

// VibeMind QuestDialog — a chat-style modal for the multi-turn "chat quest"
// that helps the user work through an insight's recommendations step by step.
// PRD 3.2.6.

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Send, Loader2, X, RotateCcw, Wand2, ArrowDown, Copy, Check, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  useQuestHistory,
  useStartOrSendQuest,
  useResetQuest,
} from "@/hooks/use-insights";
import type { QuestMessage } from "@/lib/types";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface QuestDialogProps {
  open: boolean;
  insightId: string | null;
  onClose: () => void;
}

export function QuestDialog({ open, insightId, onClose }: QuestDialogProps) {
  const { data, isLoading } = useQuestHistory(open ? insightId : null);
  const send = useStartOrSendQuest();
  const reset = useResetQuest();

  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [autoScroll, setAutoScroll] = useState(true);
  // Tracks whether we've kicked off the quest for this insight. Uses a ref
  // (not state) because it's only read inside effects/handlers, never in render.
  const startedRef = useRef<string | null>(null);
  // True while we're waiting for the background AI to persist its first reply
  // after the POST 202 returns (covers the gap between POST completion and the
  // first polled message arriving).
  const [awaitingFirstReply, setAwaitingFirstReply] = useState(false);

  const messages: QuestMessage[] = data?.messages ?? [];

  const resetLocalState = () => {
    startedRef.current = null;
    setAwaitingFirstReply(false);
    setInput("");
    setAutoScroll(true);
  };

  // The AI is "thinking" if: the POST mutation is pending, OR the last message
  // in history is from the user (background AI reply not yet persisted),
  // OR we're awaiting the first reply after starting.
  const lastMessage = messages[messages.length - 1];
  const aiThinking =
    send.isPending ||
    (!!lastMessage && lastMessage.role === "user") ||
    (messages.length === 0 && awaitingFirstReply);

  // Auto-start the quest when opening for an insight that has no messages yet.
  useEffect(() => {
    if (!open || !insightId) return;
    if (startedRef.current === insightId) return;
    if (isLoading) return;
    if (messages.length === 0 && !send.isPending) {
      startedRef.current = insightId;
      // eslint-disable-next-line react-hooks/set-state-in-effect -- legitimate: syncing with background AI job
      setAwaitingFirstReply(true);
      send.mutate({ insightId });
    }
  }, [open, insightId, isLoading, messages.length, send]);

  // Clear "awaitingFirstReply" once the first message arrives.
  useEffect(() => {
    if (messages.length > 0 && awaitingFirstReply) {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- legitimate: clearing a local flag when external polled data arrives
      setAwaitingFirstReply(false);
    }
  }, [messages.length, awaitingFirstReply]);

  const handleClose = () => {
    resetLocalState();
    onClose();
  };

  // Auto-scroll to bottom when new messages arrive (if user hasn't scrolled up).
  useEffect(() => {
    if (!autoScroll) return;
    const el = scrollRef.current;
    if (!el) return;
    const rafId = requestAnimationFrame(() => {
      // Guard: el may have been detached if component unmounted before rAF fired.
      if (el.isConnected) {
        el.scrollTop = el.scrollHeight;
      }
    });
    return () => cancelAnimationFrame(rafId);
  }, [messages, send.isPending, autoScroll]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    setAutoScroll(nearBottom);
  };

  const handleSend = () => {
    if (!insightId || !input.trim() || aiThinking) return;
    const msg = input;
    setInput("");
    setAutoScroll(true);
    send.mutate({ insightId, message: msg });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleReset = () => {
    if (!insightId) return;
    reset.mutate(insightId, {
      onSuccess: () => {
        startedRef.current = null;
        setAwaitingFirstReply(true);
        // Re-start the quest.
        setTimeout(() => {
          startedRef.current = insightId;
          send.mutate({ insightId });
        }, 100);
      },
    });
  };

  const [copiedConversation, setCopiedConversation] = useState(false);
  const handleCopyConversation = async () => {
    if (messages.length === 0) return;
    const text = messages
      .map((m) => {
        const role = m.role === "user" ? "Вы" : "Наставник";
        return `${role}:\n${m.content}`;
      })
      .join("\n\n---\n\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopiedConversation(true);
      toast.success("Диалог скопирован", { duration: 2000 });
      setTimeout(() => setCopiedConversation(false), 2000);
    } catch {
      toast.error("Не удалось скопировать");
    }
  };

  const handleExportMarkdown = () => {
    if (messages.length === 0) return;
    const date = new Date().toISOString().slice(0, 10);
    const md = [
      `# Чат-квест VibeMind`,
      ``,
      `_${date}_`,
      ``,
      ...messages.map((m) => {
        const role = m.role === "user" ? "Вы" : "Наставник";
        return `## ${role}\n\n${m.content}\n`;
      }),
    ].join("\n");
    const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vibemind-quest-${date}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success("Диалог сохранён как .md", { duration: 2500 });
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-end justify-center bg-stone-950/50 backdrop-blur-sm sm:items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleClose}
        >
          <motion.div
            className={cn(
              "relative flex h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-3xl border border-stone-200 bg-white shadow-2xl",
              "sm:h-[85vh] sm:rounded-3xl dark:border-stone-800 dark:bg-stone-900",
            )}
            initial={{ y: "100%", opacity: 0.5 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: "100%", opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 34 }}
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-label="Чат-квест для проработки идеи"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-200 bg-gradient-to-r from-violet-500/5 via-fuchsia-500/5 to-amber-500/5 px-4 py-3 dark:border-stone-800">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white shadow-sm shadow-fuchsia-600/20">
                  <Wand2 className="h-4.5 w-4.5" strokeWidth={2.2} />
                </div>
                <div className="leading-tight">
                  <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-50">
                    Чат-квест
                  </h3>
                  <p className="text-[11px] text-stone-500 dark:text-stone-400">
                    Пошаговая проработка идеи с ИИ-наставником
                  </p>
                  {/* Progress bar */}
                  {data && data.total_steps > 0 && (
                    <div className="mt-1 flex items-center gap-1.5">
                      <div className="h-1 w-20 overflow-hidden rounded-full bg-stone-200 dark:bg-stone-700">
                        <motion.div
                          className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500"
                          initial={{ width: 0 }}
                          animate={{
                            width: `${Math.min(100, (data.current_step / data.total_steps) * 100)}%`,
                          }}
                          transition={{ duration: 0.4 }}
                        />
                      </div>
                      <span className="text-[10px] tabular-nums text-stone-500 dark:text-stone-400">
                        {data.current_step}/{data.total_steps}
                      </span>
                      {data.is_completed && (
                        <span className="inline-flex items-center gap-0.5 rounded-full bg-emerald-100 px-1.5 py-0.5 text-[9px] font-bold text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300">
                          ✓ завершён
                        </span>
                      )}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-1">
                {messages.length > 0 && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleCopyConversation}
                      className="h-8 gap-1.5 rounded-full px-2.5 text-xs text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
                      aria-label="Скопировать диалог"
                    >
                      {copiedConversation ? (
                        <Check className="h-3.5 w-3.5 text-emerald-500" />
                      ) : (
                        <Copy className="h-3.5 w-3.5" />
                      )}
                      <span className="hidden sm:inline">
                        {copiedConversation ? "Скопировано" : "Копировать"}
                      </span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleExportMarkdown}
                      className="h-8 w-8 rounded-full text-stone-500 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-100"
                      aria-label="Сохранить как .md"
                      title="Сохранить как .md"
                    >
                      <Download className="h-3.5 w-3.5" />
                    </Button>
                  </>
                )}
                {messages.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleReset}
                    disabled={reset.isPending || send.isPending}
                    className="h-8 gap-1.5 rounded-full px-2.5 text-xs text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
                    aria-label="Начать заново"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">Заново</span>
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleClose}
                  className="h-8 w-8 rounded-full text-stone-500 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800"
                  aria-label="Закрыть"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Messages */}
            <div
              ref={scrollRef}
              onScroll={handleScroll}
              className="relative flex-1 space-y-4 overflow-y-auto bg-stone-50/50 px-4 py-5 dark:bg-stone-950/30"
              style={{ scrollbarGutter: "stable" }}
            >
              {isLoading && messages.length === 0 && (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-6 w-6 animate-spin text-stone-400" />
                </div>
              )}

              {/* Intro bubble — only shown before any AI message */}
              {messages.length === 0 && !send.isPending && !isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mx-auto flex max-w-md flex-col items-center gap-3 rounded-2xl border border-violet-100 bg-violet-50/50 p-6 text-center dark:border-violet-900/40 dark:bg-violet-950/20"
                >
                  <motion.div
                    animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                    className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white shadow-lg shadow-fuchsia-600/20"
                  >
                    <Sparkles className="h-6 w-6" />
                  </motion.div>
                  <p className="text-sm font-medium text-violet-900 dark:text-violet-100">
                    Запускаю квест
                  </p>
                  <p className="text-xs text-violet-600 dark:text-violet-400">
                    ИИ-наставник задаст первый вопрос по рекомендациям из разбора...
                  </p>
                </motion.div>
              )}

              <AnimatePresence initial={false}>
                {messages.map((m, i) => (
                  <MessageBubble key={m.id} message={m} index={i} />
                ))}
              </AnimatePresence>

              {/* Completion banner — shown when quest is marked complete */}
              {data?.is_completed && !aiThinking && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mx-auto flex max-w-md items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-center dark:border-emerald-900/60 dark:bg-emerald-950/20"
                >
                  <Check className="h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400" />
                  <div className="text-left">
                    <p className="text-sm font-medium text-emerald-900 dark:text-emerald-100">
                      Квест завершён
                    </p>
                    <p className="text-xs text-emerald-700 dark:text-emerald-300">
                      Разбор обновлён с учётом вашего диалога. Откройте анализ, чтобы увидеть обновлённую версию.
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Typing indicator — shows while the AI is generating its reply */}
              {aiThinking && (
                <motion.div
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex justify-start"
                >
                  <div className="flex items-center gap-1.5 rounded-2xl rounded-tl-sm border border-stone-200 bg-white px-4 py-3 shadow-sm dark:border-stone-800 dark:bg-stone-900">
                    <span className="flex gap-1">
                      {[0, 1, 2].map((d) => (
                        <motion.span
                          key={d}
                          className="h-1.5 w-1.5 rounded-full bg-violet-400 dark:bg-violet-500"
                          animate={{ opacity: [0.3, 1, 0.3], y: [0, -2, 0] }}
                          transition={{
                            duration: 0.9,
                            repeat: Infinity,
                            delay: d * 0.15,
                          }}
                        />
                      ))}
                    </span>
                  </div>
                </motion.div>
              )}

              {/* Scroll-to-bottom button */}
              <AnimatePresence>
                {!autoScroll && messages.length > 0 && (
                  <motion.button
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    onClick={() => {
                      setAutoScroll(true);
                      const el = scrollRef.current;
                      if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
                    }}
                    className="sticky bottom-2 left-full mx-4 flex h-9 w-9 translate-x-0 items-center justify-center rounded-full border border-stone-200 bg-white text-stone-600 shadow-md hover:text-stone-900 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300 dark:hover:text-stone-100"
                    aria-label="Прокрутить вниз"
                  >
                    <ArrowDown className="h-4 w-4" />
                  </motion.button>
                )}
              </AnimatePresence>
            </div>

            {/* Input */}
            <div className="border-t border-stone-200 bg-white px-3 py-3 dark:border-stone-800 dark:bg-stone-900">
              <div className="flex items-end gap-2">
                <div className="relative flex-1">
                  <textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Напишите ответ..."
                    rows={1}
                    disabled={aiThinking}
                    aria-label="Ваш ответ"
                    className={cn(
                      "max-h-32 min-h-[44px] w-full resize-none rounded-2xl border border-stone-200 bg-stone-50 px-4 py-2.5 pr-2 text-sm leading-relaxed",
                      "placeholder:text-stone-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/50",
                      "disabled:opacity-60 dark:border-stone-700 dark:bg-stone-950/40 dark:placeholder:text-stone-600",
                    )}
                    style={{
                      height: "auto",
                    }}
                    ref={(el) => {
                      if (el) {
                        el.style.height = "auto";
                        el.style.height = `${Math.min(el.scrollHeight, 128)}px`;
                      }
                    }}
                  />
                </div>
                <Button
                  onClick={handleSend}
                  disabled={!input.trim() || aiThinking}
                  className="h-11 w-11 shrink-0 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 p-0 text-white shadow-sm shadow-fuchsia-600/20 hover:from-violet-600 hover:to-fuchsia-700"
                  aria-label="Отправить"
                >
                  {aiThinking ? (
                    <Loader2 className="h-4.5 w-4.5 animate-spin" />
                  ) : (
                    <Send className="h-4.5 w-4.5" />
                  )}
                </Button>
              </div>
              <p className="mt-1.5 text-center text-[10px] text-stone-400 dark:text-stone-600">
                Enter — отправить · Shift+Enter — перенос строки
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ---------------------------------------------------------------------------

function MessageBubble({ message, index }: { message: QuestMessage; index: number }) {
  const isUser = message.role === "user";
  const time = new Date(message.created_at).toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
  });
  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.25, delay: Math.min(index * 0.02, 0.15) }}
      className={cn("flex flex-col", isUser ? "items-end" : "items-start")}
    >
      <div
        className={cn(
          "max-w-[85%] whitespace-pre-line rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm",
          isUser
            ? "rounded-tr-sm bg-stone-900 text-white dark:bg-stone-50 dark:text-stone-900"
            : "rounded-tl-sm border border-stone-200 bg-white text-stone-800 dark:border-stone-800 dark:bg-stone-900 dark:text-stone-100",
        )}
      >
        {!isUser && (
          <div className="mb-1 flex items-center gap-1.5 text-[10px] font-medium uppercase tracking-wider text-violet-500 dark:text-violet-400">
            <Sparkles className="h-3 w-3" />
            Наставник
          </div>
        )}
        {message.content}
      </div>
      <span className="mt-1 px-1 text-[10px] text-stone-400 dark:text-stone-600">{time}</span>
    </motion.div>
  );
}
