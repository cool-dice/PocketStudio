"use client";

// VibeMind analysis view — step-by-step disclosure (PRD 3.2).
//
// Flow:
//   1. Positive block visible by default ("Слушай, это круто, потому что...")
//   2. Button "В чем подвох?" reveals negative block ("А теперь трезвый взгляд...")
//   3. 300ms later, final block auto-appears ("Синтез: главное")
//   4. Button "Запустить чат-квест для проработки идеи" → stub toast "Функция в разработке"
//
// Enhancements (webDevReview round):
//   - Copy-to-clipboard button on every analysis block
//   - "Раскрыть всё / Свернуть" toggle in the toolbar
//   - Retry button in the error state
//   - Share-copy entire analysis button

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Loader2,
  Clock,
  Sparkles,
  AlertTriangle,
  Lightbulb,
  CheckCircle2,
  Wand2,
  Quote,
  ListChecks,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  RotateCw,
  Share2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAnalysis, useRetryInsight } from "@/hooks/use-insights";
import { QuestDialog } from "./quest-dialog";
import { AudioPlayer } from "./audio-player";
import { categoryMeta } from "@/lib/categories";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface AnalysisViewProps {
  insightId: string;
  onBack: () => void;
}

export function AnalysisView({ insightId, onBack }: AnalysisViewProps) {
  const { data, isLoading, isError } = useAnalysis(insightId);
  const [questOpen, setQuestOpen] = useState(false);

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6 sm:px-6 sm:py-8">
      <Toolbar onBack={onBack} analysis={data?.status === "ready" ? data : null} />

      {isLoading ? (
        <AnalysisSkeleton />
      ) : isError ? (
        <ErrorState onBack={onBack} />
      ) : data?.status === "analysis_not_ready" ? (
        <WaitingState
          scheduledAt={data.scheduled_delivery_at}
          eta={data.estimated_time}
          insightStatus={data.insight_status}
        />
      ) : data?.status === "error" ? (
        <ErrorState message={data.message} onBack={onBack} insightId={insightId} />
      ) : data?.status === "ready" ? (
        <ReadyState analysis={data} onOpenQuest={() => setQuestOpen(true)} />
      ) : null}

      <QuestDialog
        open={questOpen}
        insightId={questOpen ? insightId : null}
        onClose={() => setQuestOpen(false)}
      />
    </div>
  );
}

// ---------------------------------------------------------------------------

function Toolbar({
  onBack,
  analysis,
}: {
  onBack: () => void;
  analysis: Extract<import("@/lib/types").AnalysisResponse, { status: "ready" }> | null;
}) {
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    if (!analysis) return;
    const text = [
      `Контекст: ${categoryMeta(analysis.context_type).label}`,
      ``,
      `Мысль:`,
      analysis.original_text,
      ``,
      `Слушай, это круто, потому что...`,
      analysis.positive_block,
      ``,
      `А теперь трезвый взгляд...`,
      analysis.negative_block,
      ``,
      `Синтез: главное`,
      analysis.final_block,
      ``,
      `Что сделать дальше:`,
      analysis.recommendations,
    ].join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Весь разбор скопирован в буфер обмена");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Не удалось скопировать");
    }
  };

  return (
    <div className="mb-5 flex items-center justify-between gap-2">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm text-stone-600 transition-colors hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-100"
      >
        <ArrowLeft className="h-4 w-4" />
        Назад к списку
      </button>
      {analysis && (
        <Button
          variant="ghost"
          size="sm"
          onClick={handleShare}
          className="gap-1.5 rounded-full text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
          aria-label="Скопировать весь разбор"
        >
          {copied ? (
            <Check className="h-3.5 w-3.5 text-emerald-500" />
          ) : (
            <Share2 className="h-3.5 w-3.5" />
          )}
          <span className="hidden sm:inline">{copied ? "Скопировано" : "Копировать разбор"}</span>
        </Button>
      )}
    </div>
  );
}

function AnalysisSkeleton() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-7 w-48" />
      <Skeleton className="h-24 w-full rounded-2xl" />
      <Skeleton className="h-40 w-full rounded-2xl" />
    </div>
  );
}

function ErrorState({
  message,
  onBack,
  insightId,
}: {
  message?: string;
  onBack: () => void;
  insightId?: string;
}) {
  const retry = useRetryInsight();
  return (
    <div className="flex flex-col items-center rounded-3xl border border-rose-200 bg-rose-50/50 p-10 text-center dark:border-rose-900/60 dark:bg-rose-950/20">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 280, damping: 20 }}
        className="flex h-14 w-14 items-center justify-center rounded-full bg-rose-100 dark:bg-rose-950/60"
      >
        <AlertTriangle className="h-7 w-7 text-rose-600 dark:text-rose-400" />
      </motion.div>
      <h3 className="mt-4 text-lg font-semibold text-stone-900 dark:text-stone-50">
        {message ?? "Не удалось обработать мысль"}
      </h3>
      <p className="mt-1 max-w-sm text-sm text-stone-500 dark:text-stone-400">
        ИИ-спарринг партнёр столкнулся с ошибкой. Попробуйте запустить анализ снова или вернитесь позже.
      </p>
      <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
        {insightId && (
          <Button
            onClick={() => retry.mutate(insightId)}
            disabled={retry.isPending}
            className="gap-1.5 rounded-full bg-rose-600 text-white hover:bg-rose-700 dark:bg-rose-700 dark:hover:bg-rose-800"
          >
            {retry.isPending ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <RotateCw className="h-3.5 w-3.5" />
            )}
            Запустить заново
          </Button>
        )}
        <Button
          variant="outline"
          onClick={onBack}
          className="rounded-full border-stone-300 dark:border-stone-700"
        >
          Вернуться к списку
        </Button>
      </div>
    </div>
  );
}

function WaitingState({
  scheduledAt,
  eta,
  insightStatus,
}: {
  scheduledAt: string | null;
  eta: string | null;
  insightStatus?: string;
}) {
  const isProcessing = insightStatus === "processing";
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-3xl border border-stone-200 bg-white p-10 text-center shadow-sm dark:border-stone-800 dark:bg-stone-900"
    >
      {/* Ambient gradient */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-emerald-500/5" />
      <div className="relative flex flex-col items-center">
        <div className="relative">
          <motion.div
            animate={{ scale: [1, 1.08, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="flex h-16 w-16 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-950/50"
          >
            {isProcessing ? (
              <Loader2 className="h-7 w-7 animate-spin text-amber-600 dark:text-amber-400" />
            ) : (
              <Clock className="h-7 w-7 text-amber-600 dark:text-amber-400" />
            )}
          </motion.div>
          <span className="absolute -right-1 -top-1 h-4 w-4 rounded-full bg-amber-400 ring-2 ring-background" />
        </div>
        <h3 className="mt-5 text-lg font-semibold text-stone-900 dark:text-stone-50">
          {isProcessing ? "Анализируем вашу мысль..." : "Разбор в пути"}
        </h3>
        <p className="mt-1 max-w-sm text-sm text-stone-500 dark:text-stone-400">
          {isProcessing
            ? "ИИ-спарринг партнёр разбирает идею. Это занимает несколько секунд."
            : "Анализ готов, но ещё не пришло время доставки. Загляните чуть позже — мы пришлём уведомление."}
        </p>
        {eta && (
          <div className="mt-4 inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-medium text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
            <Clock className="h-3 w-3" />
            {eta}
          </div>
        )}
        {scheduledAt && (
          <p className="mt-3 text-xs text-stone-400 dark:text-stone-500">
            Запланированная доставка:{" "}
            {new Date(scheduledAt).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}
          </p>
        )}
      </div>
    </motion.div>
  );
}

// ---------------------------------------------------------------------------

function ReadyState({
  analysis,
  onOpenQuest,
}: {
  analysis: Extract<
    import("@/lib/types").AnalysisResponse,
    { status: "ready" }
  >;
  onOpenQuest: () => void;
}) {
  const meta = categoryMeta(analysis.context_type);
  const Icon = meta.icon;

  const [showNegative, setShowNegative] = useState(false);
  const [showFinal, setShowFinal] = useState(false);
  const [showRevision, setShowRevision] = useState(false);

  const hasRevision = analysis.has_revision && analysis.revision;
  const activeAnalysis = showRevision && analysis.revision
    ? {
        positive_block: analysis.revision.positive_block,
        negative_block: analysis.revision.negative_block,
        final_block: analysis.revision.final_block,
        recommendations: analysis.revision.recommendations,
      }
    : {
        positive_block: analysis.positive_block,
        negative_block: analysis.negative_block,
        final_block: analysis.final_block,
        recommendations: analysis.recommendations,
      };

  // PRD 3.2.5: 300ms after negative appears, final block auto-appears.
  useEffect(() => {
    if (!showNegative) return;
    const t = setTimeout(() => setShowFinal(true), 300);
    return () => clearTimeout(t);
  }, [showNegative]);

  const allRevealed = showNegative && showFinal;

  const handleRevealAll = () => {
    if (allRevealed) {
      // Collapse: reset both states together (avoids effect-driven cascading render).
      setShowNegative(false);
      setShowFinal(false);
    } else {
      setShowNegative(true);
      setShowFinal(true);
    }
  };

  const recs = activeAnalysis.recommendations
    .split(/\n+/)
    .map((l) => l.trim())
    .filter(Boolean);

  return (
    <div className="space-y-5">
      {/* Header card */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className={cn(
          "relative overflow-hidden rounded-3xl border border-stone-200 bg-white p-5 shadow-sm dark:border-stone-800 dark:bg-stone-900 sm:p-6",
        )}
      >
        <div className={cn("pointer-events-none absolute inset-0 bg-gradient-to-br", meta.gradient)} />
        <div className="relative flex items-start gap-4">
          <div
            className={cn(
              "flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border bg-white dark:bg-stone-950",
              meta.badge,
            )}
          >
            <Icon className="h-6 w-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className={cn("border-transparent", meta.badge)}>
                {meta.label}
              </Badge>
              <span className="inline-flex items-center gap-1 text-xs text-stone-400 dark:text-stone-500">
                <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                {showRevision ? "Обновлённый разбор" : "Разбор готов"}
              </span>
              {/* Revision toggle — only if quest completed */}
              {hasRevision && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowRevision((v) => !v)}
                  className={cn(
                    "h-7 gap-1 rounded-full px-2.5 text-[11px]",
                    showRevision
                      ? "bg-violet-100 text-violet-700 hover:bg-violet-200 dark:bg-violet-950/60 dark:text-violet-300"
                      : "text-stone-500 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800",
                  )}
                  aria-pressed={showRevision}
                >
                  <Sparkles className="h-3 w-3" />
                  {showRevision ? "Оригинал" : "После квеста"}
                </Button>
              )}
              {/* Reveal-all toggle */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRevealAll}
                className="ml-auto h-7 gap-1 rounded-full px-2.5 text-[11px] text-stone-500 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-100"
                aria-label={allRevealed ? "Свернуть" : "Раскрыть всё"}
              >
                {allRevealed ? (
                  <ChevronUp className="h-3 w-3" />
                ) : (
                  <ChevronDown className="h-3 w-3" />
                )}
                {allRevealed ? "Свернуть" : "Раскрыть всё"}
              </Button>
            </div>

            {/* Progress dots: 1=positive(always), 2=negative, 3=final, 4=recommendations */}
            <div className="mt-2 flex items-center gap-1.5">
              <span className="text-[10px] font-medium uppercase tracking-wider text-stone-400 dark:text-stone-500">
                Прогресс:
              </span>
              <div className="flex items-center gap-1">
                <ProgressDot active label="Сильные стороны" color="bg-emerald-500" />
                <ProgressConnector active={showNegative} />
                <ProgressDot active={showNegative} label="Риски" color="bg-rose-500" />
                <ProgressConnector active={showFinal} />
                <ProgressDot active={showFinal} label="Синтез" color="bg-amber-500" />
                <ProgressConnector active={showFinal} />
                <ProgressDot active={showFinal} label="Действия" color="bg-teal-500" />
              </div>
            </div>

            <div className="mt-3 rounded-2xl bg-stone-50/80 p-3 dark:bg-stone-950/40">
              <div className="mb-1 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-stone-400 dark:text-stone-500">
                <Quote className="h-3 w-3" />
                Ваша мысль
              </div>
              <p className="text-sm leading-relaxed text-stone-700 dark:text-stone-200">
                {analysis.original_text}
              </p>
              {analysis.has_audio && analysis.audio_url && (
                <div className="mt-3">
                  <AudioPlayer src={analysis.audio_url} fileName={`vibemind-${analysis.insight_id}.webm`} />
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Block 1 — Positive (always visible) */}
      <AnalysisBlock
        icon={<Sparkles className="h-4 w-4" />}
        title="Слушай, это круто, потому что..."
        accent="emerald"
        copyText={activeAnalysis.positive_block}
      >
        <p className="whitespace-pre-line text-sm leading-relaxed text-stone-700 dark:text-stone-200">
          {activeAnalysis.positive_block}
        </p>
      </AnalysisBlock>

      {/* Button: "В чем подвох?" */}
      <AnimatePresence>
        {!showNegative && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            className="flex justify-center"
          >
            <Button
              variant="outline"
              onClick={() => setShowNegative(true)}
              className="gap-2 rounded-full border-stone-300 bg-white px-5 text-stone-700 hover:bg-stone-50 hover:text-stone-900 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-200 dark:hover:bg-stone-800"
            >
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              В чем подвох?
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Block 2 — Negative */}
      <AnimatePresence>
        {showNegative && (
          <motion.div
            initial={{ opacity: 0, y: 12, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            <AnalysisBlock
              icon={<AlertTriangle className="h-4 w-4" />}
              title="А теперь трезвый взгляд..."
              accent="rose"
              copyText={activeAnalysis.negative_block}
            >
              <p className="whitespace-pre-line text-sm leading-relaxed text-stone-700 dark:text-stone-200">
                {activeAnalysis.negative_block}
              </p>
            </AnalysisBlock>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Block 3 — Final synthesis (auto after 300ms) */}
      <AnimatePresence>
        {showFinal && (
          <motion.div
            initial={{ opacity: 0, y: 12, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            <AnalysisBlock
              icon={<Lightbulb className="h-4 w-4" />}
              title="Синтез: главное"
              accent="amber"
              highlighted
              copyText={activeAnalysis.final_block}
            >
              <p className="whitespace-pre-line text-sm leading-relaxed text-stone-800 dark:text-stone-100">
                {activeAnalysis.final_block}
              </p>
            </AnalysisBlock>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Block 4 — Recommendations */}
      <AnimatePresence>
        {showFinal && (
          <motion.div
            initial={{ opacity: 0, y: 12, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.4, delay: 0.1, ease: "easeOut" }}
          >
            <AnalysisBlock
              icon={<ListChecks className="h-4 w-4" />}
              title="Что сделать дальше"
              accent="teal"
              copyText={activeAnalysis.recommendations}
            >
              <ol className="space-y-2">
                {recs.map((r, i) => (
                  <li
                    key={i}
                    className="flex gap-3 text-sm leading-relaxed text-stone-700 dark:text-stone-200"
                  >
                    <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-teal-100 text-[11px] font-bold text-teal-800 dark:bg-teal-950/60 dark:text-teal-300">
                      {i + 1}
                    </span>
                    <span className="whitespace-pre-line">{r.replace(/^[\d.\-–)\s]+/, "")}</span>
                  </li>
                ))}
              </ol>
            </AnalysisBlock>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quest button (PRD 3.2.6) */}
      <AnimatePresence>
        {showFinal && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center pt-2"
          >
            <Button
              onClick={onOpenQuest}
              className="gap-2 rounded-full bg-gradient-to-r from-violet-500 to-fuchsia-600 px-5 text-white shadow-sm shadow-fuchsia-600/20 hover:from-violet-600 hover:to-fuchsia-700"
            >
              <Wand2 className="h-4 w-4" />
              Запустить чат-квест для проработки идеи
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Reusable analysis block container with fade-in animation + copy button.

const ACCENT_STYLES = {
  emerald: {
    iconWrap: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300",
    bar: "bg-emerald-500",
  },
  rose: {
    iconWrap: "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300",
    bar: "bg-rose-500",
  },
  amber: {
    iconWrap: "bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300",
    bar: "bg-amber-500",
  },
  teal: {
    iconWrap: "bg-teal-100 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300",
    bar: "bg-teal-500",
  },
} as const;

function AnalysisBlock({
  icon,
  title,
  accent,
  highlighted,
  copyText,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  accent: keyof typeof ACCENT_STYLES;
  highlighted?: boolean;
  copyText?: string;
  children: React.ReactNode;
}) {
  const styles = ACCENT_STYLES[accent];
  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className={cn(
        "group relative overflow-hidden rounded-3xl border bg-white p-5 shadow-sm dark:bg-stone-900 sm:p-6",
        highlighted
          ? "border-amber-200 ring-1 ring-amber-200/50 dark:border-amber-900/60 dark:ring-amber-900/30"
          : "border-stone-200 dark:border-stone-800",
      )}
    >
      <div className={cn("absolute inset-y-0 left-0 w-1", styles.bar)} />
      <div className="relative flex items-center gap-2.5">
        <div className={cn("flex h-8 w-8 items-center justify-center rounded-lg", styles.iconWrap)}>
          {icon}
        </div>
        <h3 className="flex-1 text-sm font-semibold tracking-tight text-stone-900 dark:text-stone-50">
          {title}
        </h3>
        {copyText && <CopyButton text={copyText} label={title} />}
      </div>
      <div className="mt-3 pl-11">{children}</div>
    </motion.section>
  );
}

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const handle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Скопировано в буфер обмена", { description: label, duration: 2000 });
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Не удалось скопировать");
    }
  };
  return (
    <button
      onClick={handle}
      aria-label={`Скопировать: ${label}`}
      className="flex h-6 w-6 items-center justify-center rounded-md text-stone-400 opacity-0 transition-all hover:bg-stone-100 hover:text-stone-700 focus-visible:opacity-100 group-hover:opacity-100 dark:text-stone-500 dark:hover:bg-stone-800 dark:hover:text-stone-200 motion-safe:group-hover:opacity-100 [@media(hover:none)]:opacity-60"
    >
      {copied ? (
        <Check className="h-3.5 w-3.5 text-emerald-500" />
      ) : (
        <Copy className="h-3.5 w-3.5" />
      )}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Progress indicator helpers for the analysis view header.

function ProgressDot({
  active,
  label,
  color,
}: {
  active: boolean;
  label: string;
  color: string;
}) {
  return (
    <span
      title={label}
      className={cn(
        "h-2 w-2 rounded-full transition-all",
        active ? color : "bg-stone-200 dark:bg-stone-700",
        active && "scale-110",
      )}
    />
  );
}

function ProgressConnector({ active }: { active: boolean }) {
  return (
    <span
      className={cn(
        "h-px w-3 transition-colors",
        active ? "bg-stone-400 dark:bg-stone-500" : "bg-stone-200 dark:bg-stone-700",
      )}
    />
  );
}
