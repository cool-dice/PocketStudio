"use client";

// VibeMind StatsDashboard — insights-over-time bar chart + category donut.
// Collapsible panel shown above the insights list when the user has insights.

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ChevronDown,
  TrendingUp,
  PieChart,
  BarChart3,
  Sparkles,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useStats } from "@/hooks/use-insights";
import { categoryMeta } from "@/lib/categories";
import { cn } from "@/lib/utils";
import type { ContextType } from "@/lib/types";

const CATS: ContextType[] = ["business", "shopping", "psychology", "general"];

export function StatsDashboard() {
  const { data, isLoading } = useStats();
  const [open, setOpen] = useState(false);

  if (isLoading || !data || data.total === 0) return null;

  const maxDayCount = Math.max(1, ...data.over_time.map((d) => d.count));
  const totalForDonut = Math.max(
    1,
    CATS.reduce((s, c) => s + (data.by_category[c] ?? 0), 0),
  );

  // Donut segments — compute with reduce to avoid mutating during render.
  const donutSegments = CATS.reduce<{
    segs: Array<{ cat: ContextType; count: number; label: string; color: string; dashArray: string; dashOffset: number }>;
    offset: number;
  }>(
    (acc, c) => {
      const count = data.by_category[c] ?? 0;
      if (count === 0) return acc;
      const meta = categoryMeta(c);
      const fraction = count / totalForDonut;
      const dashLength = fraction * 100;
      acc.segs.push({
        cat: c,
        count,
        label: meta.shortLabel,
        color: meta.dot,
        dashArray: `${dashLength} ${100 - dashLength}`,
        dashOffset: -acc.offset,
      });
      acc.offset += dashLength;
      return acc;
    },
    { segs: [], offset: 0 },
  ).segs;

  return (
    <div className="mb-4 overflow-hidden rounded-2xl border border-stone-200 bg-white dark:border-stone-800 dark:bg-stone-900">
      {/* Header / toggle */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between px-4 py-3 text-left transition-colors hover:bg-stone-50 dark:hover:bg-stone-950/30"
        aria-expanded={open}
        aria-label="Показать/скрыть статистику"
      >
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-stone-100 dark:bg-stone-800">
            <BarChart3 className="h-3.5 w-3.5 text-stone-600 dark:text-stone-300" />
          </span>
          <span className="text-sm font-medium text-stone-900 dark:text-stone-50">
            Статистика
          </span>
          {data.favorite > 0 && (
            <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-medium text-amber-800 dark:bg-amber-950/40 dark:text-amber-300">
              <Sparkles className="h-2.5 w-2.5" />
              {data.favorite} избр.
            </span>
          )}
        </div>
        <motion.div
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDown className="h-4 w-4 text-stone-400 dark:text-stone-500" />
        </motion.div>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="overflow-hidden"
          >
            <div className="grid gap-4 px-4 pb-4 sm:grid-cols-2">
              {/* Insights over time — bar chart */}
              <div className="rounded-xl border border-stone-100 bg-stone-50/50 p-3 dark:border-stone-800 dark:bg-stone-950/30">
                <div className="mb-3 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-stone-500 dark:text-stone-400">
                  <TrendingUp className="h-3 w-3" />
                  Мысли за 14 дней
                </div>
                <div className="flex h-24 items-end justify-between gap-1">
                  {data.over_time.map((d, i) => (
                    <div
                      key={d.date}
                      className="group relative flex flex-1 flex-col items-center justify-end"
                      style={{ height: "100%" }}
                    >
                      <div className="absolute -top-6 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded-md bg-stone-900 px-1.5 py-0.5 text-[9px] font-medium text-white group-hover:block dark:bg-stone-700 z-10">
                        {d.label}: {d.count}
                      </div>
                      <motion.div
                        initial={{ height: 0 }}
                        animate={{ height: `${(d.count / maxDayCount) * 100}%` }}
                        transition={{ delay: i * 0.02, duration: 0.3 }}
                        className={cn(
                          "w-full rounded-t-sm",
                          d.count > 0
                            ? "bg-gradient-to-t from-emerald-500 to-teal-400"
                            : "bg-stone-200 dark:bg-stone-800",
                        )}
                        style={{
                          minHeight: d.count > 0 ? 3 : 1,
                        }}
                      />
                      {/* Today highlight */}
                      {i === data.over_time.length - 1 && (
                        <span className="absolute -bottom-4 text-[8px] text-emerald-600 dark:text-emerald-400">
                          сегодня
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Category distribution — donut */}
              <div className="rounded-xl border border-stone-100 bg-stone-50/50 p-3 dark:border-stone-800 dark:bg-stone-950/30">
                <div className="mb-3 flex items-center gap-1.5 text-[11px] font-medium uppercase tracking-wider text-stone-500 dark:text-stone-400">
                  <PieChart className="h-3 w-3" />
                  По контекстам
                </div>
                <div className="flex items-center gap-4">
                  {/* SVG donut */}
                  <div className="relative h-20 w-20 shrink-0">
                    <svg viewBox="0 0 36 36" className="h-full w-full -rotate-90">
                      <circle
                        cx="18"
                        cy="18"
                        r="15.9155"
                        fill="none"
                        className="stroke-stone-200 dark:stroke-stone-800"
                        strokeWidth="3.5"
                      />
                      {donutSegments.map((seg) => (
                        <circle
                          key={seg!.cat}
                          cx="18"
                          cy="18"
                          r="15.9155"
                          fill="none"
                          strokeWidth="3.5"
                          strokeDasharray={seg!.dashArray}
                          strokeDashoffset={seg!.dashOffset}
                          className={cn("transition-all", seg!.color)}
                          style={{ stroke: "currentColor" }}
                        >
                          <title>{`${seg!.label}: ${seg!.count}`}</title>
                        </circle>
                      ))}
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-lg font-semibold tabular-nums text-stone-900 dark:text-stone-50">
                        {data.total}
                      </span>
                      <span className="text-[8px] uppercase tracking-wider text-stone-400 dark:text-stone-500">
                        всего
                      </span>
                    </div>
                  </div>
                  {/* Legend */}
                  <div className="flex-1 space-y-1.5">
                    {CATS.map((c) => {
                      const count = data.by_category[c] ?? 0;
                      const meta = categoryMeta(c);
                      const pct = Math.round((count / totalForDonut) * 100);
                      return (
                        <div key={c} className="flex items-center gap-2">
                          <span className={cn("h-2 w-2 shrink-0 rounded-full", meta.dot)} />
                          <span className="flex-1 text-[11px] text-stone-600 dark:text-stone-300">
                            {meta.shortLabel}
                          </span>
                          <span className="text-[11px] font-medium tabular-nums text-stone-500 dark:text-stone-400">
                            {count}
                            <span className="ml-1 text-stone-400 dark:text-stone-600">({pct}%)</span>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
