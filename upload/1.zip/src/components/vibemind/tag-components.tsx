"use client";

// VibeMind TagChip — small colored chip displaying a tag name with optional remove button.
// VibeMind TagPicker — popover for adding/removing tags on an insight.

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Tag, Plus, X, Check } from "lucide-react";
import {
  useTags,
  useCreateTag,
  useAttachTag,
  useDetachTag,
} from "@/hooks/use-tags";
import { cn } from "@/lib/utils";
import type { InsightTag } from "@/lib/types";

// Tag color palette → Tailwind classes.
const TAG_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  stone: {
    bg: "bg-stone-100 dark:bg-stone-800/60",
    text: "text-stone-700 dark:text-stone-300",
    dot: "bg-stone-400",
  },
  emerald: {
    bg: "bg-emerald-100 dark:bg-emerald-950/40",
    text: "text-emerald-700 dark:text-emerald-300",
    dot: "bg-emerald-500",
  },
  amber: {
    bg: "bg-amber-100 dark:bg-amber-950/40",
    text: "text-amber-700 dark:text-amber-300",
    dot: "bg-amber-500",
  },
  rose: {
    bg: "bg-rose-100 dark:bg-rose-950/40",
    text: "text-rose-700 dark:text-rose-300",
    dot: "bg-rose-500",
  },
  violet: {
    bg: "bg-violet-100 dark:bg-violet-950/40",
    text: "text-violet-700 dark:text-violet-300",
    dot: "bg-violet-500",
  },
  teal: {
    bg: "bg-teal-100 dark:bg-teal-950/40",
    text: "text-teal-700 dark:text-teal-300",
    dot: "bg-teal-500",
  },
};

export function tagColorClasses(color: string) {
  return TAG_COLORS[color] ?? TAG_COLORS.stone;
}

// ---------------------------------------------------------------------------

export function TagChip({
  tag,
  onRemove,
  onClick,
  size = "sm",
}: {
  tag: InsightTag;
  onRemove?: () => void;
  onClick?: () => void;
  size?: "sm" | "xs";
}) {
  const c = tagColorClasses(tag.color);
  const padding = size === "xs" ? "px-1.5 py-0 text-[9px]" : "px-2 py-0.5 text-[10px]";
  return (
    <span
      onClick={onClick}
      className={cn(
        "inline-flex items-center gap-1 rounded-full font-medium",
        c.bg,
        c.text,
        onClick && "cursor-pointer hover:opacity-80",
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", c.dot)} />
      {tag.name}
      {onRemove && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          className="ml-0.5 rounded-full p-0.5 hover:bg-black/10 dark:hover:bg-white/10"
          aria-label={`Убрать тег ${tag.name}`}
        >
          <X className="h-2.5 w-2.5" />
        </button>
      )}
    </span>
  );
}

// ---------------------------------------------------------------------------

export function TagPicker({
  insightId,
  insightTags,
  children,
}: {
  insightId: string;
  insightTags: InsightTag[];
  children?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [newTagName, setNewTagName] = useState("");
  const popoverRef = useRef<HTMLDivElement | null>(null);
  const { data: tagsData } = useTags();
  const createTag = useCreateTag();
  const attachTag = useAttachTag();
  const detachTag = useDetachTag();

  const allTags = tagsData?.data ?? [];
  const attachedIds = new Set(insightTags.map((t) => t.id));

  // Close on outside click.
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const handleToggle = (tagId: string, attached: boolean) => {
    if (attached) {
      detachTag.mutate({ insightId, tagId });
    } else {
      attachTag.mutate({ insightId, tagId });
    }
  };

  const handleCreate = () => {
    const name = newTagName.trim();
    if (!name) return;
    attachTag.mutate(
      { insightId, name },
      {
        onSuccess: () => setNewTagName(""),
      },
    );
  };

  return (
    <div className="relative" ref={popoverRef}>
      <button
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        className="inline-flex items-center gap-1"
        aria-label="Управление тегами"
      >
        {children ?? (
          <span className="inline-flex items-center gap-0.5 rounded-full border border-stone-200 px-1.5 py-0.5 text-[10px] text-stone-500 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-400 dark:hover:bg-stone-800">
            <Plus className="h-2.5 w-2.5" />
            Тег
          </span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.97 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 top-full z-20 mt-1 w-56 rounded-xl border border-stone-200 bg-white p-2 shadow-lg dark:border-stone-700 dark:bg-stone-900"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Existing tags list */}
            {allTags.length > 0 ? (
              <div className="mb-2 max-h-40 space-y-0.5 overflow-y-auto">
                {allTags.map((t) => {
                  const attached = attachedIds.has(t.id);
                  const c = tagColorClasses(t.color);
                  return (
                    <button
                      key={t.id}
                      onClick={() => handleToggle(t.id, attached)}
                      className={cn(
                        "flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs transition-colors",
                        "hover:bg-stone-100 dark:hover:bg-stone-800",
                      )}
                    >
                      <span className={cn("h-2 w-2 shrink-0 rounded-full", c.dot)} />
                      <span className="flex-1 text-stone-700 dark:text-stone-200">
                        {t.name}
                      </span>
                      <span className="text-[9px] text-stone-400">{t.count}</span>
                      {attached && <Check className="h-3 w-3 text-emerald-500" />}
                    </button>
                  );
                })}
              </div>
            ) : (
              <p className="mb-2 px-1 py-2 text-center text-[11px] text-stone-400 dark:text-stone-500">
                Пока нет тегов
              </p>
            )}

            {/* Create new tag */}
            <div className="border-t border-stone-100 pt-2 dark:border-stone-800">
              <div className="flex items-center gap-1">
                <input
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleCreate();
                    }
                  }}
                  placeholder="Новый тег..."
                  maxLength={30}
                  className="h-7 flex-1 rounded-md border border-stone-200 bg-stone-50 px-2 text-xs placeholder:text-stone-400 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-stone-300 dark:border-stone-700 dark:bg-stone-950/40 dark:placeholder:text-stone-600"
                />
                <button
                  onClick={handleCreate}
                  disabled={!newTagName.trim() || attachTag.isPending}
                  className="flex h-7 w-7 items-center justify-center rounded-md bg-stone-900 text-white disabled:opacity-40 dark:bg-stone-50 dark:text-stone-900"
                  aria-label="Создать тег"
                >
                  <Plus className="h-3 w-3" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
