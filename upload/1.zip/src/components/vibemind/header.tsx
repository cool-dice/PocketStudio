"use client";

// VibeMind header — sticky top bar with logo + view switcher + theme toggle.

import { Brain, PenLine, ListChecks, HelpCircle, Shield } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "./theme-toggle";
import { cn } from "@/lib/utils";

export type View = "capture" | "list";

interface HeaderProps {
  view: View;
  onViewChange: (v: View) => void;
  pendingCount: number;
  onHelp?: () => void;
  isAdmin?: boolean;
  onAdmin?: () => void;
}

export function Header({ view, onViewChange, pendingCount, onHelp, isAdmin, onAdmin }: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-stone-200/70 bg-background/80 backdrop-blur-md dark:border-stone-800/70">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4 sm:px-6">
        <button
          className="group flex items-center gap-2.5"
          onClick={() => onViewChange("capture")}
          aria-label="VibeMind — на главный экран"
        >
          <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 via-emerald-600 to-teal-700 shadow-sm shadow-emerald-600/20">
            <Brain className="h-5 w-5 text-white" strokeWidth={2.2} />
            <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-amber-400 ring-2 ring-background" />
          </span>
          <span className="flex flex-col leading-none">
            <span className="text-base font-semibold tracking-tight text-stone-900 dark:text-stone-50">
              VibeMind
            </span>
            <span className="text-[10px] font-medium uppercase tracking-[0.18em] text-stone-400 dark:text-stone-500">
              thought · reflect · act
            </span>
          </span>
        </button>

        <nav className="flex items-center gap-1">
          <NavButton
            active={view === "capture"}
            onClick={() => onViewChange("capture")}
            icon={<PenLine className="h-4 w-4" />}
            label="Захват"
          />
          <NavButton
            active={view === "list"}
            onClick={() => onViewChange("list")}
            icon={<ListChecks className="h-4 w-4" />}
            label="Мои мысли"
            badge={pendingCount > 0 ? pendingCount : undefined}
          />
          <div className="ml-1 hidden h-6 w-px bg-stone-200 dark:bg-stone-800 sm:block" />
          {onHelp && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onHelp}
              className="h-9 w-9 rounded-full text-stone-500 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-100"
              aria-label="Справка (?)"
              title="Справка"
            >
              <HelpCircle className="h-4 w-4" />
            </Button>
          )}
          {isAdmin && onAdmin && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onAdmin}
              className="h-9 w-9 rounded-full text-stone-500 hover:bg-stone-900 hover:text-white dark:text-stone-400 dark:hover:bg-stone-50 dark:hover:text-stone-900"
              aria-label="Админ-панель"
              title="Админ-панель"
            >
              <Shield className="h-4 w-4" />
            </Button>
          )}
          <div className="ml-1 hidden sm:block">
            <ThemeToggle />
          </div>
        </nav>
      </div>
      <div className="sm:hidden flex justify-end gap-1 px-4 pb-2 -mt-1">
        {onHelp && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onHelp}
            className="h-9 w-9 rounded-full text-stone-500 hover:bg-stone-100 hover:text-stone-900 dark:text-stone-400 dark:hover:bg-stone-800 dark:hover:text-stone-100"
            aria-label="Справка"
          >
            <HelpCircle className="h-4 w-4" />
          </Button>
        )}
        {isAdmin && onAdmin && (
          <Button
            variant="ghost"
            size="icon"
            onClick={onAdmin}
            className="h-9 w-9 rounded-full text-stone-500 hover:bg-stone-900 hover:text-white dark:text-stone-400 dark:hover:bg-stone-50 dark:hover:text-stone-900"
            aria-label="Админ-панель"
          >
            <Shield className="h-4 w-4" />
          </Button>
        )}
        <ThemeToggle />
      </div>
    </header>
  );
}

function NavButton({
  active,
  onClick,
  icon,
  label,
  badge,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  badge?: number;
}) {
  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={onClick}
      className={cn(
        "relative gap-1.5 rounded-full px-3 text-sm font-medium",
        active
          ? "bg-stone-900 text-white hover:bg-stone-900 hover:text-white dark:bg-stone-50 dark:text-stone-900 dark:hover:bg-stone-50 dark:hover:text-stone-900"
          : "text-stone-600 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100",
      )}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
      {badge !== undefined && (
        <motion.span
          key={badge}
          initial={{ scale: 0.6 }}
          animate={{ scale: 1 }}
          className="ml-0.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-amber-400 px-1 text-[10px] font-bold text-amber-950"
        >
          {badge}
        </motion.span>
      )}
    </Button>
  );
}
