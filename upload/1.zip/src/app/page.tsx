"use client";

// VibeMind — main page.
// Single-route app: view switching happens via client-side state.
//   view: "capture" | "list" | "analysis"

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Header, type View } from "@/components/vibemind/header";
import { Footer } from "@/components/vibemind/footer";
import { CaptureScreen } from "@/components/vibemind/capture-screen";
import { InsightsList } from "@/components/vibemind/insights-list";
import { AnalysisView } from "@/components/vibemind/analysis-view";
import { ConfirmationModal } from "@/components/vibemind/confirmation-modal";
import { HelpDialog } from "@/components/vibemind/help-dialog";
import { OnboardingTour } from "@/components/vibemind/onboarding-tour";
import { AdminPanel } from "@/components/vibemind/admin-panel";
import { useInsights, useReadyNotifications, useRequestNotificationPermission } from "@/hooks/use-insights";
import { useKeyboardShortcuts } from "@/hooks/use-keyboard-shortcuts";
import { useCurrentUser } from "@/hooks/use-current-user";

type AppView = View | "analysis" | "admin";

export default function Home() {
  const [view, setView] = useState<AppView>("capture");
  const [activeInsightId, setActiveInsightId] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [tourOpen, setTourOpen] = useState(false);

  const { data } = useInsights();
  const { data: currentUser } = useCurrentUser();
  useReadyNotifications();
  useRequestNotificationPermission();

  const isAdmin = currentUser?.role === "admin";

  // Pending (not-yet-ready) count for the header badge.
  const pendingCount =
    data?.data.filter(
      (i) => i.status === "pending" || i.status === "processing" || (i.status === "processed" && !i.is_ready),
    ).length ?? 0;

  const openInsight = useCallback((id: string) => {
    setActiveInsightId(id);
    setView("analysis");
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const goCapture = useCallback(() => {
    setView("capture");
    setActiveInsightId(null);
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const goList = useCallback(() => {
    setView("list");
    setActiveInsightId(null);
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const goAdmin = useCallback(() => {
    setView("admin");
    setActiveInsightId(null);
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const exitAdmin = useCallback(() => {
    setView("capture");
    if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const handleHeaderNav = (v: View) => {
    if (v === "capture") goCapture();
    else goList();
  };

  // Global keyboard shortcuts.
  useKeyboardShortcuts({
    onNew: goCapture,
    onSearch: () => {
      if (view !== "list") goList();
      // Focus the search input after the list renders.
      setTimeout(() => {
        const el = document.querySelector<HTMLInputElement>('input[aria-label="Поиск по мыслям"]');
        el?.focus();
      }, 100);
    },
    onEscape: () => {
      if (helpOpen) {
        setHelpOpen(false);
      } else if (confirmOpen) {
        setConfirmOpen(false);
      } else if (view === "admin") {
        exitAdmin();
      } else if (view === "analysis") {
        goList();
      }
    },
    onHelp: () => setHelpOpen((v) => !v),
  });

  return (
    <div className="flex min-h-screen flex-col bg-stone-50 text-stone-900 dark:bg-stone-950 dark:text-stone-100">
      <Header
        view={view === "analysis" || view === "admin" ? "list" : view}
        onViewChange={handleHeaderNav}
        pendingCount={pendingCount}
        onHelp={() => setHelpOpen(true)}
        isAdmin={isAdmin}
        onAdmin={isAdmin ? goAdmin : undefined}
      />

      <main className="flex-1">
        <AnimatePresence mode="wait">
          {view === "capture" && (
            <motion.div
              key="capture"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <CaptureScreen onCaptured={() => setConfirmOpen(true)} />
            </motion.div>
          )}

          {view === "list" && (
            <motion.div
              key="list"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <InsightsList onOpenInsight={openInsight} onGoCapture={goCapture} />
            </motion.div>
          )}

          {view === "analysis" && activeInsightId && (
            <motion.div
              key="analysis"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <AnalysisView insightId={activeInsightId} onBack={goList} />
            </motion.div>
          )}

          {view === "admin" && (
            <motion.div
              key="admin"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              <AdminPanel onExit={exitAdmin} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <Footer />

      <ConfirmationModal open={confirmOpen} onClose={() => setConfirmOpen(false)} />
      <HelpDialog
        open={helpOpen}
        onClose={() => setHelpOpen(false)}
        onStartTour={() => {
          setHelpOpen(false);
          setTourOpen(true);
        }}
      />
      <OnboardingTour forceOpen={tourOpen} onClose={() => setTourOpen(false)} />
    </div>
  );
}
