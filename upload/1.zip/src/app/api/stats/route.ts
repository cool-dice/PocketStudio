// GET /api/stats
// Aggregated counts for the dashboard + insights-over-time + category distribution.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const CONTEXT_TYPES = ["business", "shopping", "psychology", "general"] as const;

export async function GET() {
  try {
    const user = await getMvpUser();

    const [total, byStatusRows, byCategoryRows, readyCount, pendingCount, errorCount, favoriteCount, allInsights] =
      await Promise.all([
        db.insight.count({ where: { userId: user.id } }),
        db.insight.groupBy({ by: ["status"], _count: true, where: { userId: user.id } }),
        db.insight.groupBy({
          by: ["contextType"],
          _count: true,
          where: { userId: user.id },
        }),
        db.insight.count({
          where: {
            userId: user.id,
            status: "processed",
            notified: false,
            scheduledDeliveryAt: { lte: new Date() },
          },
        }),
        db.insight.count({
          where: {
            userId: user.id,
            status: { in: ["pending", "processing"] },
          },
        }),
        db.insight.count({
          where: { userId: user.id, status: "error" },
        }),
        db.insight.count({
          where: { userId: user.id, favorite: true },
        }),
        // Fetch all insights with createdAt + contextType for the over-time chart.
        db.insight.findMany({
          where: { userId: user.id },
          select: { createdAt: true, contextType: true },
          orderBy: { createdAt: "asc" },
        }),
      ]);

    const byStatus: Record<string, number> = {};
    byStatusRows.forEach((r) => (byStatus[r.status] = r._count));

    const byCategory: Record<string, number> = {};
    byCategoryRows.forEach((r) => {
      const key = r.contextType ?? "uncategorized";
      byCategory[key] = (byCategory[key] ?? 0) + r._count;
    });

    // Build last-14-days over-time series.
    const now = new Date();
    const days: { date: string; label: string; count: number; byCategory: Record<string, number> }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      const dayKey = d.toISOString().slice(0, 10); // YYYY-MM-DD
      const label = d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" });
      days.push({ date: dayKey, label, count: 0, byCategory: {} });
    }

    const dayMap = new Map(days.map((d) => [d.date, d]));
    for (const ins of allInsights) {
      const dayKey = ins.createdAt.toISOString().slice(0, 10);
      const day = dayMap.get(dayKey);
      if (!day) continue; // older than 14 days
      day.count++;
      const cat = ins.contextType ?? "general";
      day.byCategory[cat] = (day.byCategory[cat] ?? 0) + 1;
    }

    return NextResponse.json({
      total,
      ready: readyCount,
      pending: pendingCount,
      error: errorCount,
      favorite: favoriteCount,
      by_status: byStatus,
      by_category: byCategory,
      over_time: days,
    });
  } catch (err: any) {
    console.error("[stats] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
