// PATCH  /api/admin/users/[id] — update role { role: 'user' | 'admin' }
// DELETE /api/admin/users/[id] — delete user (cascade)

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { ROLES } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const { id } = await params;
    const body = await req.json();
    const role = String(body?.role ?? "");
    if (role !== ROLES.USER && role !== ROLES.ADMIN) {
      return NextResponse.json({ error: "role must be 'user' or 'admin'" }, { status: 400 });
    }
    const updated = await db.user.update({ where: { id }, data: { role } });
    return NextResponse.json({ data: { id: updated.id, role: updated.role } });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const { id } = await params;
    if (id === user.id) {
      return NextResponse.json({ error: "Cannot delete yourself" }, { status: 400 });
    }
    await db.user.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
