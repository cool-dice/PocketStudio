// GET /api/admin/users — list all users with counts.
// POST /api/admin/users — create a user (stub for future auth).

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { ROLES } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const users = await db.user.findMany({
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        createdAt: true,
        _count: { select: { insights: true } },
      },
    });
    return NextResponse.json({
      data: users.map((u) => ({
        id: u.id,
        email: u.email,
        name: u.name,
        role: u.role,
        insights_count: u._count.insights,
        created_at: u.createdAt.toISOString(),
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
