// GET   /api/admin/providers — list all AI providers
// POST  /api/admin/providers — create { name, baseUrl, apiKey, model, priority?, enabled?, kind? }

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { ROLES } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const providers = await db.aIProvider.findMany({ orderBy: { priority: "asc" } });
    // Mask API keys in response (show only last 4 chars).
    return NextResponse.json({
      data: providers.map((p) => ({
        ...p,
        apiKey: p.apiKey ? `••••${p.apiKey.slice(-4)}` : "",
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const body = await req.json();
    const name = String(body?.name ?? "").trim();
    const baseUrl = String(body?.baseUrl ?? "").trim();
    const apiKey = String(body?.apiKey ?? "").trim();
    const model = String(body?.model ?? "").trim();
    if (!name || !baseUrl || !apiKey || !model) {
      return NextResponse.json({ error: "name, baseUrl, apiKey, model required" }, { status: 400 });
    }
    // Validate baseUrl looks like a URL.
    try {
      new URL(baseUrl);
    } catch {
      return NextResponse.json({ error: "baseUrl must be a valid URL" }, { status: 400 });
    }
    // Check for duplicate name.
    const existing = await db.aIProvider.findFirst({ where: { name } });
    if (existing) {
      return NextResponse.json({ error: `Provider "${name}" already exists` }, { status: 409 });
    }
    const priority = Number(body?.priority) || 10;
    const enabled = body?.enabled !== false;
    const kind = String(body?.kind ?? "chat");
    const provider = await db.aIProvider.create({
      data: { name, baseUrl, apiKey, model, priority, enabled, kind },
    });
    return NextResponse.json({ data: { ...provider, apiKey: `••••${provider.apiKey.slice(-4)}` } }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
