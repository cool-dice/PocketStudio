// PATCH  /api/admin/providers/[id] — update { name?, baseUrl?, apiKey?, model?, priority?, enabled?, kind? }
// DELETE /api/admin/providers/[id] — remove

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { ROLES } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const { id } = await params;
    const body = await req.json();
    const data: Record<string, unknown> = {};
    if (typeof body?.name === "string") data.name = body.name.trim();
    if (typeof body?.baseUrl === "string") {
      const baseUrl = body.baseUrl.trim();
      try {
        new URL(baseUrl);
      } catch {
        return NextResponse.json({ error: "baseUrl must be a valid URL" }, { status: 400 });
      }
      data.baseUrl = baseUrl;
    }
    if (typeof body?.apiKey === "string" && body.apiKey.trim()) data.apiKey = body.apiKey.trim();
    if (typeof body?.model === "string") data.model = body.model.trim();
    if (typeof body?.priority === "number") data.priority = body.priority;
    if (typeof body?.enabled === "boolean") data.enabled = body.enabled;
    if (typeof body?.kind === "string") data.kind = body.kind;
    const updated = await db.aIProvider.update({ where: { id }, data });
    return NextResponse.json({ data: { ...updated, apiKey: `••••${updated.apiKey.slice(-4)}` } });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    const { id } = await params;
    await db.aIProvider.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
