// GET  /api/admin/settings — all settings
// PUT  /api/admin/settings — bulk update { key: value, ... }

import { NextRequest, NextResponse } from "next/server";
import { getMvpUser } from "@/lib/user";
import { getAllSettings, setSettings, bustSettingsCache } from "@/lib/settings";
import { ROLES } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    const settings = await getAllSettings();
    return NextResponse.json({ settings });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }
    const body = await req.json();
    if (!body || typeof body !== "object") {
      return NextResponse.json({ error: "Body required" }, { status: 400 });
    }
    // Coerce values + validate known numeric settings.
    const NUMERIC_KEYS = new Set(["deliveryDelayMs", "maxTextLength", "maxAudioSize"]);
    const MIN_VALUES: Record<string, number> = {
      maxTextLength: 100,
      maxAudioSize: 1024,
    };
    const cleaned: Record<string, string> = {};
    for (const [k, v] of Object.entries(body)) {
      const strVal = String(v);
      if (NUMERIC_KEYS.has(k)) {
        const n = Number(strVal);
        if (!Number.isFinite(n) || n < 0) {
          return NextResponse.json({ error: `Setting "${k}" must be a non-negative number` }, { status: 400 });
        }
        const min = MIN_VALUES[k];
        if (min !== undefined && n < min) {
          return NextResponse.json({ error: `Setting "${k}" must be at least ${min}` }, { status: 400 });
        }
      }
      cleaned[k] = strVal;
    }
    await setSettings(cleaned);
    await bustSettingsCache();
    return NextResponse.json({ success: true, settings: await getAllSettings() });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
