// GET /api/admin/stats — system-wide statistics for the admin dashboard.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { ROLES } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getMvpUser();
    if (user.role !== ROLES.ADMIN) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const [totalUsers, totalInsights, totalAnalyses, totalQuestMessages, totalTags, totalProviders, byStatus, errors] =
      await Promise.all([
        db.user.count(),
        db.insight.count(),
        db.analysisResult.count(),
        db.questMessage.count(),
        db.tag.count(),
        db.aIProvider.count(),
        db.insight.groupBy({ by: ["status"], _count: true }),
        db.errorLog.count(),
      ]);

    const statusMap: Record<string, number> = {};
    byStatus.forEach((s) => (statusMap[s.status] = s._count));

    // Derived metrics.
    const errorRate = totalInsights > 0 ? Math.round((errors / totalInsights) * 1000) / 10 : 0; // %
    const successRate = totalInsights > 0 ? Math.round(((statusMap.processed ?? 0) / totalInsights) * 1000) / 10 : 0;
    const analysisCoverage = totalInsights > 0 ? Math.round((totalAnalyses / totalInsights) * 1000) / 10 : 0;

    return NextResponse.json({
      total_users: totalUsers,
      total_insights: totalInsights,
      total_analyses: totalAnalyses,
      total_quest_messages: totalQuestMessages,
      total_tags: totalTags,
      total_providers: totalProviders,
      total_errors: errors,
      error_rate_pct: errorRate,
      success_rate_pct: successRate,
      analysis_coverage_pct: analysisCoverage,
      by_status: statusMap,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message ?? "Internal error" }, { status: 500 });
  }
}
