// GET /api — VibeMind API health check.

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  let dbOk = false;
  try {
    await db.user.count();
    dbOk = true;
  } catch {
    /* ignore */
  }
  return NextResponse.json({
    name: "VibeMind API",
    status: "ok",
    db: dbOk ? "ok" : "error",
    time: new Date().toISOString(),
  });
}
