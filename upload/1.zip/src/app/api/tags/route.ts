// GET  /api/tags — list all tags for the user (with insight counts)
// POST /api/tags — create a new tag { name, color? }
// DELETE /api/tags/[id] — delete a tag

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const user = await getMvpUser();
    const tags = await db.tag.findMany({
      where: { userId: user.id },
      orderBy: { name: "asc" },
      include: { _count: { select: { insights: true } } },
    });
    return NextResponse.json({
      data: tags.map((t) => ({
        id: t.id,
        name: t.name,
        color: t.color,
        count: t._count.insights,
        created_at: t.createdAt.toISOString(),
      })),
    });
  } catch (err: any) {
    console.error("[tags GET] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getMvpUser();
    const body = await req.json();
    const name = typeof body?.name === "string" ? body.name.trim().slice(0, 30) : "";
    if (!name) {
      return NextResponse.json({ error: "Tag name required" }, { status: 400 });
    }
    const color = typeof body?.color === "string" ? body.color : "stone";

    // Upsert: if tag with this name exists for the user, return it.
    const tag = await db.tag.upsert({
      where: { userId_name: { userId: user.id, name } },
      update: { color },
      create: { userId: user.id, name, color },
    });

    return NextResponse.json({
      id: tag.id,
      name: tag.name,
      color: tag.color,
      created_at: tag.createdAt.toISOString(),
    });
  } catch (err: any) {
    console.error("[tags POST] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
