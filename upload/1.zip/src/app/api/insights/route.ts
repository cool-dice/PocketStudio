// GET /api/insights
// Returns paginated list of the user's insights (PRD section 5.2).

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { markNotified } from "@/lib/pipeline";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const user = await getMvpUser();
    const url = new URL(req.url);
    const limit = Math.min(Math.max(Number(url.searchParams.get("limit")) || 20, 1), 100);
    const offset = Math.max(Number(url.searchParams.get("offset")) || 0, 0);

    const [insights, total] = await Promise.all([
      db.insight.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: "desc" },
        take: limit,
        skip: offset,
        select: {
          id: true,
          contextType: true,
          status: true,
          rawText: true,
          transcription: true,
          audioUrl: true,
          scheduledDeliveryAt: true,
          createdAt: true,
          notified: true,
          favorite: true,
          analysis: { select: { id: true } },
          tags: {
            select: {
              tag: { select: { id: true, name: true, color: true } },
            },
          },
        },
      }),
      db.insight.count({ where: { userId: user.id } }),
    ]);

    const now = new Date();
    const data = insights.map((i) => {
      const hasAnalysis = !!i.analysis;
      const isReady =
        i.status === "processed" &&
        !!i.scheduledDeliveryAt &&
        new Date(i.scheduledDeliveryAt) <= now;
      return {
        id: i.id,
        context_type: i.contextType,
        status: i.status,
        raw_text: i.rawText ?? i.transcription ?? "",
        has_audio: !!i.audioUrl,
        audio_url: i.audioUrl,
        has_analysis: hasAnalysis,
        is_ready: isReady,
        notified: i.notified,
        favorite: i.favorite,
        tags: i.tags.map((it) => it.tag),
        scheduled_delivery_at: i.scheduledDeliveryAt?.toISOString() ?? null,
        created_at: i.createdAt.toISOString(),
      };
    });

    // Side-effect: when client signals it has shown the toast, mark as notified.
    // Fire-and-forget so the list response isn't delayed by the DB writes.
    const shouldMark = url.searchParams.get("mark_notified") === "1";
    if (shouldMark) {
      const readyIds = insights
        .filter((i) => i.status === "processed" && !i.notified && i.scheduledDeliveryAt && new Date(i.scheduledDeliveryAt) <= now)
        .map((i) => i.id);
      if (readyIds.length > 0) {
        // Non-blocking — errors are swallowed so they don't break the list fetch.
        Promise.all(readyIds.map((id) => markNotified(id).catch(() => {}))).catch(() => {});
      }
    }

    return NextResponse.json({
      data,
      pagination: { total, limit, offset },
    });
  } catch (err: any) {
    console.error("[list insights] error:", err);
    return NextResponse.json({ error: err?.message ?? "Internal server error" }, { status: 500 });
  }
}
