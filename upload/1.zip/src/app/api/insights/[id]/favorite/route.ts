// PATCH /api/insights/[id]/favorite
// Toggles the favorite (pin) state of an insight.
// Body: { favorite?: boolean } — if omitted, toggles current value.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    let nextFavorite = !insight.favorite;
    try {
      const body = await req.json();
      if (typeof body?.favorite === "boolean") {
        nextFavorite = body.favorite;
      }
    } catch {
      /* no body = toggle */
    }

    const updated = await db.insight.update({
      where: { id },
      data: { favorite: nextFavorite },
      select: { id: true, favorite: true },
    });

    return NextResponse.json({
      insight_id: updated.id,
      favorite: updated.favorite,
    });
  } catch (err: any) {
    console.error("[favorite] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
