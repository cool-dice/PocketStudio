// POST   /api/insights/[id]/tags — attach a tag to an insight { tag_id } or { name }
// DELETE /api/insights/[id]/tags?tag_id=... — detach a tag

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    const body = await req.json();
    let tagId = typeof body?.tag_id === "string" ? body.tag_id : null;

    // If name provided instead of tag_id, create/find the tag.
    if (!tagId && typeof body?.name === "string" && body.name.trim()) {
      const name = body.name.trim().slice(0, 30);
      const tag = await db.tag.upsert({
        where: { userId_name: { userId: user.id, name } },
        update: {},
        create: { userId: user.id, name, color: "stone" },
      });
      tagId = tag.id;
    }

    if (!tagId) {
      return NextResponse.json({ error: "tag_id or name required" }, { status: 400 });
    }

    // Verify tag belongs to user.
    const tag = await db.tag.findUnique({ where: { id: tagId } });
    if (!tag || tag.userId !== user.id) {
      return NextResponse.json({ error: "Tag not found" }, { status: 404 });
    }

    // Attach (idempotent via unique constraint).
    const insightTag = await db.insightTag.upsert({
      where: { insightId_tagId: { insightId: id, tagId: tagId } },
      update: {},
      create: { insightId: id, tagId },
    });

    return NextResponse.json({
      insight_id: id,
      tag_id: tagId,
      tag_name: tag.name,
      tag_color: tag.color,
      attached: true,
    });
  } catch (err: any) {
    console.error("[insight tags POST] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    const url = new URL(req.url);
    const tagId = url.searchParams.get("tag_id");
    if (!tagId) {
      return NextResponse.json({ error: "tag_id query param required" }, { status: 400 });
    }

    await db.insightTag.deleteMany({
      where: { insightId: id, tagId },
    });

    return NextResponse.json({ success: true, detached: true });
  } catch (err: any) {
    console.error("[insight tags DELETE] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
