// GET /api/insights/[id]/analysis
// Returns the structured 4-block analysis for a specific insight (PRD 5.3).

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({
      where: { id },
      include: {
        analysis: true,
        analysisRevisions: { orderBy: { createdAt: "desc" }, take: 1 },
      },
    });

    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    if (insight.status === "error") {
      return NextResponse.json(
        { status: "error", message: "Не удалось обработать мысль. Попробуйте снова" },
        { status: 500 },
      );
    }

    const now = new Date();
    const isReady =
      insight.status === "processed" &&
      !!insight.scheduledDeliveryAt &&
      new Date(insight.scheduledDeliveryAt) <= now;

    if (insight.status !== "processed" || !insight.analysis) {
      const etaMs = insight.scheduledDeliveryAt
        ? Math.max(0, new Date(insight.scheduledDeliveryAt).getTime() - now.getTime())
        : null;
      const etaMin = etaMs === null ? null : Math.max(1, Math.ceil(etaMs / 60000));
      return NextResponse.json({
        status: "analysis_not_ready",
        insight_id: insight.id,
        insight_status: insight.status,
        estimated_time: etaMin === null ? null : `через ${etaMin} мин`,
        scheduled_delivery_at: insight.scheduledDeliveryAt?.toISOString() ?? null,
      });
    }

    if (!isReady) {
      const etaMs = insight.scheduledDeliveryAt
        ? Math.max(0, new Date(insight.scheduledDeliveryAt).getTime() - now.getTime())
        : 0;
      const etaMin = Math.max(1, Math.ceil(etaMs / 60000));
      return NextResponse.json({
        status: "analysis_not_ready",
        insight_id: insight.id,
        insight_status: insight.status,
        estimated_time: `через ${etaMin} мин`,
        scheduled_delivery_at: insight.scheduledDeliveryAt?.toISOString() ?? null,
      });
    }

    const latestRevision = insight.analysisRevisions[0];

    return NextResponse.json({
      status: "ready",
      insight_id: insight.id,
      context_type: insight.contextType ?? "general",
      original_text: insight.rawText ?? insight.transcription ?? "",
      has_audio: !!insight.audioUrl,
      audio_url: insight.audioUrl,
      positive_block: insight.analysis.positiveBlock,
      negative_block: insight.analysis.negativeBlock,
      final_block: insight.analysis.finalBlock,
      recommendations: insight.analysis.recommendations,
      created_at: insight.analysis.createdAt.toISOString(),
      has_revision: !!latestRevision,
      revision: latestRevision
        ? {
            positive_block: latestRevision.positiveBlock,
            negative_block: latestRevision.negativeBlock,
            final_block: latestRevision.finalBlock,
            recommendations: latestRevision.recommendations,
            created_at: latestRevision.createdAt.toISOString(),
          }
        : null,
    });
  } catch (err: any) {
    console.error("[get analysis] error:", err);
    return NextResponse.json({ error: err?.message ?? "Internal server error" }, { status: 500 });
  }
}
