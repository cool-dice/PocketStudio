// POST /api/insights/[id]/quest
// Replaces the previous stub. Two behaviours:
//   - If quest has no messages yet → starts the quest: generates the first AI
//     message and returns it.
//   - If body contains { message } → appends the user's message, generates the
//     AI's next reply, appends it, returns both.
// GET  /api/insights/[id]/quest → returns full message history.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { generateQuestReply, generateEvolvedAnalysis, type QuestContext } from "@/lib/ai";
import type { ContextType } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function loadQuestContext(insightId: string, userId: string): Promise<QuestContext | null> {
  const insight = await db.insight.findUnique({
    where: { id: insightId },
    include: { analysis: true },
  });
  if (!insight || insight.userId !== userId) return null;
  if (!insight.analysis) return null;
  return {
    originalText: insight.rawText ?? insight.transcription ?? "",
    contextType: (insight.contextType ?? "general") as ContextType,
    positiveBlock: insight.analysis.positiveBlock,
    negativeBlock: insight.analysis.negativeBlock,
    finalBlock: insight.analysis.finalBlock,
    recommendations: insight.analysis.recommendations,
  };
}

// GET /api/insights/[id]/quest — returns quest message history + progress + completion status.
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    const messages = await db.questMessage.findMany({
      where: { insightId: id },
      orderBy: { createdAt: "asc" },
      select: { id: true, role: true, content: true, stepIndex: true, completedAt: true, createdAt: true },
    });

    // Compute progress: count assistant messages with stepIndex, find max stepIndex.
    const assistantSteps = messages.filter((m) => m.role === "assistant" && m.stepIndex);
    const currentStep = assistantSteps.reduce((max, m) => Math.max(max, m.stepIndex ?? 0), 0);
    const isCompleted = messages.some((m) => m.completedAt !== null);

    // Count total steps from analysis recommendations.
    const totalSteps = insight.analysis
      ? countRecs(insight.analysis.recommendations)
      : 0;

    return NextResponse.json({
      insight_id: id,
      messages: messages.map((m) => ({
        id: m.id,
        role: m.role,
        content: m.content,
        step_index: m.stepIndex,
        completed_at: m.completedAt?.toISOString() ?? null,
        created_at: m.createdAt.toISOString(),
      })),
      count: messages.length,
      current_step: currentStep,
      total_steps: totalSteps,
      is_completed: isCompleted,
    });
  } catch (err: any) {
    console.error("[quest GET] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}

/** Count recommendations (numbered or bulleted lines). */
function countRecs(recs: string): number {
  const lines = recs.split(/\n+/).map((l) => l.trim()).filter(Boolean);
  const numbered = lines.filter((l) => /^(\d+[.\)]|[-–*•])/.test(l));
  return Math.max(1, numbered.length > 0 ? numbered.length : lines.length);
}

// POST — start quest (no body) OR send a user message ({ message }).
// Returns 202 immediately; the AI reply is generated in the background and
// the client polls GET to pick it up (same pattern as the capture pipeline).
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({
      where: { id },
      include: { analysis: true },
    });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }
    if (!insight.analysis) {
      return NextResponse.json(
        { error: "Analysis not ready — complete the analysis first." },
        { status: 409 },
      );
    }

    // Parse body (may be empty for "start" case).
    let userMessage: string | null = null;
    try {
      const body = await req.json();
      if (typeof body?.message === "string" && body.message.trim()) {
        userMessage = body.message.trim().slice(0, 4000);
      }
    } catch {
      /* empty body = start quest */
    }

    // Persist the user message (if any) immediately so the client sees it.
    const createdUser = userMessage
      ? await db.questMessage.create({
          data: { insightId: id, role: "user", content: userMessage },
        })
      : null;

    // Schedule the AI reply generation in the background (non-blocking).
    setImmediate(() => {
      generateQuestReplyForInsight(id).catch((err) => {
        console.error(`[quest] background AI reply failed for ${id}:`, err);
        // Persist an error message so the client sees something.
        db.questMessage
          .create({
            data: {
              insightId: id,
              role: "assistant",
              content:
                "Не удалось сгенерировать ответ. Попробуйте отправить сообщение ещё раз или начните квест заново.",
            },
          })
          .catch(() => {});
      });
    });

    return NextResponse.json(
      {
        insight_id: id,
        user_message: createdUser
          ? {
              id: createdUser.id,
              role: "user",
              content: createdUser.content,
              created_at: createdUser.createdAt.toISOString(),
            }
          : null,
        status: "processing",
      },
      { status: 202 },
    );
  } catch (err: any) {
    console.error("[quest POST] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}

/**
 * Background worker: loads quest context + history, calls the AI, persists the reply.
 * Tracks step progress and detects completion; on completion triggers analysis evolution.
 */
async function generateQuestReplyForInsight(insightId: string): Promise<void> {
  const insight = await db.insight.findUnique({
    where: { id: insightId },
    include: { analysis: true },
  });
  if (!insight || !insight.analysis) return;

  const ctx: QuestContext = {
    originalText: insight.rawText ?? insight.transcription ?? "",
    contextType: (insight.contextType ?? "general") as ContextType,
    positiveBlock: insight.analysis.positiveBlock,
    negativeBlock: insight.analysis.negativeBlock,
    finalBlock: insight.analysis.finalBlock,
    recommendations: insight.analysis.recommendations,
  };

  const existing = await db.questMessage.findMany({
    where: { insightId },
    orderBy: { createdAt: "asc" },
    select: { role: true, content: true, stepIndex: true },
  });
  const history = existing.map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  // Determine current step from existing assistant messages.
  const totalSteps = countRecs(insight.analysis.recommendations);
  const currentStep = existing
    .filter((m) => m.role === "assistant" && m.stepIndex)
    .reduce((max, m) => Math.max(max, m.stepIndex ?? 0), 0);

  // Determine if this should be the completing step.
  // Heuristic: if the user has answered at least totalSteps questions, complete.
  const userAnswers = existing.filter((m) => m.role === "user").length;
  const isCompleting = userAnswers >= totalSteps;

  const aiText = await generateQuestReply(ctx, history, { currentStep: currentStep + 1, isCompleting });

  // Compute the step index for this assistant message.
  const nextStep = isCompleting ? totalSteps : Math.min(currentStep + 1, totalSteps);

  await db.questMessage.create({
    data: {
      insightId,
      role: "assistant",
      content: aiText,
      stepIndex: nextStep,
      completedAt: isCompleting ? new Date() : null,
    },
  });

  // If completed, trigger analysis evolution in the background.
  if (isCompleting) {
    console.log(`[quest] insight=${insightId} completed — generating evolved analysis`);
    setImmediate(() => {
      generateEvolvedAnalysisForInsight(insightId).catch((err) => {
        console.error(`[quest] evolved analysis failed for ${insightId}:`, err);
      });
    });
  }
}

/**
 * Generate an evolved analysis after quest completion and store as AnalysisRevision.
 */
async function generateEvolvedAnalysisForInsight(insightId: string): Promise<void> {
  const insight = await db.insight.findUnique({
    where: { id: insightId },
    include: { analysis: true, questMessages: { orderBy: { createdAt: "asc" } } },
  });
  if (!insight || !insight.analysis) return;

  const ctx: QuestContext = {
    originalText: insight.rawText ?? insight.transcription ?? "",
    contextType: (insight.contextType ?? "general") as ContextType,
    positiveBlock: insight.analysis.positiveBlock,
    negativeBlock: insight.analysis.negativeBlock,
    finalBlock: insight.analysis.finalBlock,
    recommendations: insight.analysis.recommendations,
  };

  const questHistory = insight.questMessages.map((m) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  const { blocks, raw } = await generateEvolvedAnalysis(ctx, questHistory);

  await db.analysisRevision.create({
    data: {
      insightId,
      positiveBlock: blocks.positive_block,
      negativeBlock: blocks.negative_block,
      finalBlock: blocks.final_block,
      recommendations: blocks.recommendations,
      rawResponse: JSON.stringify({ raw, generatedFrom: "quest" }),
    },
  });
  console.log(`[quest] evolved analysis saved for insight=${insightId}`);
}

// DELETE — clear quest history (so the user can restart).
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    await db.questMessage.deleteMany({ where: { insightId: id } });

    return NextResponse.json({ success: true, cleared: true });
  } catch (err: any) {
    console.error("[quest DELETE] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
