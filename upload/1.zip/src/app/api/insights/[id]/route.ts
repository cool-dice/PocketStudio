// DELETE /api/insights/[id]
// Cascade-deletes the insight and its analysis (PRD 5.4).
// Audio file is cleaned up BEFORE the DB delete so a file-system error
// doesn't orphan the DB record (we'd rather have an orphaned file than
// a DB record pointing to a missing file).

import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    // Best-effort: remove the audio file from disk BEFORE deleting the DB record.
    // If this throws, we still proceed with the DB delete (file cleanup is not
    // a hard requirement), but we log it.
    if (insight.audioUrl) {
      try {
        const fileName = path.basename(insight.audioUrl);
        const absPath = path.resolve(process.cwd(), "public/uploads", fileName);
        if (fs.existsSync(absPath)) fs.unlinkSync(absPath);
      } catch (fileErr) {
        console.warn("[delete insight] audio file cleanup failed:", fileErr);
      }
    }

    // Cascade delete handles AnalysisResult + ErrorLog + QuestMessage + InsightTag.
    await db.insight.delete({ where: { id } });

    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error("[delete insight] error:", err);
    return NextResponse.json({ error: err?.message ?? "Internal server error" }, { status: 500 });
  }
}
