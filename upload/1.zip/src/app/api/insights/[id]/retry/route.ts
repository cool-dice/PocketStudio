// POST /api/insights/[id]/retry
// Re-runs the background pipeline for an insight that previously errored.

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { schedulePipeline } from "@/lib/pipeline";
import { STATUS } from "@/lib/config";
import { getDeliveryDelayMs } from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const user = await getMvpUser();

    const insight = await db.insight.findUnique({ where: { id } });
    if (!insight || insight.userId !== user.id) {
      return NextResponse.json({ error: "Insight not found" }, { status: 404 });
    }

    // Clean up any prior analysis result so the pipeline can recreate it.
    await db.analysisResult.deleteMany({ where: { insightId: id } });

    const deliveryDelay = await getDeliveryDelayMs();
    const scheduledDeliveryAt = new Date(Date.now() + deliveryDelay);

    await db.insight.update({
      where: { id },
      data: {
        status: STATUS.PENDING,
        notified: false,
        contextType: null,
        scheduledDeliveryAt,
      },
    });

    schedulePipeline(id);

    return NextResponse.json({
      insight_id: id,
      status: STATUS.PENDING,
      scheduled_delivery_at: scheduledDeliveryAt.toISOString(),
      message: "Повторный анализ запущен",
    });
  } catch (err: any) {
    console.error("[retry] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
