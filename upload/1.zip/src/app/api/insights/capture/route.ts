// POST /api/insights/capture
// Accepts either a text thought or an audio file (multipart/form-data).
// Creates the insight with status=pending, schedules the background pipeline,
// and returns 201 immediately (PRD section 5.1).

import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import crypto from "crypto";
import { db } from "@/lib/db";
import { getMvpUser } from "@/lib/user";
import { schedulePipeline } from "@/lib/pipeline";
import { AUDIO_UPLOAD_DIR, AUDIO_URL_PREFIX, STATUS } from "@/lib/config";
import { getDeliveryDelayMs, getSettingNumber, deliveryMessage } from "@/lib/settings";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function ensureUploadDir() {
  const dir = path.resolve(process.cwd(), AUDIO_UPLOAD_DIR);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getMvpUser();

    let rawText: string | null = null;
    let audioBuffer: Buffer | null = null;
    let audioExt = ".webm";

    const contentType = req.headers.get("content-type") ?? "";

    // DB-backed limits (admin-configurable).
    const maxTextLength = await getSettingNumber("maxTextLength");
    const maxAudioSize = await getSettingNumber("maxAudioSize");

    if (contentType.includes("multipart/form-data")) {
      const formData = await req.formData();
      const textVal = formData.get("text");
      if (typeof textVal === "string" && textVal.trim().length > 0) {
        rawText = textVal.trim().slice(0, maxTextLength);
      }
      const file = formData.get("audio_file");
      if (file && file instanceof File) {
        if (file.size > maxAudioSize) {
          return NextResponse.json(
            { error: `Audio file exceeds ${maxAudioSize} bytes` },
            { status: 413 },
          );
        }
        audioBuffer = Buffer.from(await file.arrayBuffer());
        // Try to infer extension from filename.
        const name = file.name || "";
        const ext = path.extname(name).toLowerCase();
        if (ext) audioExt = ext;
      }
    } else if (contentType.includes("application/json")) {
      const body = await req.json();
      if (typeof body?.text === "string" && body.text.trim().length > 0) {
        rawText = body.text.trim().slice(0, maxTextLength);
      }
    } else {
      return NextResponse.json({ error: "Unsupported content-type" }, { status: 415 });
    }

    if (!rawText && !audioBuffer) {
      return NextResponse.json(
        { error: "Either 'text' or 'audio_file' must be provided" },
        { status: 400 },
      );
    }

    // Persist audio file if present.
    let audioUrl: string | null = null;
    if (audioBuffer) {
      ensureUploadDir();
      const fileName = `${crypto.randomUUID()}${audioExt}`;
      const absPath = path.resolve(process.cwd(), AUDIO_UPLOAD_DIR, fileName);
      fs.writeFileSync(absPath, audioBuffer);
      audioUrl = `${AUDIO_URL_PREFIX}/${fileName}`;
    }

    const deliveryDelay = await getDeliveryDelayMs();
    const scheduledDeliveryAt = new Date(Date.now() + deliveryDelay);

    const insight = await db.insight.create({
      data: {
        userId: user.id,
        rawText,
        audioUrl,
        status: STATUS.PENDING,
        scheduledDeliveryAt,
      },
    });

    // Fire-and-forget background processing.
    schedulePipeline(insight.id);

    return NextResponse.json(
      {
        insight_id: insight.id,
        status: insight.status,
        scheduled_delivery_at: scheduledDeliveryAt.toISOString(),
        message: await deliveryMessage(),
      },
      { status: 201 },
    );
  } catch (err: any) {
    console.error("[capture] error:", err);
    return NextResponse.json(
      { error: err?.message ?? "Internal server error" },
      { status: 500 },
    );
  }
}
