﻿VibeMind — MVP Product Requirements Document (PRD)

---

1. КОНЦЕПЦИЯ ПРОДУКТА И СНИЖЕНИЕ ТРЕНИЯ (FRICTION)

1.1. Базовая механика захвата мысли

Приложение предоставляет единую точку входа для фиксации инсайта — главный экран с двумя доминирующими элементами управления:

· Кнопка «Записать голос» — инициирует запись с микрофона устройства. Длительность записи не ограничена, но интерфейс отображает таймер и визуальную волну. По окончании записи аудио автоматически отправляется на сервер.
· Текстовое поле «Опишите мысль» — принимает произвольный текст без требований к форматированию. Поле автоматически расширяется по высоте до 5 строк. Поддерживает вставку из буфера обмена.

После отправки (голосовой или текстовой) система немедленно отображает модальное подтверждение с текстом: «Мысль сохранена. Анализ придёт через час». Подтверждение автоматически исчезает через 2 секунды, возвращая пользователя к чистому интерфейсу для захвата следующей мысли.

Запрещено использование Markdown, тегов, скобочных нотаций или любого синтаксиса для структурирования. Пользователь взаимодействует исключительно с естественным языком.

1.2. Асинхронный воркфлоу — двухэтапная обработка

Этап 1 — Мгновенный захват (синхронный)

· Система принимает аудиофайл (формат WebM/MP3, до 10 МБ) или текстовую строку (до 5000 символов).
· Создаётся запись в таблице insights со статусом pending.
· Для голосовых сообщений запускается асинхронная транскрипция через Whisper API.
· Текстовые сообщения сразу переходят в очередь анализа.
· Клиент получает ответ 201 Created с идентификатором инсайта и подтверждением.

Этап 2 — Фоновый ИИ-анализ (асинхронный)

· Триггер запуска: Постановка в очередь analysis-queue (Redis Bull или аналогичная система).
· Время выполнения: Workflow запускается немедленно, но результат доставляется пользователю строго через 60 минут после захвата. Это время зафиксировано в поле scheduled_delivery_at.
· Задержка реализуется через setTimeout в воркере или планировщик задач. Цель — дать пользователю завершить текущий контекст деятельности и получить разбор в момент рефлексии, а не в моменте генерации идеи.
· По истечении 60 минут система отправляет push-уведомление (через Web Push API или Firebase) с текстом: «Разбор вашей мысли готов. Откройте VibeMind».
· В случае ошибки на любом этапе статус инсайта меняется на error, а пользователь получает push с текстом: «Не удалось обработать мысль. Попробуйте снова». Запись ошибки сохраняется в отдельной таблице логов.

---

2. ДИНАМИЧЕСКИЙ МАРШРУТИЗАТОР КОНТЕКСТОВ (МУЛЬТИПРОМПТИНГ)

2.1. Логика классификации

После транскрипции или при получении текста система выполняет первичную категоризацию с помощью отдельного лёгкого промпта (модель GPT-4o-mini или DeepSeek). Категория определяется на основе ключевых слов и семантического анализа:

Категория Ключевые триггеры
business стартап, продажи, инвестиции, MVP, юнит-экономика, конкуренты, рынок, прибыль, cost, revenue
shopping купить, стоимость, цена, скидка, замена, совместимость, гарантия, доставка
psychology чувствую, отношения, тревога, границы, усталость, депрессия, рефлексия, манипуляция

Если ни одна категория не набрала уверенность > 60%, применяется универсальный промпт (общий анализ без специализации). Результат классификации сохраняется в поле context_type таблицы insights.

2.2. Три жестких системных промпта

Контекст «Бизнес и Проекты» (business)

```
Ты — стратегический консультант по развитию бизнеса. Твоя задача — дать жёсткий, прагматичный анализ идеи пользователя. 
Фокусные области:
1. Финансовая жизнеспособность: оценка юнит-экономики, точки безубыточности, маржинальности.
2. MVP-реализация: минимальный функциональный набор для проверки гипотезы, сроки, ресурсы.
3. Рыночные риски: конкуренты, барьеры входа, регуляторные ограничения, волатильность спроса.
4. Масштабируемость: возможность роста без пропорционального роста затрат.

Ответ строго структурируй в четыре блока, без воды, используй цифры, проценты и конкретные метрики там, где это возможно.
```

Контекст «Быт и Покупки» (shopping)

```
Ты — рациональный эксперт по потребительским решениям. Твоя задача — оценить практическую ценность покупки или бытового решения. 
Фокусные области:
1. Целесообразность расходов: соотношение цена/качество, частота использования, срок окупаемости.
2. Альтернативы: более дешёвые/дорогие аналоги, подержанные варианты, аренда вместо покупки.
3. Техническая совместимость: интеграция с существующими устройствами/системами, требования к инфраструктуре.
4. Скрытые затраты: обслуживание, расходники, утилизация, электроэнергия.

Ответ строго структурируй в четыре блока, используй сравнительные таблицы в тексте (в виде маркированных списков), будь предельно конкретен.
```

Контекст «Психология и Отношения» (psychology)

```
Ты — эмпатичный, но трезвый психологический ассистент. Твоя задача — поддержать, но без ложного оптимизма. 
Фокусные области:
1. Личные границы: оценка ситуации с точки зрения нарушения или укрепления личных границ.
2. Когнитивные искажения: выявление возможных искажений (катастрофизация, чёрно-белое мышление, долженствование).
3. Долгосрочные последствия для ментального здоровья: как решение или ситуация повлияет через 1 месяц, 1 год.
4. Ресурсы и опоры: что уже есть у пользователя (сильные стороны), что можно укрепить.

Ответ строго структурируй в четыре блока, используй мягкий, вопросительный тон в рекомендациях, избегай клинических диагнозов, делай акцент на осознанности.
```

---

3. ПЕРЕХОД ОТ СТАТИКИ К ИНТЕРФЕЙСУ «СПАРРИНГ-ПАРТНЕРА»

3.1. Модель хранения разбора (4 блока)

В таблице analysis_results строго фиксируются четыре поля, соответствующих этапам диалога:

Поле Тип Содержание
positive_block text Позитивный анализ, развитие, сильные стороны идеи (объём 100–200 слов).
negative_block text Риски, слабые стороны, возможные проблемы (объём 100–200 слов).
final_block text Синтез, взвешенный итог, главный вывод (объём 80–150 слов).
recommendations text Конкретные действия, чек-лист или пошаговый план (до 10 пунктов).

Все блоки генерируются ИИ в одном запросе с указанием строгой структуры вывода (JSON-схема). Дополнительно сохраняется полный сырой ответ модели в поле raw_response для аудита.

3.2. UI-репрезентация как диалог

Интерфейс разбора строится как пошаговое раскрытие блоков, имитирующее беседу со спарринг-партнёром:

1. Экран анализа (GET /api/insights/:id/analysis) загружает все 4 блока из БД.
2. По умолчанию виден только позитивный блок с заголовком: «Слушай, это круто, потому что...» и текстом positive_block.
3. Под ним — кнопка-триггер «В чем подвох?».
4. При нажатии кнопка исчезает, и плавно появляется негативный блок с заголовком: «А теперь трезвый взгляд...» и текстом negative_block.
5. Через 300 мс после появления негативного блока автоматически (без дополнительного клика) появляется финальный синтез с заголовком: «Синтез: главное» и текстом final_block.
6. Под финальным синтезом — кнопка «Запустить чат-квест для проработки идеи». Эта кнопка отправляет POST-запрос на отдельный эндпоинт /api/insights/:id/quest, который создаёт воркер для пошагового диалога с ИИ по реализации рекомендаций (эта функциональность в MVP не входит, кнопка ведёт на заглушку с уведомлением «Функция в разработке»).

Все блоки отображаются с анимацией появления (fade-in, duration 0.4s). На экране присутствует кнопка «Назад» для возврата к списку инсайтов.

---

4. ПОЛНАЯ СХЕМА БАЗЫ ДАННЫХ (PostgreSQL / Supabase)

```sql
-- Расширения для работы с UUID и аудио
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Таблица пользователей
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Таблица инсайтов
CREATE TABLE insights (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    raw_text TEXT, -- может быть NULL, если только аудио
    audio_url TEXT, -- может быть NULL, если только текст
    context_type VARCHAR(50) CHECK (context_type IN ('business', 'shopping', 'psychology', 'general')),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'processed', 'error')),
    scheduled_delivery_at TIMESTAMPTZ, -- время, когда будет отправлен push
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    CONSTRAINT either_text_or_audio CHECK (
        (raw_text IS NOT NULL AND audio_url IS NULL) OR
        (raw_text IS NULL AND audio_url IS NOT NULL) OR
        (raw_text IS NOT NULL AND audio_url IS NOT NULL)
    )
);

-- Индекс для быстрой выборки по пользователю и статусу
CREATE INDEX idx_insights_user_id_status ON insights(user_id, status);
CREATE INDEX idx_insights_scheduled_delivery ON insights(scheduled_delivery_at) WHERE status = 'pending';

-- Таблица результатов анализа
CREATE TABLE analysis_results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    insight_id UUID NOT NULL REFERENCES insights(id) ON DELETE CASCADE,
    positive_block TEXT NOT NULL,
    negative_block TEXT NOT NULL,
    final_block TEXT NOT NULL,
    recommendations TEXT NOT NULL,
    raw_response JSONB, -- сырой ответ модели для аудита
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    
    CONSTRAINT unique_insight_analysis UNIQUE (insight_id)
);

-- Триггер для автоматического обновления updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_insights_updated_at BEFORE UPDATE ON insights FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_analysis_results_updated_at BEFORE UPDATE ON analysis_results FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Таблица для логов ошибок (опционально, но рекомендовано)
CREATE TABLE error_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    insight_id UUID REFERENCES insights(id) ON DELETE SET NULL,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    error_message TEXT NOT NULL,
    stack_trace TEXT,
    context JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

5. АРХИТЕКТУРА API И ИИ-ПАЙПЛАЙНА (ENDPOINTS)

5.1. POST /api/insights/capture

Назначение: приём нового инсайта (голос или текст).

Request (multipart/form-data или application/json):

```json
{
  "user_id": "uuid",
  "text": "optional string, до 5000 символов",
  "audio_file": "optional file (WebM/MP3)"
}
```

Примечание: в запросе должен быть либо text, либо audio_file, либо оба.

Response (201 Created):

```json
{
  "insight_id": "uuid",
  "status": "pending",
  "scheduled_delivery_at": "2026-09-01T19:00:00Z",
  "message": "Мысль сохранена. Анализ придёт через час"
}
```

Логика:

1. Валидация входных данных — наличие text или audio_file.
2. Аутентификация через JWT (middleware).
3. Сохранение записи в insights со статусом pending и scheduled_delivery_at = NOW() + 1 hour.
4. Если передан аудиофайл:
   · Сохранение файла в Supabase Storage (bucket audio), получение публичного URL.
   · Запись audio_url в БД.
   · Постановка задачи в очередь transcription-queue (воркер Python/Fastify) с параметрами {insight_id, audio_url}.
5. Если передан только текст:
   · Запись raw_text в БД.
   · Постановка задачи в очередь analysis-queue с параметрами {insight_id, text}.
6. Если переданы и текст, и аудио — приоритет отдаётся аудио (текст игнорируется).
7. Возврат ответа клиенту немедленно, до завершения фоновых задач.

Очереди и воркеры:

· transcription-queue → воркер вызывает Whisper API, получает текст, обновляет raw_text в insights, затем ставит задачу в analysis-queue.
· analysis-queue → воркер:
  · Вызывает классификатор (лёгкая модель) для определения context_type.
  · Выбирает соответствующий системный промпт.
  · Выполняет основной запрос к GPT-4o/DeepSeek через LiteLLM, получает JSON с 4 блоками.
  · Сохраняет результат в analysis_results.
  · Обновляет статус insights на processed.
  · Планирует push-уведомление на время scheduled_delivery_at (через планировщик задач или cron).

---

5.2. GET /api/insights

Назначение: получение списка всех инсайтов текущего пользователя.

Request: GET /api/insights?limit=20&offset=0

Response (200 OK):

```json
{
  "data": [
    {
      "id": "uuid",
      "context_type": "business",
      "status": "processed",
      "raw_text": "Идея приложения для учета расходов...",
      "created_at": "2026-09-01T12:00:00Z",
      "has_analysis": true,
      "scheduled_delivery_at": "2026-09-01T13:00:00Z"
    }
  ],
  "pagination": {
    "total": 42,
    "limit": 20,
    "offset": 0
  }
}
```

Логика:

1. Извлечение user_id из JWT.
2. Запрос к таблице insights с фильтром по user_id, сортировка по created_at DESC.
3. Подзапрос на наличие записи в analysis_results для каждого инсайта (поле has_analysis).
4. Возврат пагинированного списка.

---

5.3. GET /api/insights/:id/analysis

Назначение: получение структурированного разбора для конкретного инсайта.

Request: GET /api/insights/{id}/analysis

Response (200 OK):

```json
{
  "insight_id": "uuid",
  "context_type": "business",
  "original_text": "Идея приложения для учета расходов...",
  "positive_block": "Слушай, это круто, потому что...",
  "negative_block": "А теперь трезвый взгляд...",
  "final_block": "Синтез: главное...",
  "recommendations": "1. Шаг первый\n2. Шаг второй",
  "created_at": "2026-09-01T12:30:00Z"
}
```

Логика:

1. Проверка существования инсайта и принадлежности пользователю.
2. Если статус processed — выполняется JOIN с analysis_results.
3. Если статус pending или processing — возвращается ответ с "status": "analysis_not_ready" и "estimated_time": "через X минут".
4. Если статус error — возвращается код 500 с сообщением об ошибке.

Интерактивный UI использует полученные 4 блока для построения пошагового диалога согласно разделу 3.2.

---

5.4. Дополнительный эндпоинт (для полноты)

DELETE /api/insights/:id — удаление инсайта и связанного анализа (каскадное удаление через FK). Требует права владельца.

---

6. ТЕХНИЧЕСКИЕ ТРЕБОВАНИЯ К ИНФРАСТРУКТУРЕ

Компонент Стек Назначение
Frontend Next.js (App Router) + TailwindCSS Рендеринг UI, клиентские взаимодействия, SWR для кэширования
API Layer Next.js API Routes / Fastify Обработка запросов, аутентификация, валидация
База данных Supabase (PostgreSQL) Хранение пользователей, инсайтов, анализов
Хранилище файлов Supabase Storage (S3-совместимое) Хранение аудиозаписей
Очереди Redis Bull (или Upstash Redis) transcription-queue, analysis-queue
Воркеры Python + Fastify + LiteLLM Транскрипция, классификация, генерация анализа
Push-уведомления Web Push API / Firebase Cloud Messaging Доставка уведомлений в браузер и мобильное приложение
Аутентификация Supabase Auth (JWT) Вход через email/password, Google, Apple

Деплой: Vercel (Next.js) + Render/Fly.io (воркеры) + Supabase (managed).

---

7. ПОРЯДОК РАЗРАБОТКИ MVP (ЗА УИКЕНД)

1. Суббота, утро: Настройка Supabase (таблицы, RLS-политики, Storage bucket). Развертывание Next.js с базовыми страницами (авторизация, главный экран).
2. Суббота, день: Реализация POST /capture — сохранение инсайта, загрузка аудио, постановка в очередь. Настройка Redis Bull.
3. Суббота, вечер: Python-воркер для транскрипции (Whisper) и классификатор контекста. Первые интеграционные тесты.
4. Воскресенье, утро: Воркер анализа с тремя промптами, генерация JSON. Сохранение в БД.
5. Воскресенье, день: UI списка инсайтов и страница анализа с пошаговым раскрытием блоков. Подключение push-уведомлений.
6. Воскресенье, вечер: End-to-end тестирование, деплой на продакшен, подготовка landing page.

---

8. RLS-ПОЛИТИКИ SUPABASE (БЕЗОПАСНОСТЬ)

```sql
-- Включить RLS на всех таблицах
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE analysis_results ENABLE ROW LEVEL SECURITY;

-- Политики для users
CREATE POLICY "Users can read own data" ON users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update own data" ON users FOR UPDATE USING (auth.uid() = id);

-- Политики для insights
CREATE POLICY "Users can read own insights" ON insights FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own insights" ON insights FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own insights" ON insights FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own insights" ON insights FOR DELETE USING (auth.uid() = user_id);

-- Политики для analysis_results
CREATE POLICY "Users can read own analysis" ON analysis_results FOR SELECT 
    USING (EXISTS (SELECT 1 FROM insights WHERE insights.id = analysis_results.insight_id AND insights.user_id = auth.uid()));

-- Политики для error_logs (только вставка системой)
CREATE POLICY "System can insert error logs" ON error_logs FOR INSERT WITH CHECK (true);
```

---

Документ является финальной версией спецификации VibeMind MVP. Все архитектурные решения утверждены и подлежат реализации без изменений в рамках заявленного стека и сроков.