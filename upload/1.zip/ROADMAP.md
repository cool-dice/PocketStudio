# VibeMind — Development Roadmap

Based on battle-testing (2 insights, 1 full chat-quest of 15 messages), this roadmap
addresses the gaps between the original PRD and the working MVP.

**Status as of 2026-09-09:** MVP functional with live-queue delivery, 4-block
analysis, chat-quest, admin panel, tags, favorites, stats dashboard. 0 voice
insights tested, 0 providers configured, 0 errors logged.

---

## Iteration 1: Quest Completion & Evolution ✅ DONE

**Goal:** Close the quest loop — formal completion, progress tracking, and feed
quest insights back into the analysis.

### 1.1 Formal Quest Completion
- [x] Detect when all recommendations have been discussed (track which rec index
      the conversation is on by parsing AI messages for "recommendation N" cues
      or a counter in the DB).
- [x] Add a "quest_complete" state to the quest history response.
- [x] When complete, prompt the AI to generate a final summary + daily commitment
      ("Что вы сделаете прямо сегодня?") — currently the quest can loop forever.
- [x] UI: show a "Квест завершён" banner with the final commitment highlighted.

### 1.2 Quest Progress Indicator
- [x] Track current recommendation index (1/10, 2/10, ...) in the QuestMessage
      metadata (add `stepIndex` field or compute from message count).
- [x] Display progress bar in the quest dialog header: "Шаг 3 из 10".
- [x] AI system prompt update: explicitly tell the model which recommendation
      it's on and how many remain.

### 1.3 Analysis Evolution (quest → analysis feedback)
- [x] After quest completion, generate an "evolved analysis" — a diff/update of
      the original 4 blocks incorporating what was discussed in the quest.
- [x] Store as a new `AnalysisRevision` model (keeps original + evolved versions).
- [x] UI: show "Обновлённый разбор" toggle in the analysis view, allowing the
      user to compare original vs evolved analysis.

### 1.4 Enforce Quest Brevity
- [x] Add `max_tokens` to the quest chatCompletion call (e.g. 300 tokens).
- [x] System prompt reinforcement: "ОТВЕТ НЕ БОЛЕЕ 4 ПРЕДЛОЖЕНИЙ + 1 ВОПРОС.
      Превышение = ошибка."
- [x] Post-process AI responses: if > 500 chars, truncate with "..." + "Кратко:
      что сделаете сегодня?"

---

## Iteration 2: Voice Pipeline Hardening

**Goal:** Make the voice capture → transcription → analysis pipeline reliable
and tested end-to-end.

### 2.1 Voice End-to-End Test
- [ ] Manual test: record a 10-30s voice memo, capture, verify transcription
      appears in the insight, verify analysis references transcribed content.
- [ ] Test "text + audio" case (PRD: audio wins) — verify transcription replaces
      text in analysis input.

### 2.2 Audio Format Compatibility
- [ ] Document which formats MediaRecorder produces (WebM/Opus on Chrome, MP4
      on Safari, OGG on Firefox).
- [ ] Server-side: detect format from file extension, log it.
- [ ] ASR: if transcription fails, surface the format to the user (currently
      silently falls back to error state).

### 2.3 Audio Player Polish
- [ ] Replace the native `<audio>` element with a custom player UI matching the
      app's design language.
- [ ] Show waveform visualization in the analysis view (reuse the recording
      waveform component).
- [ ] Download button for the original audio file.

### 2.4 Voice Shortcuts
- [ ] Spacebar to start/stop recording (when focused on capture screen).
- [ ] Visual indicator when recording is in progress (browser tab title:
      "● Recording — VibeMind").

---

## Iteration 3: Insights Interconnection

**Goal:** Link related insights, enable comparison, and surface themes.

### 3.1 Similar Insights Detection
- [ ] After analysis, compute a simple similarity score against all past
      insights (TF-IDF on rawText + analysis blocks, stored in a vector or
      just keyword overlap for MVP).
- [ ] Show "Похожие мысли" section in the analysis view (top 3 most similar).
- [ ] Clicking a similar insight opens it in a split-view or new tab.

### 3.2 Insight Comparison View
- [ ] Add "Сравнить" button when 2+ insights are selected.
- [ ] Side-by-side view: original text, 4 analysis blocks, recommendations
      for both insights.
- [ ] Highlight differences (e.g. risk levels, recommendation counts).

### 3.3 Theme Clustering
- [ ] Auto-cluster insights by shared keywords/tags (not just context_type).
- [ ] Dashboard widget: "Темы ваших мыслей" showing top 5 clusters with counts.

### 3.4 Cross-Insight Timeline
- [ ] A timeline view showing all insights + quests over time, revealing
      patterns (e.g. "most ideas on weekends", "quest depth increasing").

---

## Iteration 4: Social & Collaboration

**Goal:** Enable sharing and feedback — critical for business ideas.

### 4.1 Share Link
- [ ] Generate a read-only share link for an insight + analysis (no auth needed
      to view, but can't edit).
- [ ] Share link expires after 7 days (configurable).
- [ ] "Скопировать ссылку" button in the analysis view.

### 4.2 Feedback on Analysis
- [ ] Allow a shared viewer to leave comments on each analysis block (like
      Google Docs comments).
- [ ] Comments stored in a new `AnalysisComment` model with role="viewer".
- [ ] Owner sees comments in their analysis view with notifications.

### 4.3 Multi-User Auth
- [ ] Implement NextAuth.js with email/password (credentials provider).
- [ ] Registration flow: email → verification → account creation.
- [ ] Each user sees only their own insights (the current single-user model
      becomes the first admin account).
- [ ] Admin panel: real user management (list, ban, role change — already built).

### 4.4 Co-Founding / Teams
- [ ] Allow inviting a second user to an insight (read+comment access).
- [ ] "Соавторы" section in the analysis view.
- [ ] Notifications when a co-founder comments.

---

## Iteration 5: AI Quality & Customization

**Goal:** Improve analysis depth, enforce PRD volume requirements, allow
per-context tuning.

### 5.1 Enforce PRD Volume
- [ ] Post-process AI analysis: check word counts against PRD spec
      (positive 100-200, negative 100-200, final 80-150).
- [ ] If too short, automatically retry with "расширь блок до N слов".
- [ ] Log volume compliance to ErrorLog for monitoring.

### 5.2 Per-Context Tone Enforcement
- [ ] Audit: verify business/shopping/psychology prompts produce distinct tones.
- [ ] Psychology prompt: ensure question-asking, non-diagnostic language.
- [ ] Shopping prompt: ensure comparison tables (markdown) in output.
- [ ] Business prompt: ensure metrics/percentages are present.

### 5.3 Recommendations Format Standardization
- [ ] Force numbered list format in the system prompt: "ОТВЕТ: строго
      нумерованный список от 1 до N".
- [ ] Post-process: if recommendations aren't numbered, auto-number them.
- [ ] Store as structured array (not free text) for better UI rendering.

### 5.4 Custom System Prompts
- [ ] Admin panel: editable system prompts per context type (stored in
      SystemSettings as `prompt_business`, `prompt_shopping`, etc.).
- [ ] Version history for prompts (prompt changes don't break old analyses).
- [ ] A/B test support: split traffic between two prompt versions.

---

## Iteration 6: Mobile & Polish

**Goal:** Responsive mobile experience, offline support, PWA.

### 6.1 Mobile Optimization
- [ ] Test all views on 375px width (iPhone SE).
- [ ] Capture screen: mic button accessible, textarea usable.
- [ ] List view: cards stack properly, stats dashboard collapsible.
- [ ] Analysis view: blocks readable, quest dialog as bottom sheet.
- [ ] Admin panel: tabs scroll horizontally, cards stack.

### 6.2 PWA
- [ ] Add manifest.json with icons, theme color, display: standalone.
- [ ] Service worker for offline access to already-fetched insights.
- [ ] "Установить приложение" prompt.
- [ ] Push notifications via service worker (replaces browser Notification API).

### 6.3 Offline Capture
- [ ] Store captures locally (IndexedDB) when offline.
- [ ] Sync to server when back online (background sync API).
- [ ] Show "Оффлайн — сохранится при подключении" indicator.

### 6.4 Accessibility Audit
- [ ] Screen reader test on all views.
- [ ] Keyboard-only navigation (Tab through all interactive elements).
- [ ] Color contrast check (WCAG AA).
- [ ] Add ARIA labels where missing.

---

## Iteration 7: Analytics & Reflection

**Goal:** Turn VibeMind into a reflection tool, not just a capture tool.

### 7.1 Weekly Reflection Email
- [ ] Cron job: every Sunday, compile insights + quest summaries from the week.
- [ ] Send as email (or in-app "Недельный разбор" card).
- [ ] Includes: how many ideas, which categories, top recommendations acted on.

### 7.2 Streak & Habits
- [ ] Track "thoughts per day" streak.
- [ ] Badge system: 7-day, 30-day, 100-day streaks.
- [ ] Gentle nudge if no thoughts in 3 days (in-app or notification).

### 7.3 Decision Journal
- [ ] Mark insights that led to a decision (green "acted" badge).
- [ ] Track outcomes: did the idea work? (user feedback 1 month later).
- [ ] Dashboard: "из N идей вы acted on M, K сработали".

### 7.4 Export Everything
- [ ] Export all insights + analyses + quests as a single .md or .json file.
- [ ] "Резервная копия" in settings.
- [ ] Import from backup (round-trip).

---

## Iteration 8: Infrastructure & Scale

**Goal:** Prepare for production load, observability, and reliability.

### 8.1 Real Queue (replace setImmediate)
- [ ] Add BullMQ + Redis (or simpler: in-process queue with concurrency limit).
- [ ] Currently: all insights process concurrently via setImmediate — could
      overload AI providers under load.
- [ ] Queue with max 3 concurrent jobs, FIFO order, retry on failure.

### 8.2 Observability
- [ ] Structured logging (pino or winston) with request IDs.
- [ ] Pipeline timing metrics: classify_ms, analyze_ms, total_ms.
- [ ] Admin dashboard: "Pipeline Health" card with p50/p95 timings.
- [ ] Error rate alerting (email/webhook when error_rate > 10%).

### 8.3 Database Backups
- [ ] Daily SQLite backup to /backups with 30-day retention.
- [ ] Admin panel: "Скачать бэкап" button.
- [ ] Restore from backup flow.

### 8.4 Rate Limiting
- [ ] Per-user rate limit on capture (max 10 insights/minute).
- [ ] Per-user rate limit on quest messages (max 20/minute).
- [ ] Admin-configurable limits (SystemSettings).

---

## Iteration 9: Advanced AI Features

**Goal:** Leverage the provider pool for smarter features.

### 9.1 Multi-Model Analysis
- [ ] Use a cheap model (GPT-4o-mini) for classification, expensive (GPT-4o)
      for analysis. Already supported via `classifierModel` / `analysisModel`
      settings — just needs UI guidance.
- [ ] Admin "model routing" config: which provider for which task.

### 9.2 Streaming Responses
- [ ] Stream analysis blocks as they generate (SSE or WebSocket).
- [ ] User sees "positive block generating..." instead of waiting 10s.
- [ ] Quest messages stream token-by-token (chat UX).

### 9.3 Follow-up Questions
- [ ] After analysis delivery, suggest 3 follow-up questions the user could
      ask the AI (e.g. "Как проверить эту гипотезу за 1 неделю?").
- [ ] Clicking a suggested question starts a quest with that as the opening.

### 9.4 Image Input (VLM)
- [ ] Allow attaching a screenshot/photo to an insight (e.g. whiteboard photo,
      competitor landing page).
- [ ] VLM provider (GPT-4o vision) analyzes the image alongside text.
- [ ] Admin: vision-capable providers flagged with `kind: "vision"`.

---

## Prioritization Rationale

| Iteration | Why this order |
|-----------|----------------|
| 1. Quest Completion | Biggest UX gap — quests currently loop forever |
| 2. Voice | 50% of PRD capture flow, completely untested |
| 3. Interconnection | Battle test showed 2 related ideas with no link |
| 4. Social | Business ideas need feedback — core value prop |
| 5. AI Quality | Analysis below PRD volume, tone not differentiated |
| 6. Mobile | No mobile testing at all, PWA enables offline |
| 7. Reflection | PRD's core goal is reflection, not just capture |
| 8. Infra | Scale prep — setImmediate queue is fragile |
| 9. Advanced | Polish layer once core is solid |

---

## Estimation

| Iteration | Effort | Dependencies |
|-----------|--------|--------------|
| 1. Quest | Medium | Schema change (QuestMessage stepIndex) |
| 2. Voice | Low | Manual testing, UI work |
| 3. Interconnection | High | Similarity computation, new views |
| 4. Social | High | NextAuth.js, share infrastructure |
| 5. AI Quality | Medium | Prompt engineering, post-processing |
| 6. Mobile | Medium | Responsive CSS, PWA setup |
| 7. Reflection | Medium | Cron jobs, email/notification infra |
| 8. Infra | High | Redis, logging, monitoring |
| 9. Advanced | High | Streaming, VLM integration |

**Total: ~9 iterations. At 1 iteration per session, ~9 sessions to production.**
